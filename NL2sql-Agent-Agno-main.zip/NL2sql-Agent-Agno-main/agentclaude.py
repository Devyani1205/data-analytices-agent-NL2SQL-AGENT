import logging
import json
import time
import re
from uuid import uuid4
from agno.agent import Agent
from agno.tools.postgres import PostgresTools
from agno.models.aws import AwsBedrock
from agno.models.groq import Groq
from textwrap import dedent
from agno.models.huggingface import HuggingFace
from agno.tools.replicate import ReplicateTools
from agno.agent import RunResponse 
import boto3
from agno.models.base import Model
# Global agent instance to avoid recreation
_agent_instance = None
from agno.models.response import ModelResponse
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
import config


# Import configuration constants only
from config import (
    DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BEDROCK_REGION
)

# Import functions only - avoid importing global variables
from database import execute_sql, get_table_schema
from processing import (
    format_response_as_objects,
    preprocess_user_query,
    determine_response_format
)
#async def generate_ai_analysis(query, results, sql_query, execution_time, schema_info=None, financial_columns=None, chart_data=None):

def generate_ai_analysis(query, results, sql_query, execution_time, schema_info=None, financial_columns=None, chart_data=None):
    """Generate comprehensive AI analysis using Agno agent with optimized performance"""
    try:
        # Prepare data summary for the AI agent
        data_summary = ""
        if results:
            result_count = len(results)
            headers = list(results[0].keys())
            
            # Sample data for AI analysis
            sample_data = results[:3]  # Reduced from 5 to 3 for efficiency
            
            # Numeric analysis (optimized version)
            numeric_stats = {}
            for header in headers:
                numeric_values = []
                for row in results:
                    try:
                        val = float(str(row.get(header, 0)))
                        if val != 0:
                            numeric_values.append(val)
                    except (ValueError, TypeError):
                        continue
                
                if numeric_values:  # More Pythonic check
                    numeric_stats[header] = {
                        'count': len(numeric_values),
                        'total': sum(numeric_values),
                        'average': sum(numeric_values) / len(numeric_values),
                        'min': min(numeric_values),
                        'max': max(numeric_values)
                    }
            
            data_summary = f"""
QUERY ANALYSIS CONTEXT:
- Original Query: {query}
- SQL Generated: {sql_query}
- Records Found: {result_count}
- Execution Time: {execution_time:.2f} seconds
- Data Columns: {', '.join(headers)}
- Visualization: {chart_data['chart_type'] if chart_data else 'None'}

SAMPLE DATA (first 3 records):
{json.dumps(sample_data, indent=2, default=str)}

NUMERIC STATISTICS:
{json.dumps(numeric_stats, indent=2) if numeric_stats else 'No numeric data found'}
"""
        else:
            data_summary = f"""
QUERY ANALYSIS CONTEXT:
- Original Query: {query}
- SQL Generated: {sql_query}
- Records Found: 0
- Execution Time: {execution_time:.2f} seconds
- Result: No data matched the query criteria
"""

        # Enhanced AI analysis prompt with structured format
        analysis_prompt = f"""
You are an expert medical practice data analyst. Analyze the following query results and provide a comprehensive analysis.

{data_summary}

Please provide your analysis in EXACTLY this JSON format:

{{
    "executive_summary": "2-3 sentence overview in conversational tone",
    "parameter_explanations": [
        {{
            "parameter": "column_name",
            "meaning": "Medical practice meaning",
            "importance": "Why it matters",
            "interpretation": "How to read values",
            "benchmarks": "Typical ranges"
        }}
    ],
    "detailed_breakdown": "Key patterns/trends with specific numbers",
    "key_insights": [
        "Specific, actionable insight with data",
        "Business implication with numbers",
        "Comparative analysis insight"
    ],
    "recommendations": [
        "Practical action with rationale",
        "Strategic recommendation",
        "Quick win suggestion"
    ],
    "follow_up_questions": [
        "Analytical question to explore",
        "Comparative question",
        "Trend investigation question"
    ],
    "summary_stats": {{
        "confidence_score": "High/Medium/Low",
        "key_takeaway": "Single powerful insight"
    }}
}}

Guidelines:
1. Be conversational yet professional
2. Use specific numbers from the data
3. Provide medical context
4. Make recommendations actionable
5. Highlight both strengths and areas for improvement
6. If no results, suggest query adjustments
"""
        
        # Initialize agent with optimized configuration
        analysis_agent = Agent(
            name="Medical Data Analysis Expert",
            model=Groq(id="llama-3.1-8b-instant"),
            description="Expert medical practice data analyst",
            instructions="Provide detailed, actionable insights in a friendly tone. Focus on practical implications.",
            temperature=0.3
        )
        
        # Generate and return analysis
        analysis_result = analysis_agent.run(analysis_prompt, timeout=90)
        #analysis_result = await analysis_agent.run(analysis_prompt, timeout=90)
        return json.loads(analysis_result.content)
        
    except Exception as e:
        logger.error(f"AI analysis error: {str(e)}", exc_info=True)
        return generate_fallback_analysis(results)

def generate_fallback_analysis(results):
    """Generate a structured fallback analysis"""
    record_count = len(results) if results else 0
    return {
        "executive_summary": f"Analysis of {record_count} records reveals insights for your practice.",
        "parameter_explanations": [],
        "detailed_breakdown": "Data shows patterns worth investigating.",
        "key_insights": [
            f"Found {record_count} relevant records",
            "Multiple metrics available for review",
            "Interesting patterns in the data"
        ],
        "recommendations": [
            "Examine detailed data trends",
            "Compare with historical data",
            "Identify significant outliers"
        ],
        "follow_up_questions": [
            "How do these compare to targets?",
            "What longer-term trends exist?",
            "Which areas show most variation?"
        ],
        "summary_stats": {
            "confidence_score": "Medium",
            "key_takeaway": "Your data contains valuable insights."
        }
    }
    
# FIXED FUNCTION: parse_ai_analysis_response
def parse_ai_analysis_response(ai_response):
    """Parse the AI analysis response into structured sections"""
    try:
        analysis_dict = {}
        
        # Split response by section headers
        sections = {
            'executive_summary': ['## EXECUTIVE_SUMMARY', 'executive_summary', 'explanation'],
            'detailed_breakdown': ['## DETAILED_BREAKDOWN', 'detailed_breakdown', 'breakdown'],
            'key_insights': ['## KEY_INSIGHTS', 'key_insights', 'insights'],
            'recommendations': ['## RECOMMENDATIONS', 'actionable_recommendations', 'recommendations'],
            'follow_up_questions': ['## FOLLOW_UP_QUESTIONS', 'follow_up_questions'],
            'summary_stats': ['## SUMMARY_STATS', 'summary_stats']
        }
        
        # Parse each section
        for section_key, section_markers in sections.items():
            content = None
            
            # Try to find content by section markers
            for marker in section_markers:
                if marker.upper() in ai_response.upper():
                    # Find content between this marker and next section
                    start_idx = ai_response.upper().find(marker.upper())
                    if start_idx != -1:
                        start_idx += len(marker)
                        # Find next section or end
                        next_section_idx = len(ai_response)
                        for next_marker in ['## ', '\n##']:
                            temp_idx = ai_response.find(next_marker, start_idx + 10)
                            if temp_idx != -1 and temp_idx < next_section_idx:
                                next_section_idx = temp_idx
                        
                        content = ai_response[start_idx:next_section_idx].strip()
                        break
            
            # Clean up content
            if content:
                content = content.replace('##', '').strip()
                # Convert bullet points to list if needed
                if section_key in ['key_insights', 'recommendations', 'follow_up_questions']:
                    if '•' in content or '*' in content or '-' in content:
                        lines = content.split('\n')
                        bullet_points = []
                        for line in lines:
                            line = line.strip()
                            if line and (line.startswith('•') or line.startswith('*') or line.startswith('-')):
                                bullet_points.append(line[1:].strip())
                            elif line and not line.startswith('#'):
                                bullet_points.append(line)
                        if bullet_points:
                            content = bullet_points
                
                analysis_dict[section_key] = content
        
        # Parse summary stats specially
        if 'summary_stats' not in analysis_dict:
            analysis_dict['summary_stats'] = {
                'confidence_score': 'High',
                'key_takeaway': 'Analysis completed successfully with valuable insights.'
            }
        
        return analysis_dict
        
    except Exception as e:
        logger.error(f"Error parsing AI analysis response: {str(e)}")
        return {
            'executive_summary': 'Analysis completed successfully.',
            'detailed_breakdown': 'Detailed breakdown available in results.',
            'key_insights': ['Analysis provides valuable insights into your data.'],
            'recommendations': ['Review the data patterns and consider follow-up analysis.'],
            'follow_up_questions': ['What specific trends would you like to explore further?'],
            'summary_stats': {'confidence_score': 'High', 'key_takeaway': 'Data analysis completed.'}
        }


def format_ai_text_to_html(text):
    """Convert AI-generated text to properly formatted HTML"""
    if not text:
        return ""
    
    # Convert markdown-style formatting to HTML
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.*?)\*', r'<em>\1</em>', text)
    text = re.sub(r'^\* ', r'• ', text, flags=re.MULTILINE)
    text = re.sub(r'^\d+\. ', lambda m: f'<strong>{m.group().strip()}</strong> ', text, flags=re.MULTILINE)
    
    # Convert bullet points to proper list
    if '•' in text:
        lines = text.split('\n')
        formatted_lines = []
        in_list = False
        
        for line in lines:
            line = line.strip()
            if line.startswith('•'):
                if not in_list:
                    formatted_lines.append('<ul style="margin: 10px 0; padding-left: 20px;">')
                    in_list = True
                formatted_lines.append(f'<li style="margin-bottom: 8px;">{line[1:].strip()}</li>')
            else:
                if in_list:
                    formatted_lines.append('</ul>')
                    in_list = False
                if line:
                    formatted_lines.append(f'<p style="margin-bottom: 12px;">{line}</p>')
        
        if in_list:
            formatted_lines.append('</ul>')
        
        text = '\n'.join(formatted_lines)
    else:
        # Convert paragraphs
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        text = '\n'.join(f'<p style="margin-bottom: 12px;">{p}</p>' for p in paragraphs)
    
    return text


def format_follow_up_questions(text):
    """Format follow-up questions into a nice list"""
    if not text:
        return ""
    
    # Extract questions (lines that end with ?)
    lines = text.split('\n')
    questions = []
    
    for line in lines:
        line = line.strip()
        if line and (line.endswith('?') or any(line.startswith(prefix) for prefix in ['- ', '* ', '1.', '2.', '3.', '4.', '5.'])):
            # Clean up the line
            line = re.sub(r'^[-*\d.]\s*', '', line).strip()
            if line and not line.endswith('?'):
                line += '?'
            questions.append(line)
    
    if not questions:
        # Fallback questions
        questions = [
            "Can you show me trends over time for this data?",
            "How does this compare to previous periods?", 
            "What are the top performers in this category?",
            "Are there any unusual patterns I should investigate?"
        ]
    
    # Format as HTML list
    question_html = '<ul style="margin: 10px 0; padding-left: 20px;">'
    for question in questions[:5]:  # Limit to 5 questions
        question_html += f'<li style="margin-bottom: 10px; cursor: pointer; padding: 8px; background: rgba(33, 150, 243, 0.05); border-radius: 6px; transition: all 0.2s;" onmouseover="this.style.background=\'rgba(33, 150, 243, 0.1)\'" onmouseout="this.style.background=\'rgba(33, 150, 243, 0.05)\'">{question}</li>'
    question_html += '</ul>'
    
    return question_html

# Query processing
def preprocess_user_query(query):
    if not query or not query.strip():
        return query.strip() if query else ""
    
    query = re.sub(r'\s+', ' ', query)
    query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)
    query = re.sub(r'/\*.*?\*/', '', query, flags=re.DOTALL)
    return query
def format_sql_error_message(error_str, query):
    """
    Convert technical SQL error messages into user-friendly messages
    """
    error_lower = error_str.lower()
    
    # Common SQL error patterns and their user-friendly messages
    if "column" in error_lower and "does not exist" in error_lower:
        return "The generated query referenced a column that doesn't exist in the database. Please try rephrasing your question or refresh and ask again."
    
    elif "invalid union/intersect/except order by clause" in error_lower:
        return "There was an issue with sorting the combined results. Please try simplifying your question or refresh and ask again."
    
    elif "syntax error" in error_lower:
        return "The generated SQL query has a syntax error. Please refresh the page and try asking your question again."
    
    elif "relation" in error_lower and "does not exist" in error_lower:
        return "The query tried to access a table that doesn't exist. Please check your question and try again."
    
    elif "permission denied" in error_lower:
        return "You don't have permission to access the requested data. Please contact your administrator."
    
    elif "connection" in error_lower and ("refused" in error_lower or "timeout" in error_lower):
        return "Database connection issue. Please refresh the page and try again."
    
    elif "out of memory" in error_lower:
        return "The query is too complex and exceeded memory limits. Please try a simpler question."
    
    elif "timeout" in error_lower:
        return "The query took too long to execute. Please try a more specific question."
    
    else:
        return "An error occurred while executing the query. Please refresh the page and try rephrasing your question."

def handle_sql_execution_error(error, query, user_id=None, knowledge_base=None):
    """
    Handle SQL execution errors with user-friendly messages
    """
    error_message = str(error)
    user_friendly_message = format_sql_error_message(error_message, query)
    
    # Log the actual error for debugging
    logging.error(f"SQL Execution Error for query '{query}': {error_message}")
    
    # Store the error in knowledge base if available
    if user_id and knowledge_base:
        try:
            knowledge_base.store_conversation(
                user_id=user_id,
                query=query,
                success=False,
                metadata={
                    "error": True,
                    "error_type": "sql_execution",
                    "original_error": error_message,
                    "user_friendly_error": user_friendly_message
                }
            )
        except Exception as e:
            logging.error(f"Failed to store error in knowledge base: {e}")
    
    return {
        "success": False,
        "query": query,
        "error": True,
        "data": [
            {
                "type": "error",
                "title": "Query Execution Error",
                "content": {
                    "html": f"""
                    <div style='background: #f8d7da; padding: 20px; border-radius: 8px; border-left: 4px solid #dc3545; margin: 10px 0;'>
                        <h4 style='color: #721c24; margin-top: 0; display: flex; align-items: center;'>
                            <span style='font-size: 1.2em; margin-right: 8px;'>⚠️</span>
                            Oops! Something went wrong
                        </h4>
                        <p style='color: #721c24; margin-bottom: 15px; font-size: 16px;'>
                            {user_friendly_message}
                        </p>
                        <div style='background: #ffffff; padding: 12px; border-radius: 4px; border: 1px solid #f5c6cb;'>
                            <strong style='color: #721c24;'>💡 Suggestions:</strong>
                            <ul style='color: #721c24; margin: 8px 0 0 0; padding-left: 20px;'>
                                <li>Try refreshing the page and asking your question again</li>
                                <li>Rephrase your question to be more specific</li>
                                <li>Break complex questions into simpler parts</li>
                                <li>Check if you're asking about data that exists in the system</li>
                            </ul>
                        </div>
                        <button onclick="location.reload()" style='background: #dc3545; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin-top: 15px;'>
                            🔄 Refresh Page
                        </button>
                    </div>
                    """
                }
            }
        ]
    }
    
# Add this class definition before your agent configuration
class MockResult:
    """Mock result class to match what Agent expects from model.run()"""
    def __init__(self, content: str):
        self.content = content
        self.usage = {}
        self.response_ms = 0
class ClaudeOpus41(Model):
    def __init__(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        aws_region: str,
        inference_profile_arn: str,
        max_tokens: int = 2048,
        temperature: float = 0.1,
        top_p: float = 0.9,
        top_k: int = 50
    ):
        # Pass the inference profile ARN as the id to the parent class
        super().__init__(id=inference_profile_arn)
        
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.aws_region = aws_region
        self.inference_profile_arn = inference_profile_arn
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        
        # Initialize Bedrock client
        self.bedrock_client = boto3.client(
            'bedrock-runtime',
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
            region_name=self.aws_region
        )
    
    def invoke(self, messages: list, **kwargs) -> ModelResponse:
        """Invoke Claude Opus 4.1 model"""
        from agno.models.response import ModelResponse
        
        # Extract system message and other messages
        system_message = None
        conversation_messages = []

        for msg in messages:
            if msg.role == "system":
                system_message = msg.content
            else:
                conversation_messages.append({"role": msg.role, "content": msg.content})

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "top_k": self.top_k,
            "messages": conversation_messages
        }

        # Add system message if it exists
        if system_message:
            body["system"] = system_message
        
        response = self.bedrock_client.invoke_model(
            modelId=self.inference_profile_arn,
            body=json.dumps(body)
        )
        
        response_body = json.loads(response['body'].read())
        
        # Create a proper response object
        model_response = ModelResponse(content=response_body['content'][0]['text'])
        model_response.parsed = response_body['content'][0]['text']  # Add parsed attribute
        return model_response
    
    async def ainvoke(self, messages: list, **kwargs) -> ModelResponse:
        """Async invoke - for now, just call sync version"""
        from agno.models.response import ModelResponse
        
        # Extract system message and other messages
        system_message = None
        conversation_messages = []

        for msg in messages:
            if msg.role == "system":
                system_message = msg.content
            else:
                conversation_messages.append({"role": msg.role, "content": msg.content})

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "top_k": self.top_k,
            "messages": conversation_messages
        }

        # Add system message if it exists
        if system_message:
            body["system"] = system_message
        
        response = self.bedrock_client.invoke_model(
            modelId=self.inference_profile_arn,
            body=json.dumps(body)
        )
        
        response_body = json.loads(response['body'].read())
        
        # Create a proper response object
        model_response = ModelResponse(content=response_body['content'][0]['text'])
        model_response.parsed = response_body['content'][0]['text']  # Add parsed attribute
        return model_response
    
    def invoke_stream(self, messages: list, **kwargs):
        """Stream invoke - return single response for now"""
        response = self.invoke(messages, **kwargs)
        yield response
    
    async def ainvoke_stream(self, messages: list, **kwargs):
        """Async stream invoke"""
        response = await self.ainvoke(messages, **kwargs)
        yield response
    
    def parse_provider_response(self, response, **kwargs) -> str:
        """Parse provider response"""
        if isinstance(response, dict) and 'content' in response:
            return response['content'][0]['text']
        return str(response)
    
    def parse_provider_response_delta(self, response, **kwargs) -> str:
        """Parse provider response delta for streaming"""
        return self.parse_provider_response(response, **kwargs)
    
# class ClaudeOpus4Model:
#     """Custom Claude Opus 4.1 model class for AWS Bedrock integration"""
    
#     def __init__(
#         self,
#         aws_access_key_id: str,
#         aws_secret_access_key: str,
#         aws_region: str,
#         inference_profile_arn: str,
#         anthropic_version: str = "bedrock-2023-05-31",
#         max_tokens: int = 2048,
#         temperature: float = 0.1,
#         top_p: float = 0.9,
#         top_k: int = 50,
#     ):
#         self.aws_access_key_id = aws_access_key_id
#         self.aws_secret_access_key = aws_secret_access_key
#         self.aws_region = aws_region
#         self.inference_profile_arn = inference_profile_arn
#         self.anthropic_version = anthropic_version
#         self.max_tokens = max_tokens
#         self.temperature = temperature
#         self.top_p = top_p
#         self.top_k = top_k
        
#         # Add id attribute for Agent framework compatibility
#         self.id = inference_profile_arn
#         self.provider = "aws_bedrock"
#         self.response = None  # Add this required attribute
    
#         # Don't create client in __init__ to avoid pickle issues
#         self._bedrock_client = None
#         logger.info(f"Initialized Claude Opus 4.1 model with ARN: {self.inference_profile_arn}")
    
#     @property
#     def bedrock_client(self):
#         """Create bedrock client on demand to avoid pickle issues"""
#         if self._bedrock_client is None:
#             try:
#                 self._bedrock_client = boto3.client(
#                     service_name='bedrock-runtime',
#                     aws_access_key_id=self.aws_access_key_id,
#                     aws_secret_access_key=self.aws_secret_access_key,
#                     region_name=self.aws_region
#                 )
#                 logger.debug("Created new Bedrock client")
#             except Exception as e:
#                 logger.error(f"Failed to initialize Bedrock client: {str(e)}")
#                 raise e
#         return self._bedrock_client
    
#     def __getstate__(self):
#         """Custom pickle behavior - exclude the bedrock client"""
#         state = self.__dict__.copy()
#         state['_bedrock_client'] = None
#         return state
    
#     def __setstate__(self, state):
#         """Custom unpickle behavior - restore state without client"""
#         self.__dict__.update(state)
#         self._bedrock_client = None
    
#     def get_system_message_for_model(self, system_message=None) -> str:
#         """
#         Required method by Agent framework to format system messages for the model
#         Handles both string and list inputs, preserving dedent formatting
#         """
#         if system_message is None:
#             return ""
        
#         # Handle list input (join with newlines)
#         if isinstance(system_message, list):
#             return "\n".join(str(item) for item in system_message)
        
#         # Handle string input (preserve as-is, including dedent formatting)
#         if isinstance(system_message, str):
#             return system_message
        
#         # Fallback for other types
#         return str(system_message)
    
#     def run(self, prompt: str, timeout: int = 90, user_id: str = None, session_id: str = None, **kwargs) -> RunResponse:
#         """
#         Main method that Agent expects - returns RunResponse object
#         """
#         try:
#             logger.info(f"Running Claude Opus 4.1 for user {user_id}, session {session_id}")
#             response_text = self.invoke(prompt, **kwargs)
            
#             # Create and return RunResponse object
#             run_response = RunResponse(
#                 content=response_text,
#                 content_type="str",
#                 model=self.id,
#                 model_provider=self.provider
#             )
#             self.response = run_response  # Store the response
#             return run_response
            
#         except Exception as e:
#             logger.error(f"Error in run method: {str(e)}")
#             error_response = RunResponse(
#                 content=f"Error: {str(e)}",
#                 content_type="str",
#                 model=self.id,
#                 model_provider=self.provider
#             )
#             self.response = error_response
#             return error_response
        
#     def invoke(self, prompt: str, system_prompt=None, **kwargs) -> str:
#         """
#         Invoke the Claude Opus 4.1 model and return the generated text
#         """
#         try:
#             # Prepare messages in Anthropic format
#             messages = [{"role": "user", "content": prompt}]
            
#             # Prepare request body
#             request_body = {
#                 "anthropic_version": self.anthropic_version,
#                 "max_tokens": kwargs.get('max_tokens', self.max_tokens),
#                 "temperature": kwargs.get('temperature', self.temperature),
#                 "top_p": kwargs.get('top_p', self.top_p),
#                 "top_k": kwargs.get('top_k', self.top_k),
#                 "messages": messages
#             }
            
#             if system_prompt:
#                 request_body["system"] = system_prompt
            
#             logger.debug(f"Making Bedrock API call with model ID: {self.inference_profile_arn}")
            
#             # Make the API call to Bedrock using the property
#             response = self.bedrock_client.invoke_model(
#                 modelId=self.inference_profile_arn,
#                 body=json.dumps(request_body),
#                 contentType='application/json',
#                 accept='application/json'
#             )
            
#             # Parse response
#             response_body = json.loads(response['body'].read())
#             logger.debug(f"Received response with keys: {list(response_body.keys())}")
            
#             # Extract the generated text
#             if 'content' in response_body and len(response_body['content']) > 0:
#                 generated_text = response_body['content'][0]['text']
#                 logger.info(f"Generated response length: {len(generated_text)} characters")
#                 return generated_text
#             else:
#                 logger.warning("No content in response")
#                 return "No response generated"
                
#         except Exception as e:
#             logger.error(f"Error invoking Claude Opus 4.1: {str(e)}")
#             return f"Error generating response: {str(e)}"
#     def get_instructions_for_model(self, instructions: str = None) -> str:
#         """
#         Method expected by Agent framework to format instructions for the model
#         """
#         if instructions:
#             return instructions
#         return ""

#     def generate(self, prompt: str, **kwargs) -> str:
#         """Alternative method name that some Agent implementations might expect"""
#         return self.invoke(prompt, **kwargs)
    
#     def chat(self, messages, **kwargs):
#         """Multi-turn conversation support"""
#         try:
#             # Prepare request body with conversation history
#             request_body = {
#                 "anthropic_version": self.anthropic_version,
#                 "max_tokens": kwargs.get('max_tokens', self.max_tokens),
#                 "temperature": kwargs.get('temperature', self.temperature),
#                 "top_p": kwargs.get('top_p', self.top_p),
#                 "top_k": kwargs.get('top_k', self.top_k),
#                 "messages": messages
#             }
            
#             # Add system prompt if provided
#             system_prompt = kwargs.get('system_prompt')
#             if system_prompt:
#                 request_body["system"] = system_prompt
            
#             response = self.bedrock_client.invoke_model(
#                 modelId=self.inference_profile_arn,
#                 body=json.dumps(request_body),
#                 contentType='application/json',
#                 accept='application/json'
#             )
            
#             response_body = json.loads(response['body'].read())
            
#             if 'content' in response_body and len(response_body['content']) > 0:
#                 return response_body['content'][0]['text']
#             else:
#                 logger.warning("No content in chat response")
#                 return "No response generated"
                
#         except Exception as e:
#             logger.error(f"Error in chat with Claude Opus 4.1: {str(e)}")
#             return f"Error in chat: {str(e)}"
    
    # def test_connection(self):
    #     """Test the connection to Claude Opus 4.1"""
    #     try:
    #         test_response = self.invoke(
    #             prompt="Respond with 'Connection test successful' to confirm the model is working.",
    #             max_tokens=50
    #         )
            
    #         if "error" not in test_response.lower():
    #             return {
    #                 'connection_status': 'success',
    #                 'message': 'Successfully connected to Claude Opus 4.1',
    #                 'model_response': test_response
    #             }
    #         else:
    #             return {
    #                 'connection_status': 'failed',
    #                 'message': f'Connection failed: {test_response}',
    #                 'model_response': test_response
    #             }
                
    #     except Exception as e:
    #         return {
    #             'connection_status': 'error',
    #             'message': f'Connection test error: {str(e)}',
    #             'model_response': None
    #         }
        
async def sql_agent(query, user_id=None):
    """Process natural language query using a unified Agno SQL Agent for validation and SQL generation"""
    start_time = time.time()
    logger.info(f"Processing query for user {user_id}: {query}")
    try:
        if not query or not query.strip():
            error_response = {
                "success": False,
                "error": "Empty query provided",
                "data": [
                    {
                        "type": "text",
                        "title": "Error",
                        "content": {"html": "<p>Please provide a valid query.</p>"}
                    }
                ]
            }
            if user_id and config.knowledge_base:
                config.knowledge_base.store_conversation(
            # if user_id:
            #     knowledge_base.store_conversation(
                    user_id=user_id,
                    query=query,
                    success=False,
                    metadata={"error": "Empty query"},
                    response_data=error_response
                )
            return error_response

        # Handle memory clearing
        if "clear my memories" in query.lower() or "remove all memories" in query.lower():
            if user_id:        
                config.memory.clear()
                success_response = {
                    "success": True,
                    "query": query,
                    "data": [
                        {
                            "type": "text",
                            "title": "Memory Cleared",
                            "content": {"html": "<p>All your memories have been cleared.</p>"}
                        }
                    ]
                }
                config.knowledge_base.store_conversation(
                    user_id=user_id,
                    query=query,
                    success=True,
                    metadata={"action": "clear_memories"},
                    response_data=success_response
                )
                return success_response
            else:
                error_response = {
                    "success": False,
                    "error": "User ID required to clear memories",
                    "data": [
                        {
                            "type": "text",
                            "title": "Error",
                            "content": {"html": "<p>Please provide a user ID to clear memories.</p>"}
                        }
                    ]
                }
                return error_response

        # Get schema
        schema_info = get_table_schema()
        if not schema_info:
            error_msg = "Failed to retrieve database schema"
            error_response = {
                "success": False,
                "error": error_msg,
                "data": [
                    {
                        "type": "text",
                        "title": "Error",
                        "content": {"html": "<p>Database schema retrieval failed. Check database connection.</p>"}
                    }
                ]
            }
            if user_id and config.knowledge_base:
                config.knowledge_base.store_conversation(
            # if user_id:
            #     knowledge_base.store_conversation(
                    user_id=user_id,
                    query=query,
                    success=False,
                    metadata={"error": error_msg},
                    response_data=error_response
                )
            return error_response

        # Get user preferences
        
        # Build schema prompt
        schema_prompt = "# Medical Practice Database Schema\n\n"
        for table_name, table_info in schema_info.items():
            schema_prompt += f"## Table: {table_name} ({table_info['row_count']:,} rows)\n"
            schema_prompt += "### Columns:\n"
            for col in table_info["columns"]:
                pk_marker = " (PK)" if col["primary_key"] else ""
                nullable = " NULL" if col["nullable"] else " NOT NULL"
                schema_prompt += f"- {col['name']}: {col['type']}{pk_marker}{nullable}\n"
            if table_info["foreign_keys"]:
                schema_prompt += "### Relationships:\n"
                for fk in table_info["foreign_keys"]:
                    schema_prompt += f"- {fk['from']} → {fk['to_table']}.{fk['to_column']}\n"
            schema_prompt += "\n"
            
        # Initialize PostgresTools
        postgres_tools = PostgresTools(
            host=DB_HOST,
            port=int(DB_PORT),
            db_name=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )


        # Enhanced instructions for unified validation and SQL generation
        enhanced_instructions = dedent("""\
            You are an expert SQL generator and validator for a medical practice database. Your role is to:
            1. Understand the user's query intent, understand semantic meaning and context of input
            2. Map it to the provided schema
            3. Generate a PostgreSQL SELECT query
            
            RESPONSE FORMAT REQUIREMENTS:
            Your response must contain these sections in markdown format:

            ### Explanation
            Provide only the relevant steps used to generate this query in clear, numbered points:
            [Only include steps that were actually needed for designing from following general template that sql_query dont explain steps not needed for design]

            Provide a clear, step-by-step explanation in natural language of how the query works:
            1. First, identify what key information the query needs to find.
            2. Next, map this information to the correct tables and columns in the database.
            3. Join the necessary tables together using the right conditions or keys.
            4. Apply filters to include only the rows that meet certain criteria.
            5. Group and sort the results in a way that makes the output meaningful.
            6. Finally, select and display the specific columns you want in the result.
           
            ### SQL Query
            ```sql
            [Generated SQL Query]
            ```
            MANDATORY VALIDATION PROTOCOL:
            1. **Understand deep sementic meaning Query Intent and Map to Schema**:
            - Analyze the query to identify the user's intent by extracting key terms understand  the deep sementic meaning of user input (e.g., 'income', 'earnings', 'salary', 'procedure_date').
            - Map these terms to relevant schema columns using semantic understanding:
                - Financial terms → undestand the sementic meaning all information from schema prompt revenue/income/cost columns
                
            - If no direct match, select the most relevant column(s) based on context move from table to column to entries
            - If the query cannot be mapped, return:
                ```
                INFORMATION_NOT_AVAILABLE: for this query '[query]' information is not present in the database schema. Available information includes: [list relevant table.column pairs]
                ```

            DATA UNAVAILABILITY HANDLING(MANDATORY):
            # Enhanced error response templates
            INFORMATION_NOT_AVAILABLE_MESSAGES:
                "I don't have data regarding [request] in our current database.",
                "The specific information about [request]  is not available in our database schema. ",
                "Unfortunately, data regarding [request]  is not stored in our current system.",
                "The requested information about [request]  is not present in our database. ",
                "I don't have access to data about [request]  in our current database structure."
                "However, I can provide insights on available data including case volumes, surgeon performance, billing information, and facility utilization.I can help you with queries related to OR scheduling, financial analytics, and clinical operations data"
            

            SQL_GENERATION_ERROR_MESSAGES(MANDATORY):
                "I apologize, but I couldn't generate the correct query for your request. Could you please rephrase your question in simple English?",
                "I need more context to understand your request better. Could you please provide more specific details about what information you're looking for?",
                "Let me try again - could you please write your question in normal English with more details?",
                "I'm having trouble understanding your request. Could you please refresh your query and provide more context?",
                "Could you please rephrase your question in plain English? I'll try to better understand what you're looking for."
                ```

            SCHEMA:
            The schema is provided in the prompt. Use only the listed tables and columns.
        """)

        table_prompt = dedent("""\
            1. PATIENT & VISIT MANAGEMENT
            big_sky_admission_billing_schedule
            Purpose: Tracks patient appointments and billing status
            patient_id (PK): Unique patient identifier
            dos (PK): Date of service - the actual appointment/surgery date
            appointment_time: Scheduled time for the appointment
            patient_name: Patient's full name
            physician: Attending physician name
            procedure: Medical procedure to be performed
            auth_dos: Authorization days of service approved by insurance
            primary_payer: Primary insurance company/payer
            verification_status: Boolean - whether insurance verification is complete
            appointment_status: Current status (scheduled, completed, cancelled, etc.)
            amount_due: Total amount patient owes
            balance_due: Outstanding balance after payments
            is_total: Boolean flag for summary rows

            big_sky_visit_billing_data
            Purpose: Comprehensive billing and clinical data per patient visit

            acct_num (PK): Account number for billing
            ptid_vst_num (PK): Patient ID + Visit number combination
            patient_name: Patient's full name
            dos: Date of service
            date_billed: When the claim was submitted
            date_paid: When payment was received
            phys_id: Physician unique identifier
            phys_name: Physician name
            cpt_code1-10: Up to 10 CPT procedure codes billed
            desc1-10: Descriptions for each CPT code
            cpt1-10_modifiers: Medical coding modifiers
            pre_op_min: Pre-operative time in minutes
            or_min: Operating room time in minutes
            srgy_min: Actual surgery time in minutes
            rr_min: Recovery room time in minutes
            supply_cost: Cost of medical supplies used
            staff_cost: Labor cost for staff time
            billed_amt: Total amount billed to insurance
            payments: Total payments received
            balance_due: Outstanding balance

            2. SURGICAL OPERATIONS & SCHEDULING
            big_sky_procedure_data_with_turnover
            Purpose: Detailed surgical case timing and turnover metrics

            patient_id (PK): Patient identifier
            visit_number (PK): Visit sequence number
            or_room: Operating room identifier
            date_of_service: Surgery date
            scheduled_start_time: Planned surgery start time
            anesthesia_start_time: When anesthesia began
            anesthesia_end_time: When anesthesia ended
            surgery_start_time: Actual surgery start time
            surgery_end_time: Actual surgery end time
            or_start_time: OR room occupation start
            or_end_time: OR room occupation end
            or_turnover_minutes: Time between cases for room preparation
            procedure_description: Surgical procedure performed
            surgeon_name: Primary surgeon
            anesthesia_type: Type of anesthesia used
            anesthesiologist_name: Anesthesia provider

            big_sky_surgery_time_log
            Purpose: Detailed timestamps for each phase of surgical care

            pt_id_visit (PK): Patient + visit identifier
            dos: Date of service
            sched_time: Scheduled appointment time
            pt_arr: Patient arrival time
            phys_arr: Physician arrival time
            registr_start/min: Registration phase timing
            preop_start/min: Pre-operative preparation timing
            anes_start/min: Anesthesia administration timing
            or_start/min: Operating room time
            surgery_start/min: Actual surgical procedure timing
            pacu_phase1_start/min: Post-anesthesia care unit phase 1
            postop_phase2_start/min: Post-operative phase 2 recovery
            extended_stay_start/min: Extended recovery if needed
            antibiotic_start/min: Antibiotic prophylaxis timing

            big_sky_surgical_clinical_data
            Purpose: Comprehensive clinical and operational data per case (currently empty but structured)

            Contains detailed clinical metrics, staff assignments, timing data
            Multiple staff positions (staff1-10) with roles and time allocation
            Temperature, vital signs, and clinical indicators
            Equipment and scope usage tracking

            3. FINANCIAL MANAGEMENT
            big_sky_financial_class_summary
            Purpose: Payment performance metrics by insurance type

            financial_class (PK): Insurance category (Medicare, Commercial, Self-pay, etc.)
            total_cases: Number of cases in this category
            total_billed: Total charges submitted
            balance_due: Outstanding receivables
            primary_payments: Payments from primary insurance
            secondary_payments: Payments from secondary insurance
            self_pay_payments: Patient payments
            contract_writeoffs: Contractual adjustments
            bad_debt_writeoffs: Uncollectable amounts
            percent_primary_pay_billed: Primary payer reimbursement rate
            avg_payment_days_primary: Days to receive primary payment
            avg_billed_per_case: Average charges per case
            avg_payment_per_case: Average payment per case

            big_sky_contractual_revenue_variance
            Purpose: Analysis of expected vs actual contract performance

            account_number (PK): Patient account
            visit_number (PK): Visit identifier
            payer_id: Insurance company identifier
            contract_id: Specific contract terms
            billed_amount: Amount charged
            contract_estimated: Expected reimbursement per contract
            contract_actual: Actual payment received
            contract_variance: Difference between expected and actual
            revenue_estimated: Projected revenue
            revenue_actual: Actual revenue received
            revenue_variance: Revenue performance variance

            big_sky_payment_trending
            Purpose: Payment timing analysis by aging buckets

            claim_number (PK): Insurance claim identifier
            payer_id: Insurance company
            gross_billing: Total charges
            expected_revenue: Projected collections
            payment_0_30_days: Payments received within 30 days
            payment_31_60_days: Payments received 31-60 days
            payment_61_90_days: Payments received 61-90 days
            payment_91_120_days: Payments received 91-120 days
            payment_121_plus_days: Payments received after 120 days
            Each aging bucket has corresponding percentage fields

            4. COST ANALYSIS & PROFITABILITY
            big_sky_procedure_profit_cost
            Purpose: Profitability analysis by procedure and surgeon

            procedure_name (PK): Surgical procedure type
            surgeon_id (PK): Surgeon identifier
            case_count: Number of cases performed
            gross_billing: Total charges for these cases
            expected_revenue: Projected collections
            actual_payment: Actual payments received
            direct_cost: Direct costs (supplies, implants)
            indirect_cost: Indirect costs (overhead, admin)
            total_cost: Combined direct and indirect costs
            net_profit: Revenue minus total costs
            profit_margin_expected: Expected profit percentage
            profit_margin_actual: Actual profit percentage

            big_sky_procedure_summary
            Purpose: Case-level cost and timing summary

            pt_id_visit (PK): Patient + visit identifier
            procedure: Surgical procedure performed
            physician: Performing surgeon
            primary_payer: Insurance company
            srgy_min: Surgery duration in minutes
            staff_cost: Labor costs for the case
            center_supply_cost: Medical supply costs
            billed_amount: Total charges

            5. PHYSICIAN & STAFF MANAGEMENT
            big_sky_physician_case_billings
            Purpose: Monthly billing performance by physician

            physician_name (PK): Doctor's name
            specialty: Medical specialty
            jan_25_cases through dec_25_cases: Monthly case volumes
            jan_25_billings through dec_25_billings: Monthly billing amounts
            total_cases: Annual case volume
            total_billings: Annual billing total

            big_sky_surgeon_master
            Purpose: Physician directory and credentials

            physician_id (PK): Unique doctor identifier
            physician_name: Doctor's full name
            specialty: Medical specialty
            npi: National Provider Identifier
            state_license: Medical license number
            status: Active/inactive status

            big_sky_staff_master
            Purpose: Employee directory

            employee_id (PK): Unique staff identifier
            employee_name: Staff member's name
            hire_date: Employment start date
            department: Work department
            employee_type: Job classification

            big_sky_staff_utilization
            Purpose: Staff time tracking per surgical case

            staff_name: Employee name
            role: Job function during case
            scheduled_duration: Planned time allocation
            or_duration: Actual OR time
            time_on_patient: Direct patient care time

            big_sky_employee_credentials
            Purpose: Professional licensing and certification tracking

            employee_id: Staff identifier
            credential_type: Type of license/certification
            expiration_date: When credential expires
            credential_status: Current status (active, expired, pending)
            license_number: Official credential number

            6. CLINICAL QUALITY & ANESTHESIA
            big_sky_anesthesia_statistics
            Purpose: Anesthesia performance and safety metrics

            anesthesia_type (PK): Type of anesthesia (General, Regional, Local, etc.)
            number_of_cases_performed: Case volume
            number_of_complications: Adverse events
            total_anesthesia_time_minutes: Aggregate anesthesia time

            7. SUPPLY CHAIN & INVENTORY
            big_sky_item_information
            Purpose: Medical supply and equipment catalog

            item_id (PK): Inventory item identifier
            item_description: Product name/description
            mfg_cat_no: Manufacturer catalog number
            hcpcs_code: Healthcare billing code
            stock_level: Current inventory quantity
            cost_price: Purchase cost
            markup_price: Internal pricing with markup
            current_price: Current selling price

            big_sky_preference_card_list
            Purpose: Surgeon-specific supply preferences

            phys_id (PK): Physician identifier
            pref_card_description (PK): Preference card name
            procedure_description: Associated procedure
            cost: Total cost of preference card supplies

            8. REFERENCE DATA
            big_sky_procedures
            Purpose: Master procedure catalog

            procedure (PK): Procedure code/name
            description: Detailed procedure description
            primary_cpt: Main billing code
            specialty: Medical specialty
            duration: Expected procedure time
            require_laser: Whether laser equipment needed

            big_sky_cpt_codes
            Purpose: Medical billing code reference

            cpt_code (PK): Current Procedural Terminology code
            description: Procedure description
            specialty: Associated medical specialty
            medicare_fee: Medicare reimbursement rate
            revenue_code: Hospital revenue code category

            big_sky_payer_list
            Purpose: Insurance company directory

            payer_id (PK): Insurance company identifier
            payer_name: Insurance company name
            financial_class: Category (Commercial, Medicare, Medicaid, etc.)
            payer_type: Insurance type classification
            claim_format: Electronic format for claims
            status: Active/inactive status
        """) 
        Formula_prompt = dedent("""\
            First Case On-Time Start Accuracy = (On-time first cases ÷ Total first cases) * 100
            Block Utilization (Method 1) = (Total Case Time ÷ Total Allocated Block Time) * 100
            Block Utilization (Method 2) = ((Last Wheels Out - First Wheels In) ÷ Total Allocated Block Time) *100
            OR Utilization (People Count) = (Minutes with People Present ÷ Total Available Minutes) * 100
            OR Utilization (Case Duration) = (Σ(Wheels Out - Wheels In) ÷ Total Available OR Time) * 100
            OR Utilization (With Turnover) = ((Total Time - Time with Zero People Count) ÷ Total Available Time) * 100
            TAT (>1 hour apart) = T(room_empty) - T(wheels_out)
            TAT (≤1 hour apart) = T(next_wheels_in) - T(previous_wheels_out)
            Procedure Length = Cut Time - Close Time
            Scheduling Duration Accuracy = (Actual - Scheduled) ÷ Scheduled * 100
            Block Time Utilization = (Total Actual Surgery Time ÷ Allocated Block Time) * 100
            Anesthesia Booking Efficiency = (Total Anesthesia Hours Used ÷ Contracted Anesthesia Hours) * 100
            Total Case Cost = Direct Labor + OR Time Cost + Supply & Implant + Medication + Equipment/Depreciation + Allocated Overhead + Indirect Labor
            Profit Margin % = (Revenue - Total Case Cost) ÷ Revenue * 100
            Contribution Margin = Revenue - Variable Costs
            Contribution Margin % = (Revenue - Variable Costs) ÷ Revenue * 100
            FTEs per Case = Count of staff (by role) present during case duration
            On-Time Start Flag = IF(actual_start_time ≤ scheduled_start_time, "On-Time", "Delayed")
            Turnover Time = Next Case WHEELS_IN - Current Case WHEELS_OUT
            Contribution Margin per Surgeon = SUM(Contribution Margin per Case where surgeon = [Surgeon Name])
            Revenue per CPT = SUM(Revenue for cases with specific CPT code)
            Cost per CPT = SUM(Total Case Cost for cases with specific CPT code)
            Margin per CPT = Revenue per CPT - Cost per CPT
            Margin % per CPT = (Margin per CPT ÷ Revenue per CPT) * 100
            Supply Cost per Case = SUM(Cost of supplies/implants used in case)
            Variance from Preference Card = Actual Supply Used - Preference Card Supply
            Margin Impact = Contribution Margin with Actual Supplies - Contribution Margin with Standard Supplies
        """)

        # Get or create session for user
        session_id = config.active_sessions.get(user_id, str(uuid4()))
        if user_id and user_id not in config.active_sessions:
            config.active_sessions[user_id] = session_id
        postgres_tools = PostgresTools(
            host=DB_HOST,
            port=int(DB_PORT),
            db_name=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        
        # Get or create agent instance to avoid pickle issues
        global _agent_instance
        if _agent_instance is None:
            postgres_tools = PostgresTools(
                host=DB_HOST,
                port=int(DB_PORT),
                db_name=DB_NAME,
                user=DB_USER,
                password=DB_PASSWORD
            )
            
        # Usage in your agent
        # Usage in your agent
        claude_opus_41 = ClaudeOpus41(
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            aws_region=BEDROCK_REGION,
            inference_profile_arn=config.BEDROCK_INFERENCE_PROFILE_ARN4
        )

        agent = Agent(
            name="Medical SQL Validator and Generator",
            model=claude_opus_41,
            tools=[postgres_tools],
            memory=config.memory,
            storage=config.session_storage,
            enable_agentic_memory=True,
            enable_user_memories=True,
            description="Expert at generating and validating SQL code for medical database schemas",
            instructions=enhanced_instructions
        )
        
        # claude_opus_model = ClaudeOpus4Model(
        #     aws_access_key_id=AWS_ACCESS_KEY_ID,
        #     aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #     aws_region=BEDROCK_REGION,
        #     inference_profile_arn=config.BEDROCK_INFERENCE_PROFILE_ARN4,
        #     anthropic_version="bedrock-2023-05-31",
        #     max_tokens=2048,
        #     temperature=0.1,
        #     top_p=0.9,
        #     top_k=50
        # )

        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=claude_opus_model,
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="Expert at generating and validating SQL code for medical database schemas using Claude Opus 4.1",
        #     instructions=enhanced_instructions
        # )
        
        
        #Initialize the unified agent with Claude Opus 4
        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=AwsBedrock(
        #         aws_access_key_id=AWS_ACCESS_KEY_ID,
        #         aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #         aws_region=BEDROCK_REGION,
        #         id="arn:aws:bedrock:us-east-2:535002855311:inference-profile/us.anthropic.claude-opus-4-1-20250805-v1:0"
        #     ),
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="Expert at generating and validating SQL code for medical database schemas",
        #     instructions=enhanced_instructions
        # )
          # Optional: Use inference profile if you have one configured
          # inference_profile_id=BEDROCK_INFERENCE_PROFILE_ARN
          
        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=AwsBedrock(
        #         id="arn:aws:bedrock:us-east-2:535002855311:inference-profile/us.anthropic.claude-opus-4-1-20250805-v1:0",  # Claude 3.5 Sonnet via Bedrock
        #         aws_access_key_id=AWS_ACCESS_KEY_ID,
        #         aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #         aws_region=BEDROCK_REGION
        #     ),
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="You are an expert at generating and validating SQL code for PostgreSQL database",
        #     instructions=enhanced_instructions
        # )
        # agent = Agent(
        #     name="correct SQL Validator and Generator",
        #     model=HuggingFace(
        #         id="defog/sqlcoder-70b-alpha",  # SQLCoder fine-tuned model defog/sqlcoder-70b-alpha
        #         api_key="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",
        #         max_tokens=1024,
        #         temperature=0.1
        #     ),
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     storage=config.session_storage,
        #     description="Expert SQL generator using fine-tuned SQLCoder model",
        #     instructions=enhanced_instructions
        # )
        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=AwsBedrock(
        #         id="meta.llama3-3-70b-instruct-v1:0",
        #         aws_access_key_id=AWS_ACCESS_KEY_ID,
        #         aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #         aws_region=BEDROCK_REGION
        #     ),
        #     tool =[ReplicateTools(model="nateraw/sqlcoder-70b-alpha")],
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="Expert SQL generator using Llama 3.3 70B + SQLCoder-70B",
        #     instructions=enhanced_instructions
        # )
        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=AwsBedrock(
        #         id="meta.llama3-3-70b-instruct-v1:0",
        #         aws_access_key_id=AWS_ACCESS_KEY_ID,
        #         aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #         aws_region=BEDROCK_REGION
        #     ),
        #     tools=[ReplicateTools(model="nateraw/sqlcoder-70b-alpha")],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="Expert SQL generator using Llama 3.3 70B + SQLCoder-70B",
        #     instructions=enhanced_instructions
        # )
        # agent = Agent(
        #     name="Medical SQL Validator and Generator",
        #     model=AwsBedrock(
        #         id="meta.llama3-3-70b-instruct-v1:0",  # Claude 3.5 Sonnet via Bedrock
        #         aws_access_key_id=AWS_ACCESS_KEY_ID,
        #         aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        #         aws_region=BEDROCK_REGION              
        #     ),
        #     tools=[postgres_tools],
        #     memory=config.memory,
        #     storage=config.session_storage,
        #     enable_agentic_memory=True,
        #     enable_user_memories=True,
        #     description="You are an expert at generating and validating SQL code for PostgreSQL database",
        #     instructions=enhanced_instructions
        # )
        # Add context from similar queries
        context_info = ""
        if user_id:
            similar_queries = config.knowledge_base.get_similar_queries(user_id, query, 3)
            if similar_queries:
                context_info = "\n# Previous Similar Queries Context:\n"
                for sq in similar_queries:
                    context_info += f"- Query: {sq[0]}\n  SQL: {sq[1]}\n"

        processed_query = preprocess_user_query(query)
        combined_query = f"{schema_prompt}\n{table_prompt}\n{Formula_prompt}\n{context_info}\n\nUser Query: {processed_query}\n"

        # Run the agent
        result = agent.run(combined_query, timeout=90, user_id=user_id, session_id=session_id)

        # Check if the agent indicates information is not available
        if "INFORMATION_NOT_AVAILABLE:" in result.content:
            info_not_available_msg = result.content.split("INFORMATION_NOT_AVAILABLE:")[1].strip()
            # if user_id:
            #     knowledge_base.store_conversation(user_id, query, success=True, metadata={"info_not_available": True, "agent_response": info_not_available_msg})
            if user_id and config.knowledge_base:
                config.knowledge_base.store_conversation(user_id, query, success=True, metadata={"info_not_available": True, "agent_response": info_not_available_msg})
            return {
                "success": True,
                "query": query,
                "info_not_available": True,
                "data": [
                    {
                        "type": "text",
                        "title": "Information Not Available",
                        "content": {"html": f"<div style='background: #fff3cd; padding: 15px; border-radius: 8px; border-left: 4px solid #ffc107;'><h4 style='color: #856404; margin-top: 0;'>📋 Database Information</h4><p>{info_not_available_msg}</p></div>"}
                    }
                ]
            }

        # Extract explanation and SQL query from response
        explanation = ""
        sql_query = ""

        # Extract explanation section
        explanation_match = re.search(r'### Explanation\n(.*?)(?=\n###)', result.content, re.DOTALL)
        if explanation_match:
            explanation = explanation_match.group(1).strip()

        # Extract SQL query
        sql_query_match = re.search(r'```sql\n(.*?)\n```', result.content, re.DOTALL)
        if sql_query_match:
            sql_query = sql_query_match.group(1).strip()

        if not sql_query and result.content.strip():
            if user_id and config.knowledge_base:
                config.knowledge_base.store_conversation(user_id, query, success=True, metadata={"no_sql_generated": True, "agent_response": result.content})
            
            # if user_id:
            #     knowledge_base.store_conversation(user_id, query, success=True, metadata={"no_sql_generated": True, "agent_response": result.content})
            return {
                "success": True,
                "query": query,
                "no_sql_generated": True,
                "data": [
                    {
                        "type": "text",
                        "title": "Agent Response",
                        "content": {"html": f"<div style='background: #e7f3ff; padding: 15px; border-radius: 8px; border-left: 4px solid #007bff;'><h4 style='color: #004085; margin-top: 0;'>🤖 Agent Response</h4><p>{result.content}</p></div>"}
                    }
                ]
            }
        dangerous_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'ALTER', 'CREATE', 'TRUNCATE', 'GRANT', 'REVOKE']
        if any(keyword in sql_query.upper() for keyword in dangerous_keywords):
            error_msg = "Generated query contains potentially dangerous operations"
            logger.warning(f"Dangerous SQL detected: {sql_query}")
            return handle_sql_execution_error(error_msg, query, user_id, config.knowledge_base)

        # Execute SQL query with comprehensive error handling
        try:
            results = execute_sql(sql_query)
            execution_time = time.time() - start_time

            # Prepare the complete response data
            response_data = {
                "success": True,
                "query": query,
                "sql": sql_query,
                "execution_time": execution_time,
                "result_count": len(results),
                "data": format_response_as_objects(query, sql_query, results, execution_time, explanation)
            }

            # Store successful conversation with full response data
            if user_id:
                try:
                    response_format = determine_response_format(query, results)
                    config.knowledge_base.store_conversation(
                        user_id=user_id,
                        query=query,
                        sql_query=sql_query,
                        result_count=len(results),
                        success=True,
                        execution_time=execution_time,
                        metadata={
                            "response_format": response_format,
                            "explanation": explanation,
                            "query_type": response_format
                        },
                        response_data=response_data
                    )
                except Exception as e:
                    logger.error(f"Failed to store successful conversation: {e}")

            logger.info(f"Query processed in {execution_time:.2f}s - {len(results)} rows")
            return response_data

        except Exception as sql_error:
            # Handle SQL execution errors with user-friendly messages
            return handle_sql_execution_error(sql_error, query, user_id, config.knowledge_base)

    except Exception as e:
        error_time = time.time() - start_time
        logger.error(f"Query processing failed after {error_time:.2f}s: {str(e)}")
        
        error_response = {
            "success": False,
            "error": str(e),
            "execution_time": error_time,
            "data": [
                {
                    "type": "text",
                    "title": "Error",
                    "content": {"html": f"<p><strong>Error:</strong> {str(e)}<br><strong>Query:</strong> {query}</p>"}
                }
            ]
        }
        
        if user_id:
            config.knowledge_base.store_conversation(
                user_id=user_id,
                query=query,
                success=False,
                metadata={"error": str(e)},
                response_data=error_response
            )
        
        return error_response
    
    
