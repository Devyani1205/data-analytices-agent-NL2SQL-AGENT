
import boto3
import os
import logging
import json
import time
from datetime import datetime, timedelta
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import DictCursor, RealDictCursor
from psycopg2.pool import SimpleConnectionPool
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)



from config import (
    LOG_USER_ID, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    GROQ_API_KEY, DB_URL, OPENAI_API_KEY, AWS_ACCESS_KEY_ID,
    AWS_SECRET_ACCESS_KEY, BEDROCK_REGION
)

# Schema cache configuration
SCHEMA_CACHE_FILE = "schema_cache.json"
SCHEMA_CACHE_DURATION = 3600  # 1 hour in seconds
from config import knowledge_base, memory, active_sessions

# # Global variables
# memory_db = None
# memory = None
# connection_pool = None
# session_storage = None
# active_sessions = {}  # Track active sessions per user

WORKING_TABLES = [
    "big_sky_admission_billing_schedule",
    "big_sky_anesthesia_statistics",
    "big_sky_contractual_revenue_variance",
    "big_sky_cpt_codes",
    "big_sky_employee_credentials",
    "big_sky_employees_list",
    "big_sky_financial_class_summary",
    "big_sky_item_information",
    "big_sky_payer_list",
    "big_sky_payment_trending",
    "big_sky_physician_case_billings",
    "big_sky_preference_card_list",
    "big_sky_procedure_data_with_turnover",
    "big_sky_procedure_profit_cost",
    "big_sky_procedure_summary",
    "big_sky_procedures",
    "big_sky_staff_master",
    "big_sky_staff_utilization",
    "big_sky_surgeon_master",
    "big_sky_surgery_time_log",
    "big_sky_surgical_clinical_data",
    "big_sky_visit_billing_data"
]


# Initialize AWS Bedrock client
def get_bedrock_client():
    """Initialize AWS Bedrock client with your credentials"""
    return boto3.client(
        'bedrock-runtime',
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        region_name=BEDROCK_REGION
    )
    
def migrate_add_conversation_id():
    """Add conversation_id column to existing table"""
    try:
        with psycopg2.connect(DB_URL.replace("postgresql+psycopg", "postgresql")) as conn:
            with conn.cursor() as cursor:
                # Check if column already exists
                cursor.execute("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = 'user_conversations' 
                    AND column_name = 'conversation_id'
                """)
                
                if not cursor.fetchone():
                    # Add the column
                    cursor.execute("""
                        ALTER TABLE user_conversations 
                        ADD COLUMN conversation_id UUID DEFAULT gen_random_uuid()
                    """)
                    
                    # Update existing rows to have unique conversation_ids
                    cursor.execute("""
                        UPDATE user_conversations 
                        SET conversation_id = gen_random_uuid() 
                        WHERE conversation_id IS NULL
                    """)
                    
                    # Make it NOT NULL after updating
                    cursor.execute("""
                        ALTER TABLE user_conversations 
                        ALTER COLUMN conversation_id SET NOT NULL
                    """)
                    
                    conn.commit()
                    logger.info("Added conversation_id column successfully")
                else:
                    logger.info("conversation_id column already exists")
                    
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        raise

class KnowledgeBase:
    """PostgreSQL-based knowledge base for storing and utilizing previous conversations with conversation grouping"""
    
    def __init__(self, db_url=None):
        self.db_url = db_url  
        self.init_db()
    # Existing user_conversations table
    def init_db(self):
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS user_conversations (
                        id SERIAL PRIMARY KEY,
                        conversation_id UUID DEFAULT gen_random_uuid(),
                        user_id TEXT NOT NULL,
                        query TEXT NOT NULL,
                        sql_query TEXT,
                        result_count INTEGER,
                        success BOOLEAN,
                        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
                        execution_time REAL,
                        metadata JSONB DEFAULT '{}'::jsonb,
                        response_data JSONB DEFAULT '{}'::jsonb
                    )
                """)
                
                # NEW: Active sessions table to track current conversation per user
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS user_active_sessions (
                        user_id TEXT PRIMARY KEY,
                        conversation_id UUID NOT NULL,
                        created_at TIMESTAMP DEFAULT NOW()
                    )
                """)
                
                # Add indexes
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_user_conversations_conversation_id 
                    ON user_conversations(conversation_id)
                """)
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_user_conversations_user_id 
                    ON user_conversations(user_id, timestamp DESC)
                """)
                
                conn.commit()
                logger.info("Initialized knowledge base database in PostgreSQL")
        
        # Run migration to add conversation_id to existing data
        migrate_add_conversation_id()
    
    
    @contextmanager
    def get_connection(self):
        conn = psycopg2.connect(self.db_url.replace("postgresql+psycopg", "postgresql"))
        try:
            yield conn
        finally:
            conn.close()
    

    def store_conversation(self, user_id, query, conversation_id=None, sql_query=None, 
                            result_count=0, success=True, execution_time=0, metadata=None, 
                            response_data=None):
        """
        Store conversation with robust handling of response data formats and conversation grouping.
        Returns tuple of (record_id, conversation_id)
        
        Args:
            user_id: User identifier
            query: The user's query
            conversation_id: Optional UUID to group related queries together
            sql_query: Generated SQL query (if any)
            result_count: Number of results returned
            success: Whether the query was successful
            execution_time: Time taken to execute
            metadata: Additional metadata dictionary
            response_data: Response data structure
            
        Returns:
            tuple: (record_id, conversation_id)
        """
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                try:
                    # Base insert data
                    insert_data = {
                        'user_id': str(user_id),
                        'query': query.strip(),
                        'sql_query': str(sql_query) if sql_query is not None else None,
                        'result_count': int(result_count),
                        'success': bool(success),
                        'execution_time': float(execution_time),
                    }

                    # Handle metadata
                    if metadata is None:
                        metadata = {}
                    insert_data['metadata'] = json.dumps(metadata, ensure_ascii=False)

                    # Handle response_data with comprehensive normalization
                    if response_data is None:
                        response_data = {'data': []}

                    if isinstance(response_data, dict) and 'data' in response_data:
                        prepared_response = response_data
                    else:
                        prepared_response = {'data': []}
                        if isinstance(response_data, list):
                            for item in response_data:
                                if isinstance(item, dict) and 'type' in item and 'content' in item:
                                    prepared_response['data'].append(item)
                                else:
                                    prepared_response['data'].append({
                                        'type': 'text',
                                        'content': {'html': str(item)}
                                    })
                        else:
                            prepared_response['data'].append({
                                'type': 'text',
                                'content': {'html': str(response_data)}
                            })

                    # Normalize each data item
                    for item in prepared_response['data']:
                        if not isinstance(item, dict):
                            item = {'type': 'text', 'content': {'html': str(item)}}
                        if 'type' not in item:
                            item['type'] = 'text'
                        if 'content' not in item:
                            item['content'] = {'html': ''}

                        # Ensure table format
                        if item['type'] == 'table':
                            if 'headers' not in item['content']:
                                item['content']['headers'] = []
                            if 'rows' not in item['content']:
                                item['content']['rows'] = []

                        # Ensure chart format
                        if item['type'] == 'chart':
                            if 'chart_type' not in item['content']:
                                item['content']['chart_type'] = 'bar'
                            if 'data' not in item['content']:
                                item['content']['data'] = {'labels': [], 'datasets': []}
                            if 'options' not in item['content']:
                                item['content']['options'] = {
                                    'responsive': True,
                                    'maintainAspectRatio': False,
                                    'plugins': {
                                        'legend': {'position': 'top'},
                                        'title': {'display': True, 'text': item.get('title', 'Chart')}
                                    }
                                }

                    insert_data['response_data'] = json.dumps(prepared_response, ensure_ascii=False)

                    # **INTEGRATED: Proper conversation_id handling logic**
                    if conversation_id and conversation_id.strip():
                        # Use provided conversation_id for continuing conversations
                        insert_data['conversation_id'] = conversation_id
                        cursor.execute("""
                            INSERT INTO user_conversations 
                            (conversation_id, user_id, query, sql_query, result_count, success, 
                            execution_time, metadata, response_data)
                            VALUES (%(conversation_id)s, %(user_id)s, %(query)s, %(sql_query)s, 
                                    %(result_count)s, %(success)s, %(execution_time)s, 
                                    %(metadata)s, %(response_data)s)
                            RETURNING id, conversation_id
                        """, insert_data)
                        
                        logger.info(f"Storing message in existing conversation: {conversation_id}")
                    else:
                        # Let database generate new conversation_id for new conversations
                        cursor.execute("""
                            INSERT INTO user_conversations 
                            (user_id, query, sql_query, result_count, success, 
                            execution_time, metadata, response_data)
                            VALUES (%(user_id)s, %(query)s, %(sql_query)s, %(result_count)s, 
                                    %(success)s, %(execution_time)s, %(metadata)s, %(response_data)s)
                            RETURNING id, conversation_id
                        """, insert_data)
                        
                        logger.info(f"Creating new conversation for user: {user_id}")

                    result = cursor.fetchone()
                    conn.commit()
                    
                    record_id, returned_conversation_id = result[0], str(result[1])
                    logger.info(f"Stored conversation record {record_id} in conversation {returned_conversation_id}")
                    
                    return record_id, returned_conversation_id

                except Exception as e:
                    conn.rollback()
                    logger.error(f"Failed to store conversation for user {user_id}: {str(e)}")
                    logger.error(f"Query: {query[:100]}...")
                    raise

    
    def get_similar_queries(self, user_id, query, limit=5):
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT query, sql_query, result_count, success, timestamp, conversation_id
                    FROM user_conversations
                    WHERE user_id = %s AND success = TRUE AND sql_query IS NOT NULL
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, (user_id, limit))
                return cursor.fetchall()
    
    def get_user_conversations_grouped(self, user_id, limit=10, offset=0):
        """Get conversations grouped by conversation_id"""
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                try:
                    # First check if conversation_id column exists
                    cur.execute("""
                        SELECT column_name 
                        FROM information_schema.columns 
                        WHERE table_name = 'user_conversations' 
                        AND column_name = 'conversation_id'
                    """)
                    
                    has_conversation_id = cur.fetchone() is not None
                    
                    if has_conversation_id:
                        # New schema with conversation_id
                        cur.execute("""
                            SELECT conversation_id, 
                                MIN(timestamp) as first_message_time,
                                MAX(timestamp) as last_message_time,
                                COUNT(*) as message_count,
                                array_to_string(array_agg(query ORDER BY timestamp), ' | ') as preview_queries
                            FROM user_conversations 
                            WHERE user_id = %s 
                            GROUP BY conversation_id 
                            ORDER BY MAX(timestamp) DESC 
                            LIMIT %s OFFSET %s
                        """, (user_id, limit, offset))
                    else:
                        # Old schema without conversation_id - treat each row as separate conversation
                        cur.execute("""
                            SELECT id as conversation_id,
                                timestamp as first_message_time,
                                timestamp as last_message_time,
                                1 as message_count,
                                query as preview_queries
                            FROM user_conversations 
                            WHERE user_id = %s 
                            ORDER BY timestamp DESC 
                            LIMIT %s OFFSET %s
                        """, (user_id, limit, offset))
                    
                    return cur.fetchall()
                    
                except Exception as e:
                    logger.error(f"Error in get_user_conversations_grouped: {str(e)}")
                    # Fallback to simple query
                    cur.execute("""
                        SELECT id as conversation_id,
                            timestamp as first_message_time,
                            timestamp as last_message_time,
                            1 as message_count,
                            query as preview_queries
                        FROM user_conversations 
                        WHERE user_id = %s 
                        ORDER BY timestamp DESC 
                        LIMIT %s OFFSET %s
                    """, (user_id, limit, offset))
                    
                    return cur.fetchall()
    def get_or_create_active_conversation(self, user_id):
        """Get user's active conversation_id or create new one"""
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                # Check if user has an active conversation
                cursor.execute("""
                    SELECT conversation_id FROM user_active_sessions 
                    WHERE user_id = %s
                """, (user_id,))
                
                result = cursor.fetchone()
                if result:
                    return str(result[0])
                
                # No active session, create new conversation_id
                from uuid import uuid4
                new_conversation_id = str(uuid4())
                cursor.execute("""
                    INSERT INTO user_active_sessions (user_id, conversation_id, created_at)
                    VALUES (%s, %s, NOW())
                """, (user_id, new_conversation_id))
                
                conn.commit()
                logger.info(f"Created new active conversation {new_conversation_id} for user {user_id}")
                return new_conversation_id

    def create_new_conversation_for_user(self, user_id):
        """Create new conversation when user clicks 'New Chat'"""
        from uuid import uuid4
        new_conversation_id = str(uuid4())
        
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO user_active_sessions (user_id, conversation_id, created_at)
                    VALUES (%s, %s, NOW())
                    ON CONFLICT (user_id) 
                    DO UPDATE SET conversation_id = %s, created_at = NOW()
                """, (user_id, new_conversation_id, new_conversation_id))
                
                conn.commit()
                logger.info(f"Created NEW conversation {new_conversation_id} for user {user_id}")
                return new_conversation_id

    def set_active_conversation(self, user_id, conversation_id):
        """Set a specific conversation as active for the user (when clicking on old chat)"""
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                # Verify the conversation belongs to this user
                cursor.execute("""
                    SELECT COUNT(*) FROM user_conversations 
                    WHERE user_id = %s AND conversation_id = %s
                """, (user_id, conversation_id))
                
                if cursor.fetchone()[0] == 0:
                    raise ValueError(f"Conversation {conversation_id} not found for user {user_id}")
                
                # Set this conversation as active
                cursor.execute("""
                    INSERT INTO user_active_sessions (user_id, conversation_id, created_at)
                    VALUES (%s, %s, NOW())
                    ON CONFLICT (user_id) 
                    DO UPDATE SET conversation_id = %s, created_at = NOW()
                """, (user_id, conversation_id, conversation_id))
                
                conn.commit()
                logger.info(f"Reactivated conversation {conversation_id} for user {user_id}")
                return conversation_id
    def get_conversation_messages(self, conversation_id, limit=50, offset=0):
        """
        Get all messages in a specific conversation with proper formatting
        """
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT id, user_id, query, sql_query, result_count,
                        execution_time, success, timestamp, metadata, response_data
                    FROM user_conversations
                    WHERE conversation_id = %s
                    ORDER BY timestamp ASC
                    LIMIT %s OFFSET %s
                """, (conversation_id, limit, offset))
                
                messages = []
                for row in cur.fetchall():
                    # Parse metadata
                    metadata = {}
                    if row['metadata']:
                        try:
                            metadata = json.loads(row['metadata']) if isinstance(row['metadata'], str) else row['metadata']
                        except (json.JSONDecodeError, TypeError) as e:
                            logger.warning(f"Failed to parse metadata: {e}")
                            metadata = {'parse_error': str(e)}
                    
                    # Parse response_data
                    response_data = row.get('response_data', {})
                    if isinstance(response_data, str):
                        try:
                            response_data = json.loads(response_data)
                        except (json.JSONDecodeError, TypeError):
                            response_data = {'data': [{'type': 'text', 'content': {'html': str(response_data)}}]}
                    
                    # Ensure response_data has proper structure
                    if not isinstance(response_data, dict):
                        response_data = {'data': [{'type': 'text', 'content': {'html': str(response_data)}}]}
                    
                    if 'data' not in response_data:
                        response_data = {'data': []}
                    
                    timestamp = row['timestamp'].isoformat() if isinstance(row['timestamp'], datetime) else row['timestamp']
                    
                    message = {
                        'id': row['id'],
                        'user_id': row['user_id'],
                        'query': row['query'],
                        'sql_query': row['sql_query'],
                        'result_count': row['result_count'],
                        'execution_time': row['execution_time'],
                        'success': row['success'],
                        'timestamp': timestamp,
                        'metadata': metadata,
                        'response_data': response_data
                    }
                    
                    messages.append(message)
                
                return messages
    
    def get_user_conversations(self, user_id, limit=10, offset=0):
        """
        Retrieve paginated conversations with proper handling of response data and chart reconstruction.
        This method maintains backward compatibility while supporting conversation grouping.
        """
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                # Get paginated conversations
                cur.execute("""
                    SELECT id, conversation_id, user_id, query, sql_query, result_count,
                        execution_time, success, timestamp, metadata,
                        response_data
                    FROM user_conversations
                    WHERE user_id = %s
                    ORDER BY timestamp DESC
                    LIMIT %s OFFSET %s
                """, (user_id, limit, offset))
                
                conversations = []
                for row in cur.fetchall():
                    # Parse metadata
                    metadata = {}
                    if row['metadata']:
                        try:
                            metadata = json.loads(row['metadata']) if isinstance(row['metadata'], str) else row['metadata']
                        except (json.JSONDecodeError, TypeError) as e:
                            logger.warning(f"Failed to parse metadata: {e}")
                            metadata = {'parse_error': str(e)}
                    
                    # Parse response_data
                    response_data = row.get('response_data', {})
                    if isinstance(response_data, str):
                        try:
                            response_data = json.loads(response_data)
                        except (json.JSONDecodeError, TypeError):
                            response_data = {'data': [{'type': 'text', 'content': {'html': str(response_data)}}]}
                    
                    # Ensure response_data has proper structure
                    if not isinstance(response_data, dict):
                        response_data = {'data': [{'type': 'text', 'content': {'html': str(response_data)}}]}
                    
                    # Handle different response data formats
                    if 'data' not in response_data:
                        # Check if this is the old format with sql/query keys
                        if 'sql' in response_data and 'query' in response_data:
                            # This is the new format but missing 'data' array
                            response_data = {'data': response_data.get('data', [])}
                        else:
                            # This is the old format, convert it
                            response_data = {'data': [{
                                'type': 'text',
                                'content': {'html': f"<p>Query: {row['query']}</p><p>SQL: {row['sql_query']}</p>"}
                            }]}
                    
                    # Build chat history items
                    timestamp = row['timestamp'].isoformat() if isinstance(row['timestamp'], datetime) else row['timestamp']
                    
                    conversation = {
                        'id': row['id'],
                        'conversation_id': row['conversation_id'],  # Added conversation_id
                        'user_id': row['user_id'],
                        'query': row['query'],
                        'sql_query': row['sql_query'],
                        'result_count': row['result_count'],
                        'execution_time': row['execution_time'],
                        'success': row['success'],
                        'timestamp': timestamp,
                        'metadata': metadata,
                        'response_data': response_data,
                        'chat_history': [
                            {
                                "role": "user",
                                "content": row['query'],
                                "timestamp": timestamp,
                                "source": "knowledge_base",
                                "conversation_id": row['conversation_id'],
                                "message_id": row['id']
                            }
                        ]
                    }
                    
                    # Process each data item in the response
                    html_parts = []
                    for item in response_data['data']:
                        if item['type'] == 'text' and 'content' in item and 'html' in item['content']:
                            html_parts.append(item['content']['html'])
                        elif item['type'] == 'table' and 'content' in item:
                            # Generate HTML table
                            table_content = item['content']
                            if 'headers' in table_content and 'rows' in table_content:
                                table_html = "<table class='result-table' style='width: 100%; border-collapse: collapse; margin: 20px 0;'>"
                                table_html += "<thead><tr style='background-color: #f8f9fa;'>"
                                table_html += "".join(f"<th style='border: 1px solid #dee2e6; padding: 12px; text-align: left; font-weight: bold;'>{h}</th>" for h in table_content['headers'])
                                table_html += "</tr></thead><tbody>"
                                table_html += "".join(
                                    "<tr style='border-bottom: 1px solid #dee2e6;'>" + 
                                    "".join(f"<td style='border: 1px solid #dee2e6; padding: 12px;'>{cell}</td>" for cell in row_data) + 
                                    "</tr>"
                                    for row_data in table_content['rows']
                                )
                                table_html += "</tbody></table>"
                                html_parts.append(table_html)
                        elif item['type'] == 'chart' and 'content' in item:
                            # Generate chart HTML with proper Chart.js integration
                            canvas_id = f"chart_{row['id']}_{len(html_parts)}"
                            chart_content = item.get('content', {})
                            chart_title = item.get('title', 'Chart')
                            
                            # Ensure chart has all required properties
                            chart_config = {
                                'type': chart_content.get('chart_type', 'bar'),
                                'data': chart_content.get('data', {
                                    'labels': [],
                                    'datasets': []
                                }),
                                'options': chart_content.get('options', {
                                    'responsive': True,
                                    'maintainAspectRatio': False,
                                    'plugins': {
                                        'legend': {
                                            'position': 'top',
                                        },
                                        'title': {
                                            'display': True,
                                            'text': chart_title
                                        }
                                    }
                                })
                            }
                            
                            # Fix options to ensure proper structure
                            if 'options' not in chart_config:
                                chart_config['options'] = {}
                            if 'plugins' not in chart_config['options']:
                                chart_config['options']['plugins'] = {}
                            if 'title' not in chart_config['options']['plugins']:
                                chart_config['options']['plugins']['title'] = {
                                    'display': True,
                                    'text': chart_title
                                }
                            
                            # Convert chart config to JSON string
                            chart_config_json = json.dumps(chart_config)
                            
                            chart_html = f"""
                                <div class='chart-container' style='position: relative; height: 400px; width: 100%; margin: 20px 0; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background: #fafafa;'>
                                    <h4 style='margin: 0 0 15px 0; color: #333; text-align: center;'>{chart_title}</h4>
                                    <div style='position: relative; height: 350px; width: 100%;'>
                                        <canvas id='{canvas_id}' style='max-height: 350px;'></canvas>
                                    </div>
                                    <script>
                                        (function() {{
                                            function initChart() {{
                                                const canvas = document.getElementById('{canvas_id}');
                                                if (canvas && typeof Chart !== 'undefined') {{
                                                    const ctx = canvas.getContext('2d');
                                                    try {{
                                                        new Chart(ctx, {chart_config_json});
                                                    }} catch (error) {{
                                                        console.error('Chart creation error:', error);
                                                        canvas.parentElement.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">Chart could not be displayed</p>';
                                                    }}
                                                }} else if (canvas) {{
                                                    // Chart.js not loaded yet, try again later
                                                    setTimeout(initChart, 100);
                                                }}
                                            }}
                                            
                                            // Try to initialize immediately
                                            if (document.readyState === 'complete') {{
                                                initChart();
                                            }} else {{
                                                document.addEventListener('DOMContentLoaded', initChart);
                                                // Fallback for cases where DOMContentLoaded already fired
                                                setTimeout(initChart, 100);
                                            }}
                                        }})();
                                    </script>
                                </div>
                            """
                            html_parts.append(chart_html)
                    
                    # Add assistant response
                    conversation['chat_history'].append({
                        "role": "assistant",
                        "content": "\n".join(html_parts) if html_parts else "<p>No response content available</p>",
                        "timestamp": timestamp,
                        "source": "knowledge_base",
                        "conversation_id": row['conversation_id'],
                        "message_id": row['id'],
                        "sql_query": row['sql_query'],
                        "result_count": row['result_count'],
                        "success": row['success'],
                        "metadata": metadata
                    })
                    
                    conversations.append(conversation)
                
                return conversations
    
    def get_conversation_count(self, user_id):
        """Get total number of unique conversations for a user"""
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT COUNT(DISTINCT conversation_id) 
                    FROM user_conversations 
                    WHERE user_id = %s
                """, (user_id,))
                return cursor.fetchone()[0]
    
    def delete_conversation(self, conversation_id, user_id):
        """Delete an entire conversation and all its messages"""
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    DELETE FROM user_conversations 
                    WHERE conversation_id = %s AND user_id = %s
                """, (conversation_id, user_id))
                deleted_count = cursor.rowcount
                conn.commit()
                return deleted_count
    
    def update_conversation_metadata(self, conversation_id, user_id, metadata):
        """Update metadata for all messages in a conversation"""
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE user_conversations 
                    SET metadata = %s 
                    WHERE conversation_id = %s AND user_id = %s
                """, (json.dumps(metadata), conversation_id, user_id))
                updated_count = cursor.rowcount
                conn.commit()
                return updated_count
def get_connection_pool():
    # Remove this line: global connection_pool
    try:
        pool = psycopg2.pool.SimpleConnectionPool(
            1, 10,
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT,
            connect_timeout=90,
            application_name="MedicalSQLAssistant"
        )
        logger.info("Connection pool created successfully")
        return pool
    except Exception as e:
        logger.error(f"Connection pool creation failed: {e}")
        raise ValueError(f"Failed to create connection pool: {e}")

def get_postgres_connection():
    global connection_pool
    try:
        if not connection_pool:
            connection_pool = get_connection_pool()
        conn = connection_pool.getconn()
        with conn.cursor() as test_cursor:
            test_cursor.execute("SELECT 1")
        logger.debug("Retrieved and tested connection from pool")
        return conn
    except Exception as e:
        logger.error(f"Connection attempt failed: {e}")
        raise

def close_connection(conn):
    global connection_pool
    try:
        if connection_pool and conn:
            connection_pool.putconn(conn)
            logger.debug("Returned connection to pool")
        elif conn:
            conn.close()
            logger.debug("Closed connection")
    except Exception as e:
        logger.warning(f"Error closing connection: {e}")

def execute_sql(query, params=None):
    start_time = time.time()
    logger.debug(f"Executing SQL query: {query[:200]}...")
    conn = None
    try:
        query_upper = query.strip().upper()
        allowed_system_queries = [
            "SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN"
        ]
        
        if "PG_CONSTRAINT" in query_upper or "INFORMATION_SCHEMA" in query_upper:
            pass
        elif not any(query_upper.startswith(allowed) for allowed in allowed_system_queries):
            raise ValueError("Only SELECT and system catalog queries are allowed")
        
        conn = get_postgres_connection()
        cursor = conn.cursor(cursor_factory=DictCursor)
        cursor.execute(query, params or ())
        results = [dict(row) for row in cursor.fetchall()] if cursor.description else []
        conn.commit()
        logger.debug(f"SQL query executed in {time.time() - start_time:.2f} seconds, returned {len(results)} rows")
        return results
    except Exception as e:
        logger.error(f"SQL execution error: {e}")
        if conn:
            conn.rollback()
        raise
    finally:
        if conn:
            close_connection(conn)

def load_schema_cache():
    try:
        if os.path.exists(SCHEMA_CACHE_FILE):
            with open(SCHEMA_CACHE_FILE, 'r') as f:
                cache_data = json.load(f)
                
                if not isinstance(cache_data, dict) or 'timestamp' not in cache_data or 'schema' not in cache_data:
                    logger.warning("Invalid cache file structure, removing cache")
                    try:
                        os.remove(SCHEMA_CACHE_FILE)
                    except OSError as e:
                        logger.warning(f"Failed to remove invalid schema cache file: {e}")
                    return None
                
                cache_time = datetime.fromisoformat(cache_data['timestamp'])
                if datetime.now() - cache_time < timedelta(seconds=SCHEMA_CACHE_DURATION):
                    logger.info("Using cached schema data")
                    return cache_data['schema']
                else:
                    logger.info("Schema cache expired, will refresh")
                    try:
                        os.remove(SCHEMA_CACHE_FILE)
                    except OSError as e:
                        logger.warning(f"Failed to remove expired schema cache file: {e}")
                    return None
    except Exception as e:
        logger.warning(f"Error loading schema cache: {e}")
        try:
            if os.path.exists(SCHEMA_CACHE_FILE):
                os.remove(SCHEMA_CACHE_FILE)
        except OSError as e:
            logger.warning(f"Failed to remove schema cache file: {e}")
        return None
    return None

def save_schema_cache(schema_info):
    try:
        cache_data = {
            'timestamp': datetime.now().isoformat(),
            'schema': schema_info,
            'version': '1.0'
        }
        with open(SCHEMA_CACHE_FILE, 'w') as f:
            json.dump(cache_data, f, indent=2)
        logger.info("Schema cached successfully")
    except Exception as e:
        logger.warning(f"Error saving schema cache: {e}")

def get_table_schema():
    cached_schema = load_schema_cache()
    if cached_schema:
        return cached_schema
    
    schema_info = {}
    conn = None
    try:
        conn = get_postgres_connection()
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        for table_name in WORKING_TABLES:
            cursor.execute("""
                SELECT column_name, data_type, is_nullable, column_default
                FROM information_schema.columns 
                WHERE table_name = %s AND table_schema = 'public'
                ORDER BY ordinal_position
            """, (table_name,))
            columns = cursor.fetchall()
            
            if not columns:
                logger.warning(f"No columns found for table: {table_name}")
                continue
            
            cursor.execute("""
                SELECT column_name
                FROM information_schema.key_column_usage k
                JOIN information_schema.table_constraints t
                ON k.constraint_name = t.constraint_name
                WHERE t.table_name = %s AND t.constraint_type = 'PRIMARY KEY'
            """, (table_name,))
            primary_keys = [row[0] for row in cursor.fetchall()]
            
            cursor.execute("""
                SELECT kcu.column_name as from_column, ccu.table_name as to_table, ccu.column_name as to_column
                FROM information_schema.key_column_usage kcu
                JOIN information_schema.referential_constraints rc 
                    ON kcu.constraint_name = rc.constraint_name
                JOIN information_schema.constraint_column_usage ccu 
                    ON rc.unique_constraint_name = ccu.constraint_name
                WHERE kcu.table_name = %s
            """, (table_name,))
            foreign_keys = cursor.fetchall()
            
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = cursor.fetchone()[0]
            
            schema_info[table_name] = {
                "columns": [
                    {
                        "name": col["column_name"],
                        "type": col["data_type"],
                        "nullable": col["is_nullable"] == "YES",
                        "default_value": col["column_default"],
                        "primary_key": col["column_name"] in primary_keys
                    } for col in columns
                ],
                "foreign_keys": [
                    {
                        "from": fk["from_column"],
                        "to_table": fk["to_table"],
                        "to_column": fk["to_column"]
                    } for fk in foreign_keys
                ],
                "row_count": row_count
            }
        
        save_schema_cache(schema_info)
        logger.info(f"Schema loaded successfully for {len(schema_info)} tables")
        return schema_info
        
    except Exception as e:
        logger.error(f"Error getting table schema: {str(e)}")
        return {}
    finally:
        if conn:
            close_connection(conn)
            
# Initialize connection_pool at module level for import
connection_pool = None

def initialize_connection_pool():
    global connection_pool
    if connection_pool is None:
        connection_pool = get_connection_pool()
    return connection_pool