# sigmatic-ai-agent
agent for sigmatic

#This code need to deploy on the server based on client access or client requirements we need ui ux for design and the full stack team need to design the frontend or connect our end point to the 
