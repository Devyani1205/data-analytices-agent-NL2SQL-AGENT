# shared.py
import logging
from agno.memory.v2.memory import Memory
from agno.memory.v2.db.postgres import PostgresMemoryDb

# Initialize logger shared
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from config import (
    LOG_USER_ID, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    GROQ_API_KEY, DB_URL, OPENAI_API_KEY, AWS_ACCESS_KEY_ID, 
    AWS_SECRET_ACCESS_KEY, BEDROCK_REGION
)

# Initialize memory (you'll need to pass DB_URL or configure it)
memory_db = PostgresMemoryDb(
    table_name="user_memories",
    db_url = f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)
memory = Memory(db=memory_db)

# # Shared variables
# active_sessions = {}  # Track active sessions per user

def log_user_conversations(user_id):
    if not user_id or not memory:
        logger.warning("No user_id provided or memory not initialized")
        return
    
    memories = memory.get_user_memories(user_id=user_id)
    if not memories:
        logger.info(f"No conversations found for user {user_id}")
        return
    
    logger.info(f"--- Conversations for user {user_id} ---")
    for i, mem in enumerate(memories, 1):
        logger.info(f"Conversation {i}:")
        logger.info(f"  Memory: {mem.memory}")
        logger.info(f"  Topics: {mem.topics}")
        logger.info("-" * 40)
    logger.info(f"Total conversations logged for user {user_id}: {len(memories)}")