import os
from dotenv import load_dotenv

# Load environment variables from sqlagent.env file
load_dotenv("sqlagent.env") 


# PostgreSQL connection parameters
DB_NAME = os.getenv("DB_NAME", "dev_database")
DB_USER = os.getenv("DB_USER", "master_user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "DB_PASSWORD")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
LOG_USER_ID = os.getenv("LOG_USER_ID")
DB_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# API Keys
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
LOG_USER_ID = os.getenv("LOG_USER_ID", "agent@sigmatic.ai")

# AWS Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
BEDROCK_REGION = os.getenv("BEDROCK_REGION", "us-east-2")
BEDROCK_INFERENCE_PROFILE_ARN = os.getenv("BEDROCK_INFERENCE_PROFILE_ARN")
BEDROCK_INFERENCE_PROFILE_ARN_llama = os.getenv("BEDROCK_INFERENCE_PROFILE_ARN_llama")
BEDROCK_INFERENCE_PROFILE_ARN3 = os.getenv("BEDROCK_INFERENCE_PROFILE_ARN3")
BEDROCK_INFERENCE_PROFILE_ARNr = os.getenv("BEDROCK_INFERENCE_PROFILE_ARNr")


# globals.py
knowledge_base = None
memory_db = None
memory = None
connection_pool = None
session_storage = None
active_sessions = {}