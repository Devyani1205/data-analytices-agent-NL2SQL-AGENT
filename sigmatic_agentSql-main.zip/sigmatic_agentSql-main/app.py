import os
import logging
import json
import time
from uuid import uuid4
from datetime import datetime
from contextlib import contextmanager, asynccontextmanager



from fastapi import FastAPI, HTTPException, Request, Query
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

import socketio
import uvicorn
from textwrap import dedent
from rich.pretty import pprint
from dotenv import load_dotenv

from agno.memory.v2.memory import Memory
from agno.memory.v2.db.postgres import PostgresMemoryDb

from agno.storage.postgres import PostgresStorage

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# Import from all lower levels
from config import memory, active_sessions
from processing import (
    create_chart_html,
    merge_options,
    create_fallback_content,
    create_table_html,format_financial_value
)

from database import execute_sql, get_connection_pool,KnowledgeBase

from config import (
    LOG_USER_ID, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    GROQ_API_KEY, DB_URL, OPENAI_API_KEY, AWS_ACCESS_KEY_ID,
    AWS_SECRET_ACCESS_KEY, BEDROCK_REGION
)



def log_user_conversations(user_id):
    if not user_id or not memory:
        logger.warning("No user_id provided or memory not initialized")
        return
    
    memories = memory.get_user_memories(user_id=user_id)
    if not memories:
        logger.info(f"No conversations found for user {user_id}")
        return
    
    logger.info(f"--- Conversations for user {user_id} ---")
    for i, mem in enumerate(memories, 1):
        logger.info(f"Conversation {i}:")
        logger.info(f"  Memory: {mem.memory}")
        logger.info(f"  Topics: {mem.topics}")
        logger.info("-" * 40)
    logger.info(f"Total conversations logged for user {user_id}: {len(memories)}")
    

@asynccontextmanager
async def lifespan(app: FastAPI):
    global memory_db, memory, knowledge_base, session_storage
    try:
        # Initialize PostgreSQL memory database
        memory_db = PostgresMemoryDb(
            table_name="user_memories",
            db_url=DB_URL
        )
        memory = Memory(db=memory_db)
        
        knowledge_base = KnowledgeBase(db_url=DB_URL)
        session_storage = PostgresStorage(
            table_name="agent_sessions",
            db_url=DB_URL
        )
        
        # Initialize connection pool during startup
        from database import initialize_connection_pool
        initialize_connection_pool()
        
        # UPDATE CONFIG.PY GLOBALS
        import config
        config.memory_db = memory_db
        config.memory = memory
        config.knowledge_base = knowledge_base
        config.session_storage = session_storage
        
        logger.info("Application startup completed")
        yield
    finally:
        if LOG_USER_ID:
            log_user_conversations(LOG_USER_ID)
        
        # Import and close connection pool
        from database import connection_pool
        if connection_pool:
            connection_pool.closeall()
            logger.info("Connection pool closed")
        logger.info("Application shutdown completed")
        
    
app = FastAPI(
    title="Medical SQL Assistant",
    description="Natural Language to SQL Query System for Medical Practice Data",
    version="1.0.0",
    lifespan=lifespan
)

@app.get("/agent/api")
async def read_agent_api():
    return {
        "message": "Agent API is working",
        "endpoints": {
            "query": "/agent/api/query (POST)",
            "memories": "/agent/api/memories/{user_id} (GET)",
            "chat_history": "/agent/api/chat-history/{user_id} (GET)",
            "user_memories": "/agent/api/user-memories/{user_id} (GET)",
            "clear_session": "/agent/api/clear-session/{user_id} (DELETE)"
        },
        "status": "healthy"
    }

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

app.mount("/static", StaticFiles(directory=os.path.dirname(os.path.abspath(__file__))), name="static")

sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins='*',
    logger=True,
    engineio_logger=True
)
socket_app = socketio.ASGIApp(sio, app)



# @app.get("/agent/api/chat-history/{user_id}")
# async def get_chat_history_api(
#     user_id: str,
#     page: int = Query(1, ge=1, description="Page number (1-indexed)"),
#     per_page: int = Query(20, ge=1, le=100, description="Items per page"),
#     format: str = Query("html", description="Response format: json or html"),
#     include_charts: bool = Query(True, description="Include chart data in response")
# ):
#     """
#     Enhanced REST API endpoint to retrieve chat history with proper chart rendering
#     """
#     try:
#         # Validate user_id
#         if not user_id or len(user_id.strip()) == 0:
#             raise HTTPException(status_code=400, detail="User ID is required and cannot be empty")
        
#         # Get total count for pagination
#         with knowledge_base.get_connection() as conn:
#             with conn.cursor() as cursor:
#                 cursor.execute(
#                     "SELECT COUNT(*) FROM user_conversations WHERE user_id = %s", 
#                     (user_id,)
#                 )
#                 total_count = cursor.fetchone()[0]
        
#         # Calculate pagination parameters
#         total_pages = (total_count + per_page - 1) // per_page
#         offset = (page - 1) * per_page
        
#         # Validate page number
#         if page > total_pages and total_count > 0:
#             raise HTTPException(
#                 status_code=404, 
#                 detail=f"Page {page} not found. Total pages: {total_pages}"
#             )
        
#         # Get conversations from knowledge base
#         kb_conversations = knowledge_base.get_user_conversations(
#             user_id, 
#             limit=per_page, 
#             offset=offset
#         )
        
#         chat_history = []
#         chart_count = 0
        
#         for conv in kb_conversations:
#             # Add user message
#             user_message = {
#                 "role": "user",
#                 "content": conv['query'],
#                 "timestamp": conv['timestamp'],
#                 "source": "knowledge_base",
#                 "conversation_id": conv['id']
#             }
#             chat_history.append(user_message)
            
#             # Process response data
#             response_data = conv.get('response_data', {})
            
#             # Ensure proper structure
#             if isinstance(response_data, str):
#                 try:
#                     response_data = json.loads(response_data)
#                 except (json.JSONDecodeError, TypeError):
#                     response_data = {'data': []}
            
#             if not isinstance(response_data, dict) or 'data' not in response_data:
#                 response_data = {'data': []}
            
#             # Process each data item based on format
#             html_parts = []
#             chart_data = []
            
#             for item_index, item in enumerate(response_data.get('data', [])):
#                 try:
#                     if item.get('type') == 'text' and 'content' in item:
#                         if format == "html" and 'html' in item['content']:
#                             html_parts.append(item['content']['html'])
#                         elif format == "json":
#                             html_parts.append(item['content'].get('text', item['content'].get('html', '')))
                    
#                     elif item.get('type') == 'table' and 'content' in item:
#                         table_content = item['content']
#                         if format == "html" and 'headers' in table_content and 'rows' in table_content:
#                             table_html = create_table_html(table_content['headers'], table_content['rows'])
#                             html_parts.append(table_html)
#                         elif format == "json":
#                             html_parts.append(f"Table: {len(table_content.get('rows', []))} rows")
                    
#                     elif item.get('type') == 'chart' and 'content' in item:
#                         chart_count += 1
#                         if include_charts and format == "html":
#                             # Generate unique ID for API charts
#                             unique_id = f"api_chart_{conv['id']}_{item_index}_{int(time.time() * 1000)}_{chart_count}"
#                             chart_html = create_chart_html(item, unique_id, conv['id'])
#                             html_parts.append(chart_html)
#                         elif include_charts and format == "json":
#                             # Return complete chart configuration for JSON format
#                             chart_data.append({
#                                 'type': 'chart',
#                                 'title': item.get('title', 'Chart'),
#                                 'chart_type': item['content'].get('chart_type'),
#                                 'data': {
#                                     'labels': item['content'].get('data', {}).get('labels', []),
#                                     'datasets': [{
#                                         'label': ds.get('label', 'Dataset'),
#                                         'data': ds.get('data', [])
#                                     } for ds in item['content'].get('data', {}).get('datasets', [])]
#                                 },
#                                 'options': item['content'].get('options', {})
#                             })
#                         else:
#                             html_parts.append(f"📊 Chart: {item.get('title', 'Visualization')}")
                            
#                 except Exception as item_error:
#                     logger.error(f"Error processing item {item_index} for conversation {conv['id']}: {item_error}")
#                     if format == "html":
#                         html_parts.append(f"<p style='color: #dc3545;'>Error loading content item {item_index + 1}</p>")
#                     else:
#                         html_parts.append(f"Error loading content item {item_index + 1}")
            
#             # Create assistant response
#             if format == "html":
#                 assistant_content = "\n".join(html_parts) if html_parts else create_fallback_content(conv)
#             else:
#                 assistant_content = {
#                     'text': "\n".join(html_parts) if html_parts else f"Query: {conv['query']}",
#                     'charts': chart_data if include_charts else []
#                 }
            
#             assistant_message = {
#                 "role": "assistant",
#                 "content": assistant_content,
#                 "timestamp": conv['timestamp'],
#                 "source": "knowledge_base",
#                 "conversation_id": conv['id'],
#                 "sql_query": conv.get('sql_query'),
#                 "result_count": conv.get('result_count'),
#                 "success": conv.get('success', False),
#                 "execution_time": conv.get('execution_time', 0),
#                 "metadata": conv.get('metadata', {}),
#                 "has_charts": any(item.get('type') == 'chart' for item in response_data.get('data', []))
#             }
#             chat_history.append(assistant_message)
        
#         # Sort by timestamp (newest first)
#         chat_history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
#         # Prepare response
#         response_data = {
#             'success': True,
#             'user_id': user_id,
#             'chat_history': chat_history,
#             'pagination': {
#                 'page': page,
#                 'per_page': per_page,
#                 'total_pages': total_pages,
#                 'total_items': total_count,
#                 'has_next': page < total_pages,
#                 'has_prev': page > 1
#             },
#             'metadata': {
#                 'format': format,
#                 'include_charts': include_charts,
#                 'chart_count': chart_count,
#                 'conversation_count': len(kb_conversations),
#                 'total_messages': len(chat_history)
#             },
#             'timestamp': datetime.now().isoformat()
#         }
        
#         return response_data
        
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"API chat history error: {str(e)}", exc_info=True)
#         raise HTTPException(
#             status_code=500, 
#             detail={
#                 'error': 'Internal server error',
#                 'message': 'Failed to retrieve chat history',
#                 'details': str(e)
#             }
#         )
        

@sio.event
async def clear_session(sid, data):
    try:
        user_id = data.get('user_id')
        if not user_id:
            await sio.emit('clear_session_error', {'error': 'User ID is required'}, to=sid)
            return
        
        session_id = active_sessions.get(user_id)
        if session_id:
            if session_id in memory.runs:
                del memory.runs[session_id]
            del active_sessions[user_id]
            memory.clear()


        
        await sio.emit('clear_session_result', {
            'success': True,
            'message': f'Session cleared for user {user_id}'
        }, to=sid)
        
    except Exception as e:
        logger.error(f"Socket clear session error: {str(e)}")
        await sio.emit('clear_session_error', {'error': str(e)}, to=sid)

@app.get("/")
async def root():
    return FileResponse(os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html"))

@app.get("/favicon.ico")
async def favicon():
    favicon_svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <rect width="100" height="100" fill="#007bff"/>
        <text x="50" y="65" font-family="Arial, sans-serif" font-size="50" text-anchor="middle" fill="white">🏥</text>
    </svg>"""
    return Response(content=favicon_svg, media_type="image/svg+xml")

@app.get("/robots.txt")
async def robots():
    robots_content = """User-agent: *
Disallow: /

# This application is for internal use only
# No crawling allowed"""
    return Response(content=robots_content, media_type="text/plain")

@app.post("/agent/api/query")
async def query_endpoint(request: Request):
    try:
        data = await request.json()
        query = data.get("query")
        user_id = data.get("user_id")
        conversation_id = data.get("conversation_id")  # ADD THIS LINE
        
        if not query:
            raise HTTPException(status_code=400, detail="Query is required")
        from agent import sql_agent
        result = await sql_agent(query, user_id, conversation_id)  # PASS conversation_id
        return JSONResponse(content=result)
    except Exception as e:
        logger.error(f"API query error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    #New Conversation API Endpoint
@app.post("/agent/api/new-conversation")
async def create_new_conversation(request: Request):
    try:
        data = await request.json()
        user_id = data.get("user_id")
        
        if not user_id:
            raise HTTPException(status_code=400, detail="User ID is required")
        
        # Create new conversation for user (this will be their active conversation)
        conversation_id = knowledge_base.create_new_conversation_for_user(user_id)
        
        return JSONResponse(content={
            "success": True,
            "conversation_id": conversation_id,
            "user_id": user_id,
            "message": "New conversation created and set as active"
        })
        
    except Exception as e:
        logger.error(f"New conversation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/agent/api/switch-conversation")
async def switch_to_conversation(request: Request):
    """Switch to an existing conversation (when user clicks on old chat)"""
    try:
        data = await request.json()
        user_id = data.get("user_id")
        conversation_id = data.get("conversation_id")
        
        if not user_id or not conversation_id:
            raise HTTPException(status_code=400, detail="User ID and Conversation ID are required")
        
        # Set this conversation as active
        active_conversation_id = knowledge_base.set_active_conversation(user_id, conversation_id)
        
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "active_conversation_id": active_conversation_id,
            "message": f"Switched to conversation {conversation_id}"
        })
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Switch conversation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/agent/api/active-conversation/{user_id}")
async def get_active_conversation(user_id: str):
    """Get user's current active conversation_id"""
    try:
        conversation_id = knowledge_base.get_or_create_active_conversation(user_id)
        
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "active_conversation_id": conversation_id
        })
        
    except Exception as e:
        logger.error(f"Get active conversation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/agent/api/conversations/{user_id}")
async def get_user_conversations_list(user_id: str):
    """Get list of conversations for a user"""
    try:
        if not user_id:
            raise HTTPException(status_code=400, detail="User ID is required")
            
        conversations = knowledge_base.get_user_conversations_grouped(user_id)
        
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "conversations": [
                {
                    "conversation_id": str(conv['conversation_id']),
                    "first_message_time": conv['first_message_time'].isoformat() if conv['first_message_time'] else None,
                    "last_message_time": conv['last_message_time'].isoformat() if conv['last_message_time'] else None,
                    "message_count": conv['message_count'],
                    "preview": (conv['preview_queries'][:100] + "...") if conv['preview_queries'] and len(str(conv['preview_queries'])) > 100 else str(conv['preview_queries'])
                }
                for conv in conversations
            ]
        })
    except Exception as e:
        logger.error(f"Get conversations error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500, 
            detail={
                "error": "Failed to load conversations",
                "message": str(e)
            }
        )

@app.get("/agent/api/conversation/{conversation_id}/messages")
async def get_conversation_messages_api(conversation_id: str):
    """Get all messages in a specific conversation"""
    try:
        messages = knowledge_base.get_conversation_messages(conversation_id)
        
        chat_history = []
        chart_count = 0
        
        for msg in messages:
            # Add user message
            chat_history.append({
                "role": "user",
                "content": msg['query'],
                "timestamp": msg['timestamp'].isoformat() if hasattr(msg['timestamp'], 'isoformat') else msg['timestamp'],
                "conversation_id": conversation_id,
                "message_id": msg['id']
            })
            
            # Process response data
            response_data = msg.get('response_data', {})
            if isinstance(response_data, str):
                try:
                    response_data = json.loads(response_data)
                except (json.JSONDecodeError, TypeError):
                    response_data = {'data': []}
            
            if not isinstance(response_data, dict) or 'data' not in response_data:
                response_data = {'data': []}
            
            # Process each data item
            html_parts = []
            for item_index, item in enumerate(response_data.get('data', [])):
                if item.get('type') == 'text' and 'content' in item and 'html' in item['content']:
                    html_parts.append(item['content']['html'])
                
                elif item.get('type') == 'table' and 'content' in item:
                    table_content = item['content']
                    if 'headers' in table_content and 'rows' in table_content:
                        table_html = create_table_html(table_content['headers'], table_content['rows'])
                        html_parts.append(table_html)
                
                elif item.get('type') == 'chart' and 'content' in item:
                    chart_count += 1
                    unique_id = f"conv_chart_{conversation_id}_{item_index}_{int(time.time() * 1000)}"
                    chart_html = create_chart_html(item, unique_id, conversation_id)
                    html_parts.append(chart_html)
            
            # Add assistant response
            assistant_content = "\n".join(html_parts) if html_parts else create_fallback_content(msg)
            
            chat_history.append({
                "role": "assistant",
                "content": assistant_content,
                "timestamp": msg['timestamp'].isoformat() if hasattr(msg['timestamp'], 'isoformat') else msg['timestamp'],
                "conversation_id": conversation_id,
                "message_id": msg['id'],
                "sql_query": msg.get('sql_query'),
                "result_count": msg.get('result_count'),
                "success": msg.get('success', False),
                "execution_time": msg.get('execution_time', 0),
                "metadata": msg.get('metadata', {}),
                "has_charts": any(item.get('type') == 'chart' for item in response_data.get('data', []))
            })
        
        return JSONResponse(content={
            "success": True,
            "conversation_id": conversation_id,
            "messages": chat_history,
            "chart_count": chart_count,
            "total_messages": len(chat_history)
        })
        
    except Exception as e:
        logger.error(f"Get conversation messages error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/agent/api/memories/{user_id}")
async def get_memories(user_id: str):
    try:
        memories = memory.get_user_memories(user_id=user_id)
        logger.info(f"Retrieved memories for user {user_id}:")
        pprint(memories)
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "memories": [{
                "memory": mem.memory,
                "topics": mem.topics,
                "timestamp": mem.timestamp.isoformat() if isinstance(mem.timestamp, datetime) else mem.timestamp
            } for mem in memories]
        })
    except Exception as e:
        logger.error(f"Memory retrieval error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    

@app.delete("/agent/api/conversation/{conversation_id}")
async def delete_conversation(conversation_id: str, user_id: str = Query(...)):
    """Delete an entire conversation"""
    try:
        deleted_count = knowledge_base.delete_conversation(conversation_id, user_id)
        
        return JSONResponse(content={
            "success": True,
            "conversation_id": conversation_id,
            "deleted_messages": deleted_count,
            "message": f"Conversation deleted successfully"
        })
        
    except Exception as e:
        logger.error(f"Delete conversation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    



@sio.event
async def connect(sid, environ):
    logger.info(f"Socket connected: {sid}")
    await sio.emit('connection_success', {'message': 'Connected to SQL Agent'}, to=sid)

@sio.event
async def disconnect(sid):
    logger.info(f"Socket disconnected: {sid}")

@sio.event
async def query(sid, data):
    from agent import sql_agent  # Import here instead
    try:
        query = data.get('query')
        user_id = data.get('user_id')
        conversation_id = data.get('conversation_id')  # Add this parameter
        
        if not query:
            await sio.emit('query_error', {'error': 'Query is required'}, to=sid)
            return
        
        result = await sql_agent(query, user_id, conversation_id)
        await sio.emit('query_result', result, to=sid)
        
    except Exception as e:
        logger.error(f"Socket query error: {str(e)}")
        await sio.emit('query_error', {'error': str(e)}, to=sid)
          
def create_chart_html(item, unique_id, conversation_id):
    """Create robust chart HTML with enhanced error handling"""
    chart_content = item.get('content', {})
    chart_title = item.get('title', 'Data Visualization')
    
    # Validate chart configuration
    if not chart_content or 'chart_type' not in chart_content:
        return f"""
        <div style='text-align: center; color: #666; padding: 40px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6;'>
            <h4 style='margin: 0; color: #6c757d;'> Chart data unavailable</h4>
            <p style='margin: 10px 0 0 0; font-size: 14px;'>The chart configuration could not be loaded.</p>
        </div>
        """
    
    # Build comprehensive chart configuration
    chart_config = {
        'type': chart_content.get('chart_type', 'bar'),
        'data': chart_content.get('data', {'labels': [], 'datasets': []}),
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'legend': {
                    'display': True,
                    'position': 'top'
                },
                'title': {
                    'display': True,
                    'text': chart_title,
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'tooltip': {
                    'enabled': True,
                    'mode': 'index',
                    'intersect': False
                }
            },
            'interaction': {
                'mode': 'nearest',
                'axis': 'x',
                'intersect': False
            }
        }
    }
    
    # Merge existing options
    if 'options' in chart_content:
        merge_options(chart_config['options'], chart_content['options'])
    
    # Add scales for appropriate chart types
    if chart_config['type'] in ['bar', 'line', 'area']:
        if 'scales' not in chart_config['options']:
            chart_config['options']['scales'] = {
                'x': {
                    'beginAtZero': True,
                    'grid': {
                        'display': True,
                        'color': 'rgba(0, 0, 0, 0.1)'
                    }
                },
                'y': {
                    'beginAtZero': True,
                    'grid': {
                        'display': True,
                        'color': 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
    
    # Convert chart config to JSON string with error handling
    try:
        chart_config_json = json.dumps(chart_config, ensure_ascii=False)
    except (TypeError, ValueError) as e:
        logger.error(f"Chart config serialization error: {e}")
        return f"""
        <div style='text-align: center; color: #dc3545; padding: 40px; background: #f8d7da; border-radius: 8px; border: 1px solid #f5c6cb;'>
            <h4 style='margin: 0;'> Chart Configuration Error</h4>
            <p style='margin: 10px 0 0 0; font-size: 14px;'>Unable to serialize chart configuration.</p>
        </div>
        """
    
    # Generate the complete chart HTML
    chart_html = f"""
    <div class='chart-container' style='position: relative; width: 100%; margin: 20px 0; padding: 20px; background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border: 1px solid #e9ecef;'>
        <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #f8f9fa;'>
            <h4 style='margin: 0; color: #495057; font-size: 18px; font-weight: 600;'>
                 {chart_title}
            </h4>
            <div style='display: flex; gap: 10px; align-items: center;'>
                <span style='font-size: 12px; color: #6c757d; background: #f8f9fa; padding: 4px 8px; border-radius: 4px;'>
                    ID: {conversation_id}
                </span>
            </div>
        </div>
        
        <div style='position: relative; height: 400px; width: 100%;'>
            <canvas id='{unique_id}' style='max-height: 400px; width: 100%;'></canvas>
            <div id='{unique_id}_loading' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: #6c757d;'>
                <div style='font-size: 14px;'>Loading chart...</div>
                <div style='margin-top: 10px; font-size: 24px;'></div>
            </div>
            <div id='{unique_id}_error' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: #dc3545; display: none;'>
                <div style='font-size: 14px; font-weight: 500;'> Chart Load Error</div>
                <div style='margin-top: 5px; font-size: 12px;'>Please refresh the page to retry</div>
            </div>
        </div>
        
        <script>
            (function() {{
                const canvasId = '{unique_id}';
                const loadingId = '{unique_id}_loading';
                const errorId = '{unique_id}_error';
                let retryCount = 0;
                const maxRetries = 5;
                
                function hideLoading() {{
                    const loading = document.getElementById(loadingId);
                    if (loading) loading.style.display = 'none';
                }}
                
                function showError() {{
                    hideLoading();
                    const error = document.getElementById(errorId);
                    if (error) error.style.display = 'block';
                }}
                
                function initChart() {{
                    const canvas = document.getElementById(canvasId);
                    if (!canvas) {{
                        console.warn('Canvas not found:', canvasId);
                        return;
                    }}
                    
                    if (typeof Chart === 'undefined') {{
                        if (retryCount < maxRetries) {{
                            retryCount++;
                            console.log(`Chart.js not loaded yet, retry ${{retryCount}}/${{maxRetries}}`);
                            setTimeout(initChart, 200 * retryCount);
                            return;
                        }} else {{
                            console.error('Chart.js failed to load after', maxRetries, 'retries');
                            showError();
                            return;
                        }}
                    }}
                    
                    try {{
                        const ctx = canvas.getContext('2d');
                        const config = {chart_config_json};
                        
                        // Validate configuration
                        if (!config.data || !config.data.labels || !config.data.datasets) {{
                            throw new Error('Invalid chart configuration: missing data structure');
                        }}
                        
                        // Create the chart
                        const chart = new Chart(ctx, config);
                        
                        // Hide loading indicator on success
                        hideLoading();
                        
                        console.log('Chart initialized successfully:', canvasId);
                        
                    }} catch (error) {{
                        console.error('Chart creation error for', canvasId, ':', error);
                        showError();
                    }}
                }}
                
                // Multiple initialization strategies
                if (document.readyState === 'complete') {{
                    initChart();
                }} else {{
                    document.addEventListener('DOMContentLoaded', initChart);
                    // Fallback for cases where DOMContentLoaded already fired
                    setTimeout(initChart, 100);
                }}
                
                // Additional fallback for dynamic content loading
                setTimeout(initChart, 500);
            }})();
        </script>
    </div>
    """
    
    return chart_html


def merge_options(target, source):
    """Recursively merge chart options"""
    for key, value in source.items():
        if key in target and isinstance(target[key], dict) and isinstance(value, dict):
            merge_options(target[key], value)
        else:
            target[key] = value


def create_fallback_content(conv):
    """Create fallback content for conversation display with enhanced styling"""
    query = conv.get('query', '')
    sql_query = conv.get('sql_query', '')
    result_count = conv.get('result_count', 0)
    
    html = f'''
    <div class="conversation-item" style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #6c757d; margin: 10px 0;">
        <h4 style="color: #495057; margin-top: 0; font-size: 16px;">Query Response</h4>
        <p style="margin: 10px 0;"><strong>Query:</strong> {query}</p>
    '''
    
    if sql_query:
        html += f'<p style="margin: 10px 0;"><strong>SQL:</strong> <code style="background: #e9ecef; padding: 2px 4px; border-radius: 3px;">{sql_query}</code></p>'
    
    html += f'<p style="margin: 10px 0 0 0;"><strong>Results:</strong> {result_count} rows</p>'
    html += '</div>'
    
    return html

@sio.event
async def get_chat_history(sid, data):
    """Enhanced socket handler for chat history with robust chart rendering"""
    try:
        user_id = data.get('user_id')
        page = int(data.get('page', 1))
        per_page = int(data.get('per_page', 20))
        
        if not user_id:
            await sio.emit('chat_history_error', {'error': 'User ID is required'}, to=sid)
            return
        
        # Get total count
        with knowledge_base.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM user_conversations WHERE user_id = %s", (user_id,))
                total_count = cursor.fetchone()[0]
        
        # Calculate pagination
        total_pages = (total_count + per_page - 1) // per_page
        offset = (page - 1) * per_page
        
        # Get conversations
        kb_conversations = knowledge_base.get_user_conversations(user_id, limit=per_page, offset=offset)
        
        chat_history = []
        chart_count = 0
        
        for conv in kb_conversations:
            # Add user message
            chat_history.append({
                "role": "user",
                "content": conv['query'],
                "timestamp": conv['timestamp'],
                "source": "knowledge_base",
                "conversation_id": conv['id']
            })
            
            # Process response data with enhanced chart handling
            response_data = conv.get('response_data', {})
            
            # Ensure proper structure
            if isinstance(response_data, str):
                try:
                    response_data = json.loads(response_data)
                except (json.JSONDecodeError, TypeError):
                    response_data = {'data': []}
            
            if not isinstance(response_data, dict) or 'data' not in response_data:
                response_data = {'data': []}
            
            # Process each data item
            html_parts = []
            
            for item_index, item in enumerate(response_data.get('data', [])):
                if item.get('type') == 'text' and 'content' in item and 'html' in item['content']:
                    html_parts.append(item['content']['html'])
                
                elif item.get('type') == 'table' and 'content' in item:
                    table_content = item['content']
                    if 'headers' in table_content and 'rows' in table_content:
                        table_html = create_table_html(table_content['headers'], table_content['rows'])
                        html_parts.append(table_html)
                
                elif item.get('type') == 'chart' and 'content' in item:
                    chart_count += 1
                    unique_id = f"chat_chart_{conv['id']}_{item_index}_{int(time.time() * 1000)}"
                    chart_html = create_chart_html(item, unique_id, conv['id'])
                    html_parts.append(chart_html)
            
            # Add assistant response
            assistant_content = "\n".join(html_parts) if html_parts else create_fallback_content(conv)
            
            chat_history.append({
                "role": "assistant",
                "content": assistant_content,
                "timestamp": conv['timestamp'],
                "source": "knowledge_base",
                "conversation_id": conv['id'],
                "sql_query": conv.get('sql_query'),
                "result_count": conv.get('result_count'),
                "success": conv.get('success', False),
                "metadata": conv.get('metadata', {}),
                "has_charts": any(item.get('type') == 'chart' for item in response_data.get('data', []))
            })
        
        # Sort by timestamp (newest first)
        chat_history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        await sio.emit('chat_history_result', {
            'user_id': user_id,
            'session_id': active_sessions.get(user_id),
            'chat_history': chat_history,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total_pages': total_pages,
                'total_items': total_count
            },
            'message': f'Retrieved {len(chat_history)} messages with {chart_count} charts',
            'chart_count': chart_count
        }, to=sid)
        
    except Exception as e:
        logger.error(f"Socket chat history error: {str(e)}", exc_info=True)
        await sio.emit('chat_history_error', {
            'error': str(e),
            'details': 'Failed to retrieve chat history. Please try again.'
        }, to=sid)



# def create_table_html(headers, rows, financial_columns=None):
#     """Create styled HTML table with currency formatting"""
#     if financial_columns is None:
#         financial_columns = set()
    
#     table_html = """
#     <div style='overflow-x: auto; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
#         <table style='width: 100%; border-collapse: collapse; background: white;'>
#             <thead>
#                 <tr style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'>
#     """
    
#     for header in headers:
#         table_html += f"<th style='padding: 15px 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #dee2e6;'>{header}</th>"
    
#     table_html += "</tr></thead><tbody>"
    
#     for i, row in enumerate(rows):
#         bg_color = '#f8f9fa' if i % 2 == 0 else 'white'
#         table_html += f"<tr style='background: {bg_color}; transition: background-color 0.2s;' onmouseover='this.style.background=\"#e3f2fd\"' onmouseout='this.style.background=\"{bg_color}\"'>"
        
#         for col, cell in zip(headers, row):
#             if col in financial_columns:
#                 formatted_cell = format_financial_value(cell)
#                 table_html += f"<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: #495057; text-align: right;'>{formatted_cell}</td>"
#             else:
#                 table_html += f"<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: #495057;'>{cell}</td>"
        
#         table_html += "</tr>"
    
#     table_html += "</tbody></table></div>"
#     return table_html
        
@sio.event
async def clear_session(sid, data):
    try:
        user_id = data.get('user_id')
        if not user_id:
            await sio.emit('clear_session_error', {'error': 'User ID is required'}, to=sid)
            return
        
        session_id = active_sessions.get(user_id)
        if session_id:
            if session_id in memory.runs:
                del memory.runs[session_id]
            del active_sessions[user_id]
            memory.clear()


        
        await sio.emit('clear_session_result', {
            'success': True,
            'message': f'Session cleared for user {user_id}'
        }, to=sid)
        
    except Exception as e:
        logger.error(f"Socket clear session error: {str(e)}")
        await sio.emit('clear_session_error', {'error': str(e)}, to=sid)

@app.get("/")
async def root():
    return FileResponse(os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html"))

@app.get("/favicon.ico")
async def favicon():
    favicon_svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <rect width="100" height="100" fill="#007bff"/>
        <text x="50" y="65" font-family="Arial, sans-serif" font-size="50" text-anchor="middle" fill="white">🏥</text>
    </svg>"""
    return Response(content=favicon_svg, media_type="image/svg+xml")

@app.get("/robots.txt")
async def robots():
    robots_content = """User-agent: *
Disallow: /

# This application is for internal use only
# No crawling allowed"""
    return Response(content=robots_content, media_type="text/plain")

# @app.post("/agent/api/query")
# async def query_endpoint(request: Request):
#     try:
#         data = await request.json()
#         query = data.get("query")
#         user_id = data.get("user_id")
#         if not query:
#             raise HTTPException(status_code=400, detail="Query is required")
#         result = await sql_agent(query, user_id)
#         return JSONResponse(content=result)
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"API query error: {str(e)}")
#         raise HTTPException(status_code=500, detail=str(e))

@app.get("/agent/api/memories/{user_id}")
async def get_memories(user_id: str):
    try:
        memories = memory.get_user_memories(user_id=user_id)
        logger.info(f"Retrieved memories for user {user_id}:")
        pprint(memories)
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "memories": [{
                "memory": mem.memory,
                "topics": mem.topics,
                "timestamp": mem.timestamp.isoformat() if isinstance(mem.timestamp, datetime) else mem.timestamp
            } for mem in memories]
        })
    except Exception as e:
        logger.error(f"Memory retrieval error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agent/api/chat-history/{user_id}")
async def get_chat_history_api(
    user_id: str,
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    per_page: int = Query(10, ge=1, le=50, description="Conversations per page"),
    format: str = Query("html", description="Response format: json or html")
):
    """
    Get chat history grouped by conversations - ChatGPT style
    Each conversation contains multiple message exchanges
    """
    try:
        if not user_id or len(user_id.strip()) == 0:
            raise HTTPException(status_code=400, detail="User ID is required and cannot be empty")
        
        # Get conversations grouped by conversation_id
        conversations_list = knowledge_base.get_user_conversations_grouped(
            user_id, 
            limit=per_page, 
            offset=(page - 1) * per_page
        )
        
        total_conversations = knowledge_base.get_conversation_count(user_id)
        total_pages = (total_conversations + per_page - 1) // per_page
        
        # Build conversation threads
        conversation_threads = []
        
        for conv_meta in conversations_list:
            conversation_id = str(conv_meta['conversation_id'])
            
            # Get all messages in this conversation
            messages = knowledge_base.get_conversation_messages(conversation_id, limit=100)
            
            # Format messages as alternating user/assistant pairs
            chat_messages = []
            chart_count = 0
            
            for msg in messages:
                # User message
                chat_messages.append({
                    "role": "user",
                    "content": msg['query'],
                    "timestamp": msg['timestamp'] if isinstance(msg['timestamp'], str) else msg['timestamp'].isoformat(),
                    "message_id": msg['id']
                })
                
                # Assistant response - format using existing response structure
                response_content = format_stored_response_for_chat(msg)
                
                # Count charts in this response
                if 'chart-container' in response_content or 'canvas id=' in response_content:
                    chart_count += 1
                
                chat_messages.append({
                    "role": "assistant",
                    "content": response_content,
                    "timestamp": msg['timestamp'] if isinstance(msg['timestamp'], str) else msg['timestamp'].isoformat(),
                    "message_id": msg['id'],
                    "sql_query": msg.get('sql_query'),
                    "result_count": msg.get('result_count', 0),
                    "execution_time": msg.get('execution_time', 0),
                    "success": msg.get('success', False),
                    "metadata": msg.get('metadata', {})
                })
            
            # Create conversation thread
            conversation_thread = {
                "conversation_id": conversation_id,
                "first_message_time": conv_meta['first_message_time'].isoformat() if conv_meta['first_message_time'] else None,
                "last_message_time": conv_meta['last_message_time'].isoformat() if conv_meta['last_message_time'] else None,
                "total_messages": len(chat_messages),
                "query_count": len(messages),
                "preview": conv_meta['preview_queries'][:100] + "..." if len(str(conv_meta['preview_queries'])) > 100 else str(conv_meta['preview_queries']),
                "messages": chat_messages,
                "has_charts": chart_count > 0,
                "chart_count": chart_count
            }
            
            conversation_threads.append(conversation_thread)
        
        return JSONResponse(content={
            'success': True,
            'user_id': user_id,
            'conversation_threads': conversation_threads,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total_pages': total_pages,
                'total_conversations': total_conversations,
                'has_next': page < total_pages,
                'has_prev': page > 1
            },
            'metadata': {
                'format': format,
                'conversation_count': len(conversation_threads),
                'total_messages': sum(thread['total_messages'] for thread in conversation_threads)
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Conversation history error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail={'error': 'Failed to retrieve conversation history', 'details': str(e)})

def format_stored_response_for_chat(msg):
    """
    Format stored response_data for chat display using existing response structure
    This maintains compatibility with your format_response_as_objects output
    """
    response_data = msg.get('response_data', {})
    
    # Parse JSON if stored as string
    if isinstance(response_data, str):
        try:
            response_data = json.loads(response_data)
        except (json.JSONDecodeError, TypeError):
            response_data = {'data': []}
    
    # Ensure proper structure
    if not isinstance(response_data, dict) or 'data' not in response_data:
        return create_fallback_chat_response(msg)
    
    # Process each data item from your response structure
    html_parts = []
    
    for item_index, item in enumerate(response_data.get('data', [])):
        try:
            if item.get('type') == 'text' and 'content' in item:
                # Use existing HTML content from format_response_as_objects
                if 'html' in item['content']:
                    html_parts.append(item['content']['html'])
                else:
                    html_parts.append(f"<p>{item['content']}</p>")
            
            elif item.get('type') == 'table' and 'content' in item:
                # Format table using existing table structure
                table_content = item['content']
                if 'headers' in table_content and 'rows' in table_content:
                    # Use your existing create_table_html function
                    table_html = create_table_html(
                        table_content['headers'], 
                        table_content['rows'],
                        financial_columns=set(table_content.get('financial_columns', []))
                    )
                    html_parts.append(table_html)
            
            elif item.get('type') == 'chart' and 'content' in item:
                # Format chart using existing chart structure
                unique_id = f"chat_chart_{msg['id']}_{item_index}_{int(time.time() * 1000)}"
                chart_html = create_chart_html(item, unique_id, str(msg['id']))
                html_parts.append(chart_html)
            
            elif item.get('type') == 'error' and 'content' in item:
                # Handle error responses
                error_content = item['content']
                if 'html' in error_content:
                    html_parts.append(error_content['html'])
                else:
                    html_parts.append(f"<div style='color: #dc3545; padding: 15px; background: #f8d7da; border-radius: 8px;'>{error_content}</div>")
        
        except Exception as item_error:
            logger.error(f"Error formatting chat item {item_index}: {item_error}")
            html_parts.append(f"<p style='color: #dc3545;'>Error displaying content item {item_index + 1}</p>")
    
    return "\n".join(html_parts) if html_parts else create_fallback_chat_response(msg)

def create_fallback_chat_response(msg):
    """Create fallback response when stored response_data is invalid"""
    return f"""
    <div style='background: #f8f9fa; padding: 15px; border-radius: 8px; border-left: 4px solid #6c757d; margin: 10px 0;'>
        <p><strong>Query:</strong> {msg['query']}</p>
        <p><strong>Results:</strong> {msg.get('result_count', 0)} rows</p>
        {f"<p><strong>Execution Time:</strong> {msg.get('execution_time', 0):.2f}s</p>" if msg.get('execution_time') else ""}
        {f"<details><summary>SQL Query</summary><code style='background: #e9ecef; padding: 10px; border-radius: 4px; display: block; margin-top: 10px;'>{msg.get('sql_query', '')}</code></details>" if msg.get('sql_query') else ""}
    </div>
    """\

@app.get("/agent/api/user-memories/{user_id}")
async def get_user_memories(user_id: str):
    try:
        user_memories = memory.get_user_memories(user_id=user_id)
        
        return JSONResponse(content={
            "success": True,
            "user_id": user_id,
            "user_memories": [{
                "memory": mem.memory,
                "topics": mem.topics,
                "timestamp": mem.timestamp.isoformat() if isinstance(mem.timestamp, datetime) else mem.timestamp
            } for mem in user_memories]
        })
    except Exception as e:
        logger.error(f"User memories retrieval error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/agent/api/clear-session/{user_id}")
async def clear_user_session(user_id: str):
    try:
        session_id = active_sessions.get(user_id)
        if session_id:
            if session_id in memory.runs:
                del memory.runs[session_id]
            del active_sessions[user_id]
            memory.clear()


            
            return JSONResponse(content={
                "success": True,
                "message": f"Session and memories cleared for user {user_id}"
            })
        else:
            return JSONResponse(content={
                "success": True,
                "message": f"No active session found for user {user_id}"
            })
    except Exception as e:
        logger.error(f"Session clearing error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    logger.info("Starting server on 0.0.0.0:8000")
    uvicorn.run(
        socket_app,
        host="0.0.0.0",
        port=8000,
        log_level="debug",
        access_log=True
    )
    
