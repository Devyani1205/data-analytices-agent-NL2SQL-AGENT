import logging
import json
import random
import re
import math
from agno.models.groq import Groq
from agno.agent import Agent
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

from database import execute_sql

def determine_chart_type(query, results):
    """Enhanced inference based on query content and data structure"""
    query_lower = query.lower()
    
    if not results or len(results) == 0:
        return 'bar'
    
    # Analyze data structure
    headers = list(results[0].keys()) if results else []
    numeric_cols = []
    categorical_cols = []
    date_cols = []
    
    # Enhanced column classification
    for col in headers:
        col_lower = col.lower()
        sample_values = [row.get(col) for row in results[:10] if row.get(col) is not None]
        
        if not sample_values:
            continue
            
        # Check for date columns
        if any(term in col_lower for term in ['date', 'time', 'year', 'month', 'day']):
            date_cols.append(col)
        else:
            # Check if numeric
            try:
                numeric_samples = [float(str(val)) for val in sample_values if val is not None]
                if len(numeric_samples) > len(sample_values) * 0.7:  # 70% numeric threshold
                    numeric_cols.append(col)
                else:
                    categorical_cols.append(col)
            except (ValueError, TypeError):
                categorical_cols.append(col)
    
    # Smart chart type selection based on content and structure
    if len(numeric_cols) >= 2:
        # Two or more numeric columns suggest scatter plot for correlation
        if any(term in query_lower for term in ['correlation', 'relationship', 'vs', 'against', 'compare']):
            return 'scatter'
    
    if date_cols or any(term in query_lower for term in ['trend', 'over time', 'timeline', 'progression', 'monthly', 'yearly', 'daily']):
        return 'line'
    
    if any(term in query_lower for term in ['distribution', 'breakdown', 'composition', 'percentage', 'proportion']) and len(results) <= 10:
        return 'pie'
    
    if any(term in query_lower for term in ['compare', 'comparison', 'versus', 'ranking']):
        return 'bar'
    
    # Default based on data size
    if len(results) <= 5:
        return 'pie'
    elif len(results) > 20:
        return 'line'
    else:
        return 'bar'


def generate_colors(count):
    """Generate attractive colors for charts with better distribution"""
    base_colors = [
        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
        '#FF9F40', '#8AC24A', '#7E57C2', '#EF5350', '#29B6F6',
        '#66BB6A', '#FFA726', '#5C6BC0', '#26C6DA', '#D4E157'
    ]
    
    if count <= len(base_colors):
        return base_colors[:count]
    
    # Generate additional colors using HSL color space for better distribution
    additional_colors = []
    hue_step = 360 / (count - len(base_colors))
    
    for i in range(count - len(base_colors)):
        hue = int(i * hue_step) % 360
        saturation = 70 + random.randint(-10, 10)
        lightness = 50 + random.randint(-10, 10)
        additional_colors.append(f'hsl({hue}, {saturation}%, {lightness}%)')
    
    return base_colors + additional_colors

def clean_label(text):
    """Convert labels to clean, readable text with better formatting"""
    if not text:
        return ""
    
    # Replace special characters with spaces
    text = re.sub(r'[_\-]+', ' ', str(text))
    
    # Handle camelCase
    text = re.sub(r'([a-z])([A-Z])', r'\1 \2', text)
    
    # Convert to title case but preserve acronyms
    words = []
    for word in text.split():
        if word.isupper() and len(word) > 1:
            words.append(word)
        else:
            words.append(word.title())
    
    # Join and clean up
    text = ' '.join(words)
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def format_time_value(value):
    """Format time values with proper units and smart rounding"""
    try:
        num_value = float(value)
        if num_value >= 1440:  # Convert to days if >= 24 hours
            days = num_value / 1440
            return f"{days:.1f} days"
        elif num_value >= 60:  # Convert to hours if >= 60 minutes
            hours = num_value / 60
            return f"{hours:.1f} hrs"
        elif num_value >= 1:  # Show as minutes if >= 1 minute
            return f"{num_value:.1f} min"
        else:  # Show as seconds if < 1 minute
            seconds = num_value * 60
            return f"{seconds:.0f} sec"
    except (ValueError, TypeError):
        return str(value)
    
def format_financial_value_clean(value):
    """Format financial values with proper currency symbol"""
    try:
        # Clean existing formatting
        clean_value = str(value).replace('%', '').replace('$', '').replace(',', '').strip()
        num = float(clean_value)
        
        if num.is_integer():
            return f"${int(num):,}"
        else:
            return f"${num:,.2f}"
    except (ValueError, TypeError):
        return str(value)
    
def is_financial_column(column_name):
    """Check if column contains financial data - IMPROVED VERSION"""
    financial_keywords = [
        'amount', 'revenue', 'payment', 'billing', 'cost', 'price', 
        'profit', 'loss', 'fee', 'income', 'expense', 'charge',
        'bill',  'margin', 'tax', 
        'bonus', 'allowance', 'premium',
        'refund', 'balance', 'salary'
    ]
         
    col_lower = str(column_name).lower().strip()
    
    # EXCLUDE time-related columns from being considered financial
    time_indicators = ['minutes', 'hours', 'seconds', 'time', 'duration']
    if any(time_word in col_lower for time_word in time_indicators):
        return False
    
    return (
        any(keyword in col_lower for keyword in financial_keywords) or
        col_lower.endswith('amount') or
        col_lower.startswith('amount') or
        (col_lower.endswith('value') and 'time' not in col_lower) or
        (col_lower.startswith('value') and 'time' not in col_lower)
    )


def is_time_column(column_name):
    """Check if column contains time data with comprehensive indicators"""
    time_keywords = [
        # Basic time units
        'time', 'timestamp', 'datetime', 'date', 'hour', 'minute', 'second',
        'millisecond', 'microsecond', 'nanosecond', 'duration', 'elapsed',
        
        # Time periods
        'minutes', 'hours', 'seconds', 'days', 'weeks', 'months', 'years',
        'quarter',
        'period', 
        
        # Process timing
        'turnover', 'wait', 'delay', 'processing',
        'response', 'throughput', 'latency', 
        'downtime', 'execution', 
        
        # Scheduling terms
        'schedule', 'arrival', 'departure', 'start', 'begin', 'end', 'finish',
        'stop', 
        # Time-related metrics
        'frequency', 
        'acceleration'
    ]
    
    col_lower = str(column_name).lower()
    return any(keyword in col_lower for keyword in time_keywords)

    
def format_number_with_units(value, column_name=None):
    """Format numbers with proper units and 2 decimal places"""
    if value is None:
        return "0"
    
    try:
        num_value = float(value)
    except (ValueError, TypeError):
        return str(value)
    
    # Check if this is a time-related column
    col_lower = str(column_name).lower() if column_name else ""
    is_time = any(term in col_lower for term in ['time', 'duration', 'minutes', 'hours', 'seconds'])
    
    if is_time:
        # Format time values
        if num_value >= 60:  # Convert to hours if >= 60 minutes
            hours = num_value / 60
            return f"{hours:.2f} hrs"
        else:
            return f"{num_value:.2f} min"
    else:
        # Regular number formatting
        return f"{num_value:.2f}"

def format_month_label(value):
    """Convert month numbers or abbreviations to full month names"""
    month_map = {
    '1': 'January', '2': 'February', '3': 'March', '4': 'April',
    '5': 'May', '6': 'June', '7': 'July', '8': 'August',
    '9': 'September', '10': 'October', '11': 'November', '12': 'December',
    '01': 'January', '02': 'February', '03': 'March', '04': 'April',
    '05': 'May', '06': 'June', '07': 'July', '08': 'August',
    '09': 'September', '10': 'October', '11': 'November', '12': 'December',
    'jan': 'January', 'feb': 'February', 'mar': 'March', 'apr': 'April',
    'may': 'May', 'jun': 'June', 'jul': 'July', 'aug': 'August',
    'sep': 'September', 'oct': 'October', 'nov': 'November', 'dec': 'December',
    'january': 'January', 'february': 'February', 'march': 'March', 
    'april': 'April', 'june': 'June', 'july': 'July', 'august': 'August',
    'september': 'September', 'october': 'October', 'november': 'November', 'december': 'December'
    }
    
    value_str = str(value).lower().strip()
    return month_map.get(value_str, value)


def prepare_scatter_data(results, numeric_cols, query, financial_columns=None):
    """Prepare scatter plot data with enhanced financial formatting and clean labels"""
    if len(numeric_cols) < 2:
        return None
    
    x_col = numeric_cols[0]
    y_col = numeric_cols[1]
    
    # Check if columns are time-related or financial
    x_is_time = any(term in x_col.lower() for term in ['time', 'duration', 'minutes', 'hours'])
    y_is_time = any(term in y_col.lower() for term in ['time', 'duration', 'minutes', 'hours'])
    x_is_financial = financial_columns and x_col in financial_columns
    y_is_financial = financial_columns and y_col in financial_columns
    
    # Try to find a categorical column for point labels
    cat_col = None
    try:
        if results and isinstance(results[0], dict):
            headers = list(results[0].keys())
            categorical_cols = [col for col in headers 
                             if col not in numeric_cols and 
                             not any(term in col.lower() for term in ['date', 'time', 'year', 'month', 'day'])]
            if categorical_cols:
                cat_col = categorical_cols[0]
    except Exception:
        cat_col = None
    
    data_points = []
    x_values = []
    y_values = []
    
    for row in results:
        try:
            x_val_raw = str(row.get(x_col, 0))
            y_val_raw = str(row.get(y_col, 0))
            
            # Clean financial formatting
            if '$' in x_val_raw:
                x_val_raw = x_val_raw.replace('$', '').replace(',', '')
                x_is_financial = True
            if '$' in y_val_raw:
                y_val_raw = y_val_raw.replace('$', '').replace(',', '')
                y_is_financial = True
                
            x_val = round(float(x_val_raw), 2)
            y_val = round(float(y_val_raw), 2)
            
            x_values.append(x_val)
            y_values.append(y_val)
            
            point = {'x': x_val, 'y': y_val}
            if cat_col:
                try:
                    point['category'] = str(row.get(cat_col, ''))
                except Exception:
                    point['category'] = ''
            data_points.append(point)
        except (ValueError, TypeError):
            continue
    
    if not data_points:
        return None
    
    # Clean labels with units
    x_label = clean_label(x_col)
    y_label = clean_label(y_col)
    
    if x_is_time:
        x_label = f"{x_label} (min)"
    elif x_is_financial:
        x_label = f"{x_label} ($)"
    
    if y_is_time:
        y_label = f"{y_label} (min)"
    elif y_is_financial:
        y_label = f"{y_label} ($)"
    
    # Calculate nice axis ranges
    x_max = max(x_values) if x_values else 0
    y_max = max(y_values) if y_values else 0
    
    chart_config = {
        'chart_type': 'scatter',
        'data': {
            'datasets': [{
                'label': f'{x_label} vs {y_label}',
                'data': data_points,
                'backgroundColor': '#36A2EB',
                'borderColor': '#36A2EB',
                'borderWidth': 1,
                'pointRadius': 5,
                'pointHoverRadius': 8
            }]
        },
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'title': {
                    'display': True,
                    'text': f'Scatter Analysis: {x_label} vs {y_label}',
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'legend': {
                    'display': True,
                    'position': 'top'
                },
                'tooltip': {
                    'enabled': True,
                    'mode': 'point',
                    'intersect': True
                }
            },
            'scales': {
                'x': {
                    'title': {
                        'display': True,
                        'text': x_label,
                        'font': {'size': 14}
                    },
                    'beginAtZero': True
                },
                'y': {
                    'title': {
                        'display': True,
                        'text': y_label,
                        'font': {'size': 14}
                    },
                    'beginAtZero': True
                }
            }
        },
        'title': f'{x_label} vs {y_label} Analysis'
    }
    
    # Add formatting hints for frontend
    chart_config['formatting'] = {
        'x_is_financial': x_is_financial,
        'y_is_financial': y_is_financial,
        'x_is_time': x_is_time,
        'y_is_time': y_is_time,
        'has_categories': cat_col is not None
    }
    
    return chart_config



def prepare_line_data(results, date_cols, categorical_cols, numeric_cols, chart_type, query, financial_columns=None):
    """Prepare line/area chart data with proper formatting"""
    if not numeric_cols:
        return None
    
    # CHANGE 1: Improved x-axis column selection logic
    x_col = None
    y_col = None
    
    # Priority order: date > categorical > first available column
    if date_cols:
        x_col = date_cols[0]
        y_col = numeric_cols[0] if numeric_cols else None
    elif categorical_cols and numeric_cols:
        # Use categorical for x-axis and numeric for y-axis
        x_col = categorical_cols[0]
        y_col = numeric_cols[0]
    elif len(numeric_cols) >= 2:
        # If we have multiple numeric columns, use first as x, second as y
        x_col = numeric_cols[0]
        y_col = numeric_cols[1]
    elif results and len(results) > 0 and isinstance(results[0], dict):
        # Fallback to first two columns
        all_cols = list(results[0].keys())
        if len(all_cols) >= 2:
            x_col = all_cols[0]
            y_col = all_cols[1]
        else:
            return None
    else:
        return None
    
    if not x_col or not y_col:
        return None
    
    # Check column types more accurately
    is_financial = False
    is_time = False
    is_percentage = False
    
    # Check if y-column is actually financial
    if financial_columns and y_col in financial_columns:
        is_financial = True
    elif is_financial_column(y_col):
        is_financial = True
    
    # Check for time columns
    if is_time_column(y_col):
        is_time = True
    
    # Check for percentage columns
    y_col_lower = y_col.lower()
    if any(keyword in y_col_lower for keyword in ['percent', 'percentage', '%', 'rate']):
        is_percentage = True
    
    # Extract and process data
    chart_data = []
    sample_values = []
    
    for row in results:
        try:
            x_val = str(row.get(x_col, ''))
            y_val_raw = str(row.get(y_col, 0))
            
            # Clean financial formatting
            if '$' in y_val_raw:
                y_val_raw = y_val_raw.replace('$', '').replace(',', '')
                is_financial = True  # If we see $ signs, treat as financial
            
            # Clean percentage formatting
            if '%' in y_val_raw:
                y_val_raw = y_val_raw.replace('%', '')
                is_percentage = True
            
            y_val = round(float(y_val_raw), 2)
            sample_values.append(y_val)
            
            # Format month labels using the new function (if format_month_label exists)
            if 'month' in x_col.lower():
                try:
                    x_val = format_month_label(x_val)
                except:
                    pass  # Use original value if function doesn't exist
            
            chart_data.append((x_val, y_val))
        except (ValueError, TypeError):
            continue
    
    if not chart_data:
        return None
    
    # Check if all values are integers
    all_integers = all(float(val).is_integer() for val in sample_values if val is not None)
    
    # Sort data
    try:
        chart_data.sort(key=lambda x: float(x[0]))
    except (ValueError, TypeError):
        chart_data.sort(key=lambda x: x[0])
    
    labels = [item[0] for item in chart_data]
    values = [item[1] for item in chart_data]
    
    # CHANGE 2: Clean labels and prepare axis titles properly
    x_label = clean_label(x_col)
    y_label = clean_label(y_col)
    
    # Calculate data metrics for y-axis scaling
    max_value = max(sample_values) if sample_values else 0
    min_value = min(sample_values) if sample_values else 0
    
    # Improved y-axis scale calculation
    def calculate_scale_params(max_val):
        """Calculate optimal step size and max value for y-axis"""
        if max_val == 0:
            return 1, 0, 0
        
        # Calculate order of magnitude
        order_of_magnitude = 10 ** math.floor(math.log10(max_val))
        normalized = max_val / order_of_magnitude
        
        # Determine step size based on normalized max value
        if normalized <= 1.5:
            step_size = 0.2 * order_of_magnitude
        elif normalized <= 3:
            step_size = 0.5 * order_of_magnitude
        elif normalized <= 7:
            step_size = 1 * order_of_magnitude
        else:
            step_size = 2 * order_of_magnitude
        
        # Calculate nice max value that's slightly above our data max
        nice_max = math.ceil(max_val / step_size) * step_size
        
        # Ensure we have between 5-10 ticks
        num_ticks = nice_max / step_size
        if num_ticks < 5:
            step_size = nice_max / 5
        elif num_ticks > 10:
            step_size = nice_max / 10
        
        return step_size, nice_max, min(12, math.ceil(nice_max / step_size))
    
    step_size, nice_max, max_ticks = calculate_scale_params(max_value)
    
    # Create appropriate formatting based on data type
    if is_financial:
        formatted_y_title = f"{y_label} ($)"
    elif is_time:
        formatted_y_title = f"{y_label} (time)"
    elif is_percentage:
        formatted_y_title = f"{y_label} (%)"
    else:
        formatted_y_title = y_label
    
    # CHANGE 3: Proper dataset configuration with correct legend
    dataset_config = {
        'label': y_label,  # Legend shows the y-axis data series name
        'data': values,
        'borderColor': '#36A2EB',
        'backgroundColor': 'rgba(54, 162, 235, 0.2)' if chart_type == 'area' else 'rgba(54, 162, 235, 0.1)',
        'borderWidth': 3,
        'tension': 0.4,
        'pointRadius': 5,
        'pointHoverRadius': 8,
        'pointBackgroundColor': '#36A2EB',
        'pointBorderColor': '#ffffff',
        'pointBorderWidth': 2
    }
    
    if chart_type == 'area':
        dataset_config['fill'] = True
    
    # CHANGE 4: Improved chart configuration with proper titles and axis labels
    chart_config = {
        'chart_type': chart_type,
        'data': {
            'labels': labels,
            'datasets': [dataset_config]
        },
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'title': {
                    'display': True,
                    'text': f'{y_label} by {x_label}',  # Title shows relationship
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'legend': {
                    'display': True,
                    'position': 'top'
                },
                'tooltip': {
                    'enabled': True,
                    'mode': 'index',
                    'intersect': False
                }
            },
            'scales': {
                'x': {
                    'title': {
                        'display': True,
                        'text': x_label,  # X-axis shows the x-column name
                        'font': {'size': 14}
                    },
                    'grid': {
                        'display': True,
                        'color': 'rgba(0,0,0,0.1)'
                    }
                },
                'y': {
                    'title': {
                        'display': True,
                        'text': formatted_y_title,  # Y-axis shows the y-column name
                        'font': {'size': 14}
                    },
                    'min': 0,
                    'max': nice_max,
                    'ticks': {
                        'stepSize': step_size,
                        'maxTicksLimit': max_ticks,
                        'autoSkip': True,
                        'font': {
                            'size': 12
                        }
                    },
                    'grid': {
                        'display': True,
                        'color': 'rgba(0,0,0,0.15)',
                        'lineWidth': 1,
                        'drawBorder': True
                    },
                    'border': {
                        'display': True,
                        'color': '#666',
                        'width': 1
                    }
                }
            },
            'interaction': {
                'intersect': False,
                'mode': 'index'
            }
        },
        'title': f'{y_label} Trend Analysis'
    }
    
    # Add formatting hints for frontend
    chart_config['formatting'] = {
        'is_financial': is_financial,
        'is_time': is_time,
        'is_percentage': is_percentage,
        'all_integers': all_integers
    }
    
    return chart_config




def prepare_pie_data(results, categorical_cols, numeric_cols, query, financial_columns=None):
    """Prepare pie chart data with proper formatting"""
    if not categorical_cols or not numeric_cols:
        return None
    
    cat_col = categorical_cols[0]
    num_col = numeric_cols[0]
    
    # Check column types
    is_financial = is_financial_column(num_col) or (financial_columns and num_col in financial_columns)
    is_time = is_time_column(num_col)
    
    # Special handling for count columns - override financial check
    count_columns = [
        'total cases', 'case count', 'visit count',
        'patient count', 'record count', 'number of cases',
        'count', 'cases', 'number'
    ]
    col_lower = str(num_col).lower().strip()
    is_count = any(count_term in col_lower for count_term in count_columns)
    
    # Check for percentage columns
    is_percentage = any(keyword in col_lower for keyword in ['percent', 'percentage', '%', 'rate'])
    
    # Aggregate data
    data_map = {}
    for row in results:
        try:
            category = str(row.get(cat_col, 'Unknown'))
            value_raw = str(row.get(num_col, 0))
            
            # Clean financial formatting if present
            if '$' in value_raw:
                value_raw = value_raw.replace('$', '').replace(',', '')
                is_financial = True  # Override if we see $ signs
            
            # Clean percentage formatting
            if '%' in value_raw:
                value_raw = value_raw.replace('%', '')
                is_percentage = True
            
            value = round(float(value_raw), 2)
            data_map[category] = round(data_map.get(category, 0) + value, 2)
        except (ValueError, TypeError):
            continue
    
    if not data_map:
        return None
    
    # Sort by value descending and limit to top 10
    sorted_data = sorted(data_map.items(), key=lambda x: x[1], reverse=True)[:10]
    
    raw_labels = [item[0] for item in sorted_data]
    values = [item[1] for item in sorted_data]
    total = sum(values) if values else 0
    colors = generate_colors(len(raw_labels))
    
    # Clean labels
    labels = [clean_label(item[0]) for item in sorted_data]
    
    # Format values for display based on data type
    formatted_values = []
    for v in values:
        if is_count:  # Count columns get simple number formatting
            formatted_values.append(f"{v:,.0f}")
        elif is_financial and not is_count:  # Only format as financial if not a count column
            formatted_values.append(f"${v:,.2f}")
        elif is_time:
            if v >= 60:
                formatted_values.append(f"{v/60:,.1f} hrs")
            else:
                formatted_values.append(f"{v:,.1f} min")
        elif is_percentage:
            formatted_values.append(f"{v:,.1f}%")
        else:
            formatted_values.append(f"{v:,.2f}")
    
    # Build display labels with value and percentage
    display_labels = []
    for i, lbl in enumerate(labels):
        v = values[i]
        pct = (v / total * 100.0) if total else 0
        display_labels.append(f"{lbl} ({formatted_values[i]}, {pct:.1f}%)")
    
    # Clean column names for display
    cat_label = clean_label(cat_col)
    num_label = clean_label(num_col)
    
    chart_config = {
        'chart_type': 'pie',
        'data': {
            'labels': display_labels,
            'datasets': [{
                'data': values,
                'backgroundColor': colors,
                'borderColor': '#ffffff',
                'borderWidth': 2
            }]
        },
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'title': {
                    'display': True,
                    'text': f'{num_label} by {cat_label}',
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'legend': {
                    'display': True,
                    'position': 'right'
                },
                'tooltip': {
                    'enabled': True
                }
            },
            'cutout': '50%'  # Makes it a donut chart; set to 0 for full pie
        },
        'title': f'{num_label} Distribution'
    }
    
    # Add formatting hints for frontend
    chart_config['formatting'] = {
        'is_financial': is_financial and not is_count,
        'is_time': is_time,
        'is_percentage': is_percentage,
        'is_count': is_count
    }
    
    return chart_config
def format_percentage_value(value):
    """Format percentage values with proper % symbol"""
    try:
        # Clean existing formatting first
        clean_value = str(value).replace('%', '').replace('$', '').replace(',', '').strip()
        num = float(clean_value)
        
        if num.is_integer():
            return f"{int(num)}%"
        else:
            # Format decimals and remove trailing zeros, then add %
            formatted_num = f"{num:.2f}".rstrip('0').rstrip('.')
            return f"{formatted_num}%"
    except (ValueError, TypeError):
        # If not a number, just add % if not already present
        str_value = str(value)
        if not str_value.endswith('%'):
            return f"{str_value}%"
        else:
            return str_value
        
    
def is_percentage_column(column_name):
    """Check if column contains percentage data"""
    percentage_keywords = [
        'percent', 'percentage', '%', 'rate', 'ratio', 'utilization',
        'efficiency', 'performance'
    ]
    
    col_lower = str(column_name).lower()
    return any(keyword in col_lower for keyword in percentage_keywords)

def format_table_data(formatted_results, financial_columns=None):
    """Format table data with clean headers and proper formatting - FIXED VERSION"""
    if not formatted_results:
        return [], []
        
    # Clean headers
    original_headers = list(formatted_results[0].keys())
    clean_headers = [clean_label(header) for header in original_headers]
    
    # Categorize columns by type - PRIORITIZE TIME COLUMNS FIRST
    financial_cols = set()
    percentage_cols = set()
    time_cols = set()
    
    # Categorize each column with proper priority order
    for col in original_headers:
        col_lower = col.lower().strip()
        
        # First check for time columns (highest priority for your case)
        if is_time_column(col_lower):
            time_cols.add(col)
        # Then check for percentage columns
        elif is_percentage_column(col_lower):
            percentage_cols.add(col)
        # Finally check for financial columns
        elif is_financial_column(col_lower):
            financial_cols.add(col)
    
    # Override with explicitly provided financial columns if available
    if financial_columns:
        # Only add to financial_cols if not already categorized as time or percentage
        for fin_col in financial_columns:
            if fin_col not in time_cols and fin_col not in percentage_cols:
                financial_cols.add(fin_col)
    
    # Remove any potential overlaps (time and percentage take priority over financial)
    financial_cols = financial_cols - time_cols - percentage_cols
 
    rows = []
    for row in formatted_results:
        formatted_row = []
        for i, col in enumerate(original_headers):
            value = row.get(col, '')
                        
            if value is None or value == '':
                formatted_row.append('')
            elif col in time_cols:
                # Format time columns with time indicators (HIGHEST PRIORITY)
                formatted_row.append(format_time_value(value))
            elif col in percentage_cols:
                # Format percentage columns with % symbol
                formatted_row.append(format_percentage_value(value))
            elif col in financial_cols:
                # Format as currency only if explicitly marked as financial
                formatted_row.append(format_financial_value_clean(value))
            else:
                # Enhanced number formatting with proper comma separation
                try:
                    # Clean any existing formatting first
                    clean_value = str(value).replace('%', '').replace('$', '').replace(',', '').strip()
                    num = float(clean_value)
                    if num.is_integer():
                        formatted_row.append(f"{int(num):,}")
                    else:
                        # Format decimals with commas and remove trailing zeros
                        formatted_num = f"{num:,.2f}".rstrip('0').rstrip('.')
                        formatted_row.append(formatted_num)
                except (ValueError, TypeError):
                    formatted_row.append(str(value))
                    
        rows.append(formatted_row)
        
    return clean_headers, rows

def prepare_bar_data(results, categorical_cols, numeric_cols, query, financial_columns=None):
    """Prepare bar chart data with proper tooltip and formatting"""
    if not categorical_cols or not numeric_cols:
        return None
    
    cat_col = categorical_cols[0]
    num_col = numeric_cols[0]
    
    # Check column types - make this more accurate
    is_financial = False
    is_time = False
    is_percentage = False
    
    # Check if column is actually financial
    if financial_columns and num_col in financial_columns:
        is_financial = True
    elif is_financial_column(num_col):
        is_financial = True
    
    # Check for time columns
    if is_time_column(num_col):
        is_time = True
    
    # Check for percentage columns
    num_col_lower = num_col.lower()
    if any(keyword in num_col_lower for keyword in ['percent', 'percentage', '%', 'rate', 'ratio', 'efficiency', 'performance']):
        is_percentage = True
    
    # Aggregate data
    data_map = {}
    sample_values = []
    
    for row in results:
        try:
            category = str(row.get(cat_col, 'Unknown'))
            value_raw = str(row.get(num_col, 0))
            
            # Clean financial formatting for calculation
            if '$' in value_raw:
                value_raw = value_raw.replace('$', '').replace(',', '')
                is_financial = True  # If we see $ signs, treat as financial
            
            # Clean percentage formatting
            if '%' in value_raw:
                value_raw = value_raw.replace('%', '')
                is_percentage = True
            
            value = round(float(value_raw), 2)
            data_map[category] = round(data_map.get(category, 0) + value, 2)
            sample_values.append(value)
        except (ValueError, TypeError):
            continue
    
    if not data_map:
        return None
    
    # Analyze data to determine appropriate formatting
    max_value = max(sample_values) if sample_values else 0
    min_value = min(sample_values) if sample_values else 0
    avg_value = sum(sample_values) / len(sample_values) if sample_values else 0
    value_range = max_value - min_value
    
    # Check if all values are integers
    all_integers = all(float(val).is_integer() for val in sample_values if val is not None)
    
    # Sort and limit data
    sorted_data = sorted(data_map.items(), key=lambda x: x[1], reverse=True)[:15]
    
    labels = [clean_label(item[0]) for item in sorted_data]
    values = [item[1] for item in sorted_data]
    colors = generate_colors(len(labels))
    
    # Clean column labels
    cat_label = clean_label(cat_col)
    num_label = clean_label(num_col)
    
    # Improved y-axis scale calculation
    def calculate_scale_params(max_val):
        """Calculate optimal step size and max value for y-axis"""
        import math
        if max_val == 0:
            return 1, 0, 0
        
        # Calculate order of magnitude
        order_of_magnitude = 10 ** math.floor(math.log10(max_val))
        normalized = max_val / order_of_magnitude
        
        # Determine step size based on normalized max value
        if normalized <= 1.5:
            step_size = 0.2 * order_of_magnitude
        elif normalized <= 3:
            step_size = 0.5 * order_of_magnitude
        elif normalized <= 7:
            step_size = 1 * order_of_magnitude
        else:
            step_size = 2 * order_of_magnitude
        
        # Calculate nice max value that's slightly above our data max
        nice_max = math.ceil(max_val / step_size) * step_size
        
        # Ensure we have between 5-10 ticks
        num_ticks = nice_max / step_size
        if num_ticks < 5:
            step_size = nice_max / 5
        elif num_ticks > 10:
            step_size = nice_max / 10
        
        return step_size, nice_max, min(12, math.ceil(nice_max / step_size))
    
    step_size, nice_max, max_ticks = calculate_scale_params(max_value)
    
    # Create appropriate formatting based on data type
    # Using simpler approach without custom JavaScript callbacks
    if is_financial:
        y_axis_title = f"{num_label} ($)"
    elif is_time:
        y_axis_title = f"{num_label} (time)"
    elif is_percentage:
        y_axis_title = f"{num_label} (%)"
    else:
        y_axis_title = num_label
    
    # Basic chart configuration without complex callbacks
    chart_config = {
        'chart_type': 'bar',
        'data': {
            'labels': labels,
            'datasets': [{
                'label': num_label,
                'data': values,
                'backgroundColor': colors,
                'borderColor': colors,
                'borderWidth': 1
            }]
        },
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'title': {
                    'display': True,
                    'text': f'{num_label} by {cat_label}',
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'legend': {
                    'display': True,
                    'position': 'top'
                },
                'tooltip': {
                    'enabled': True,
                    'mode': 'index',
                    'intersect': False
                }
            },
            'scales': {
                'x': {
                    'title': {
                        'display': True,
                        'text': cat_label,
                        'font': {'size': 14}
                    },
                    'grid': {
                        'display': True,
                        'color': 'rgba(0,0,0,0.1)'
                    }
                },
                'y': {
                    'title': {
                        'display': True,
                        'text': y_axis_title,
                        'font': {'size': 14}
                    },
                    'min': 0,
                    'max': nice_max,
                    'ticks': {
                        'stepSize': step_size,
                        'maxTicksLimit': max_ticks,
                        'autoSkip': True,
                        'font': {
                            'size': 12
                        }
                    },
                    'grid': {
                        'display': True,
                        'color': 'rgba(0,0,0,0.15)',
                        'lineWidth': 1,
                        'drawBorder': True
                    },
                    'border': {
                        'display': True,
                        'color': '#666',
                        'width': 1
                    }
                }
            },
            'interaction': {
                'intersect': False,
                'mode': 'index'
            }
        },
        'title': f'{num_label} Analysis'
    }
    
    # If you need custom formatting, you'll need to handle it in your frontend JavaScript
    # Add formatting hints to the config
    chart_config['formatting'] = {
        'is_financial': is_financial,
        'is_time': is_time,
        'is_percentage': is_percentage,
        'all_integers': all_integers
    }
    
    return chart_config


def has_enough_categories(labels, min_unique):
    return len({l for l in labels if l is not None}) >= min_unique
def display_name(column_name: str) -> str:
    """
    Convert snake_case column names to Title Case with proper spacing and acronym handling.
    
    Examples:
    - or_room → OR Room
    - avg_turnover_minutes → Avg Turnover Minutes  
    - case_count → Case Count
    - cpt_code → CPT Code
    - total_payments → Total Payments
    """
    if not column_name:
        return ""
    
    # Handle common acronyms that should stay uppercase
    acronyms = {
        'or': 'OR',
        'cpt': 'CPT', 
        'npi': 'NPI',
        'dos': 'DOS',
        'pt': 'PT',
        'phys': 'Phys',
        'srgy': 'Surgery',
        'rr': 'RR',
        'pacu': 'PACU',
        'anes': 'Anesthesia',
        'preop': 'Pre-op',
        'postop': 'Post-op',
        'hcpcs': 'HCPCS',
        'ftes': 'FTEs',
        'tat': 'TAT',
        'bcbs': 'BCBS',
        'medicare': 'Medicare',
        'medicaid': 'Medicaid',
        'commercial': 'Commercial'
    }
    
    # Split by underscore and process each part
    parts = column_name.lower().split('_')
    processed_parts = []
    
    for part in parts:
        if part in acronyms:
            processed_parts.append(acronyms[part])
        else:
            # Title case the part, handling special cases
            if part in ['avg', 'min', 'max', 'sum', 'count', 'total']:
                # Common aggregations
                processed_parts.append(part.title())
            elif part in ['id', 'num', 'amt', 'cost', 'time', 'date']:
                # Common abbreviations
                processed_parts.append(part.upper())
            else:
                # Regular title case
                processed_parts.append(part.title())
    
    return ' '.join(processed_parts)

def prepare_chart_data(results, query):
    """Prepare chart data with currency formatting preservation and dimension-aware selection"""
    if not results or len(results) == 0:
        return None
        
    if not isinstance(results[0], dict):
        return None
        
    # Drop total rows
    def _is_total_row(row):
        for k, v in row.items():
            try:
                s = str(v).strip().lower()
                if s in ("total", "totals", "grand total", "grand totals"):
                    return True
            except Exception:
                continue
        return False
        
    filtered_results = [r for r in results if isinstance(r, dict) and not _is_total_row(r)]
    results = filtered_results or results
        
    # Detect financial columns first
    financial_columns = detect_financial_columns(results, query)
    formatted_results = format_results_with_currency(results, financial_columns)
        
    if not formatted_results or len(formatted_results) == 0:
        return None
        
    headers = list(formatted_results[0].keys())
    # Only suppress charts when there's only 1 column (not 2)
    if len(headers) <= 1:
        return None
        
    # CHANGE 5: Improved column classification logic
    numeric_cols = []
    categorical_cols = []
    date_cols = []
        
    for col in headers:
        col_lower = col.lower()
        sample_values = [row.get(col) for row in formatted_results[:10] if row.get(col) is not None]
                
        if not sample_values:
            continue
                    
        # Check for date columns
        if any(term in col_lower for term in ['date', 'time', 'year', 'month', 'day']):
            date_cols.append(col)
        else:
            # Check if numeric (handle currency formatting)
            try:
                numeric_samples = []
                for val in sample_values:
                    if val is not None:
                        val_str = str(val).replace('$', '').replace(',', '').replace('%', '')
                        # Handle negative numbers
                        if val_str.startswith('-') or val_str.startswith('('):
                            val_str = val_str.replace('(', '-').replace(')', '')
                        numeric_samples.append(float(val_str))
                                
                if len(numeric_samples) > len(sample_values) * 0.7:  # 70% numeric threshold
                    numeric_cols.append(col)
                else:
                    categorical_cols.append(col)
            except (ValueError, TypeError):
                categorical_cols.append(col)
        
    chart_type = determine_chart_type(query, formatted_results)
        
    # Pass financial_columns to all chart preparation functions
    if chart_type == 'scatter':
        return prepare_scatter_data(formatted_results, numeric_cols, query, financial_columns)
    elif chart_type in ['line', 'area']:
        return prepare_line_data(formatted_results, date_cols, categorical_cols, numeric_cols, chart_type, query, financial_columns)
    elif chart_type == 'pie':
        return prepare_pie_data(formatted_results, categorical_cols, numeric_cols, query, financial_columns)
    else:  # bar chart
        return prepare_bar_data(formatted_results, categorical_cols, numeric_cols, query, financial_columns)



def detect_financial_columns(results, query):
    """Identify financial columns using hardcoded rules"""
    if not results or len(results) == 0:
        return set()
    
    financial_columns = set()
    headers = list(results[0].keys())
    
    # Explicit financial keywords (must appear in column name)
    financial_keywords = [
        'amount', 'revenue', 'payment', 'billing', 'cost', 'price',
        'profit', 'loss', 'fee', 'income', 'expense', 
        'bill', 'variance', 'margin', 'discount', 'tax',
        'bonus', 'allowance', 'deduction', 'premium',
        'refund', 'valuation', 'balance', 
        'credit', 'debit', 'gross', 'net', 'contribution'
    ]
    
    # Explicit non-financial columns (even if they contain financial keywords)
    non_financial_columns = [
        'claim number', 'account number', 'visit number', 
        'payer id', 'id', 'reference', 'code', 'phone','minutes',
        'date', 'time', 'year', 'month', 'day', 'ssn',
        'zip', 'address', 'name', 'description', 'note',
        'status', 'flag', 'type', 'category','Total cases',
    ]
    
    # Check each column
    for column in headers:
        col_lower = column.lower()
        
        # Skip explicitly non-financial columns
        if any(non_financial in col_lower for non_financial in non_financial_columns):
            continue
            
        # Check for financial indicators
        if (any(keyword in col_lower for keyword in financial_keywords) or
            col_lower.endswith(('amount', 'value', 'price', 'cost', 'fee')) or
            col_lower.startswith(('amount', 'value', 'price', 'cost', 'fee'))):
            
            # Verify sample values look like monetary values
            sample_values = [str(row.get(column, '')).strip() for row in results[:5]]
            monetary_count = 0
            
            for val in sample_values:
                if not val:
                    continue
                # Check for currency symbols or numeric patterns
                if (val.startswith('$') or 
                    re.match(r'^[\d,]+\.\d{2}$', val) or
                    re.match(r'^[\d,]+$', val)):
                    monetary_count += 1
            
            # If at least 60% of sample values look monetary
            if monetary_count / len(sample_values) > 0.6:
                financial_columns.add(column)
    
    return financial_columns

def format_financial_value(value):
    """Format a value as currency if it's numeric"""
    try:
        # Remove existing formatting
        clean_val = str(value).replace('$', '').replace(',', '')
        num = float(clean_val)
        return f"${num:,.2f}"
    except (ValueError, TypeError):
        return str(value)


# Replace your format_results_with_currency function
def format_results_with_currency(results, financial_columns):
    """Format financial columns and time columns with proper formatting"""
    if not results:
        return results
    
    formatted_results = []
    for row in results:
        formatted_row = {}
        for k, v in row.items():
            if v is None:
                formatted_row[k] = v
            elif is_financial_column(k) or k in (financial_columns or []):
                formatted_row[k] = format_financial_value_clean(v)
            elif is_time_column(k):
                formatted_row[k] = format_time_value(v)
            else:
                # Round other numeric values to 2 decimal places
                try:
                    num_val = float(v)
                    formatted_row[k] = f"{num_val:.2f}"
                except (ValueError, TypeError):
                    formatted_row[k] = v
        formatted_results.append(formatted_row)
    
    return formatted_results


async def generate_ai_analysis(query, results, sql_query, execution_time, schema_info=None, financial_columns=None, chart_data=None):
    """Generate comprehensive AI analysis using Agno agent with optimized performance"""
    try:
        # Prepare data summary for the AI agent
        data_summary = ""
        if results:
            result_count = len(results)
            headers = list(results[0].keys())
            
            # Sample data for AI analysis
            sample_data = results[:3]  # Reduced from 5 to 3 for efficiency
            
            # Numeric analysis (optimized version)
            numeric_stats = {}
            for header in headers:
                numeric_values = []
                for row in results:
                    try:
                        val = float(str(row.get(header, 0)))
                        if val != 0:
                            numeric_values.append(val)
                    except (ValueError, TypeError):
                        continue
                
                if numeric_values:  # More Pythonic check
                    numeric_stats[header] = {
                        'count': len(numeric_values),
                        'total': sum(numeric_values),
                        'average': sum(numeric_values) / len(numeric_values),
                        'min': min(numeric_values),
                        'max': max(numeric_values)
                    }
            
            data_summary = f"""
QUERY ANALYSIS CONTEXT:
- Original Query: {query}
- SQL Generated: {sql_query}
- Records Found: {result_count}
- Execution Time: {execution_time:.2f} seconds
- Data Columns: {', '.join(headers)}
- Visualization: {chart_data['chart_type'] if chart_data else 'None'}

SAMPLE DATA (first 3 records):
{json.dumps(sample_data, indent=2, default=str)}

NUMERIC STATISTICS:
{json.dumps(numeric_stats, indent=2) if numeric_stats else 'No numeric data found'}
"""
        else:
            data_summary = f"""
QUERY ANALYSIS CONTEXT:
- Original Query: {query}
- SQL Generated: {sql_query}
- Records Found: 0
- Execution Time: {execution_time:.2f} seconds
- Result: No data matched the query criteria
"""

        # Enhanced AI analysis prompt with structured format
        analysis_prompt = f"""
You are an expert medical practice data analyst. Analyze the following query results and provide a comprehensive analysis.

{data_summary}

Please provide your analysis in EXACTLY this JSON format:

{{
    "executive_summary": "2-3 sentence overview in conversational tone",
    "parameter_explanations": [
        {{
            "parameter": "column_name",
            "meaning": "Medical practice meaning",
            "importance": "Why it matters",
            "interpretation": "How to read values",
            "benchmarks": "Typical ranges"
        }}
    ],
    "detailed_breakdown": "Key patterns/trends with specific numbers",
    "key_insights": [
        "Specific, actionable insight with data",
        "Business implication with numbers",
        "Comparative analysis insight"
    ],
    "recommendations": [
        "Practical action with rationale",
        "Strategic recommendation",
        "Quick win suggestion"
    ],
    "follow_up_questions": [
        "Analytical question to explore",
        "Comparative question",
        "Trend investigation question"
    ],
    "summary_stats": {{
        "confidence_score": "High/Medium/Low",
        "key_takeaway": "Single powerful insight"
    }}
}}

Guidelines:
1. Be conversational yet professional
2. Use specific numbers from the data
3. Provide medical context
4. Make recommendations actionable
5. Highlight both strengths and areas for improvement
"""
        
        # Initialize agent with optimized configuration
        analysis_agent = Agent(
            name="Medical Data Analysis Expert",
            model=Groq(id="llama-3.1-8b-instant"),
            description="Expert medical practice data analyst",
            instructions="Provide detailed, actionable insights in a friendly tone. Focus on practical implications.",
            temperature=0.3
        )
        
        # Generate and return analysis
        analysis_result = await analysis_agent.run(analysis_prompt, timeout=90)
        return json.loads(analysis_result.content)
        
    except Exception as e:
        logger.error(f"AI analysis error: {str(e)}", exc_info=True)
        return await generate_fallback_analysis(results)

async def generate_fallback_analysis(results):
    """Generate a structured fallback analysis"""
    record_count = len(results) if results else 0
    return {
        "executive_summary": f"Analysis of {record_count} records reveals insights for your practice.",
        "parameter_explanations": [],
        "detailed_breakdown": "Data shows patterns worth investigating.",
        "key_insights": [
            f"Found {record_count} relevant records",
            "Multiple metrics available for review",
            "Interesting patterns in the data"
        ],
        "recommendations": [
            "Examine detailed data trends",
            "Compare with historical data",
            "Identify significant outliers"
        ],
        "follow_up_questions": [
            "How do these compare to targets?",
            "What longer-term trends exist?",
            "Which areas show most variation?"
        ],
        "summary_stats": {
            "confidence_score": "Medium",
            "key_takeaway": "Your data contains valuable insights."
        }
    }
    
def format_response_as_objects(query, sql_query, results, execution_time, explanation=""):
    """Enhanced response formatting with AI-generated comprehensive analysis and financial support"""
    # Detect financial columns first
    financial_columns = detect_financial_columns(results, query)
    formatted_results = format_results_with_currency(results, financial_columns)
    objects = []

    if not results:
        objects.append({
            "type": "text",
            "title": "No Results",
            "content": {
                "html": """
                    <div style="text-align: center; padding: 30px; background: #fff3cd; border-radius: 8px; border: 1px solid #ffeaa7;">
                        <h4 style="color: #856404; margin-top: 0;"> No Data Found</h4>
                        <p style="color: #856404;">No records match your query criteria. Try adjusting your search parameters.</p>
                    </div>
                """
            }
        })
        return objects
    
    try:
        # Generate AI-powered comprehensive analysis with error handling
        try:
            ai_analysis = generate_ai_analysis(query, formatted_results, sql_query, execution_time, financial_columns)
            
            # Ensure ai_analysis is a dictionary
            if isinstance(ai_analysis, str):
                try:
                    ai_analysis = json.loads(ai_analysis)
                except json.JSONDecodeError:
                    ai_analysis = {
                        'executive_summary': ai_analysis,
                        'key_insights': [],
                        'recommendations': []
                    }
        except Exception as e:
            logger.error(f"Error generating AI analysis: {str(e)}")
            ai_analysis = {
                'executive_summary': f"Analysis of {len(results)} records",
                'key_insights': [],
                'recommendations': []
            }

        # Determine response format and create visualizations
        response_format = determine_response_format(query, formatted_results)
        
        # Create chart if applicable
        chart_data = prepare_chart_data(formatted_results, query)
        if chart_data and response_format in ['chart', 'both']:
            full_chart_config = {
                "type": "chart",
                "title": chart_data.get('title', 'Data Visualization'),
                "content": {
                    "chart_type": chart_data['chart_type'],
                    "data": chart_data['data'],
                    "options": chart_data['options']
                }
            }
            objects.append(full_chart_config)
        
        # Add table if requested or as fallback
        if response_format in ['table', 'both'] or (response_format == 'chart' and not chart_data):
            clean_headers, formatted_rows = format_table_data(formatted_results, financial_columns)
            
            objects.append({
                "type": "table",
                "title": f"Data Table ({len(results)} records)",
                "content": {
                    "headers": clean_headers,
                    "rows": formatted_rows,
                    "financial_columns": list(financial_columns) if financial_columns else []
                }
            })
        
        # Helper function to clean markdown and format as bullet points
        def format_content_as_bullets(content):
            if isinstance(content, list):
                bullet_text = '<ul style="margin: 0; padding-left: 20px;">'
                for item in content:
                    # Clean markdown symbols including "* -" pattern
                    clean_item = str(item).replace('**', '').replace('* -', '').replace('*', '').replace('##', '').replace('#', '').strip()
                    # Also remove standalone dashes at the beginning
                    if clean_item.startswith('- '):
                        clean_item = clean_item[2:].strip()
                    bullet_text += f'<li style="margin-bottom: 10px; line-height: 1.6;">{clean_item}</li>'
                bullet_text += '</ul>'
                return bullet_text
            else:
                # Similar logic for string content
                content_str = str(content).replace('**', '').replace('* -', '').replace('*', '').replace('##', '').replace('#', '').strip()
                
                # Split by common separators
                lines = []
                for separator in ['. ', '.\n', '\n', ';']:
                    if separator in content_str:
                        lines = [line.strip() for line in content_str.split(separator) if line.strip()]
                        break
                
                if not lines:
                    lines = [content_str]
                
                bullet_text = '<ul style="margin: 0; padding-left: 20px;">'
                for line in lines:
                    if line:
                        # Remove leading dashes
                        if line.startswith('- '):
                            line = line[2:].strip()
                        bullet_text += f'<li style="margin-bottom: 10px; line-height: 1.6;">{line}</li>'
                bullet_text += '</ul>'
                return bullet_text
        
        # Add AI-generated explanation with bullet points
        if ai_analysis.get('explanation') or ai_analysis.get('executive_summary'):
            explanation_content = ai_analysis.get('explanation') or ai_analysis.get('executive_summary', 'Analysis completed successfully.')
            explanation_bullets = format_content_as_bullets(explanation_content)
            
            explanation_html = f"""
            <div style='background: #f8f9ff; padding: 25px; border-radius: 12px; border-left: 5px solid #4CAF50; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #2E7D32; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Data Analysis & Insights
                </h3>
                <div style='line-height: 1.7; font-size: 15px; color: #444;'>
                    {explanation_bullets}
                </div>
            </div>
            """
            objects.append({
                "type": "text",
                "title": "AI Analysis",
                "content": {"html": explanation_html}
            })
        
        # Add detailed breakdown of results with bullet points
        if ai_analysis.get('breakdown') or ai_analysis.get('detailed_breakdown'):
            breakdown_content = ai_analysis.get('breakdown') or ai_analysis.get('detailed_breakdown', 'Detailed analysis in progress.')
            breakdown_bullets = format_content_as_bullets(breakdown_content)
            
            breakdown_html = f"""
            <div style='background: #e8f5e8; padding: 25px; border-radius: 12px; border-left: 5px solid #66BB6A; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #2E7D32; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Detailed Results Breakdown
                </h3>
                <div style='line-height: 1.7; font-size: 15px; color: #444;'>
                    {breakdown_bullets}
                </div>
            </div>
            """
            objects.append({
                "type": "text",
                "title": "Results Breakdown",
                "content": {"html": breakdown_html}
            })
        
        # Add key insights and patterns with clean bullet points
        if ai_analysis.get('insights') or ai_analysis.get('key_insights'):
            insights_content = ai_analysis.get('insights') or ai_analysis.get('key_insights', 'Key insights are being analyzed.')
            insights_bullets = format_content_as_bullets(insights_content)
                
            insights_html = f"""
            <div style='background: #fff3e0; padding: 25px; border-radius: 12px; border-left: 5px solid #FF9800; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #E65100; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Key Insights & Patterns
                </h3>
                <div style='line-height: 1.7; font-size: 15px; color: #444;'>
                    {insights_bullets}
                </div>
            </div>
            """
            objects.append({
                "type": "text",
                "title": "Key Insights",
                "content": {"html": insights_html}
            })
        # Add recommendations and next steps with clean bullet points
        if ai_analysis.get('recommendations') or ai_analysis.get('actionable_recommendations'):
            recommendations_content = ai_analysis.get('recommendations') or ai_analysis.get('actionable_recommendations', 'Recommendations are being generated.')
            recommendations_bullets = format_content_as_bullets(recommendations_content)
            recommendations_html = f"""
            <div style='background: #f3e5f5; padding: 25px; border-radius: 12px; border-left: 5px solid #9C27B0; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #6A1B9A; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Recommendations & Action Items
                </h3>
                <div style='line-height: 1.7; font-size: 15px; color: #444;'>
                    {recommendations_bullets}
                </div>
            </div>
            """
            objects.append({
                "type": "text",
                "title": "Recommendations",
                "content": {"html": recommendations_html}
            })
        
        # Add follow-up questions
        # Add follow-up questions
        if ai_analysis.get('follow_up_questions'):
            follow_up_content = ai_analysis.get('follow_up_questions', [])
            follow_up_bullets = format_content_as_bullets(follow_up_content)
                    
            follow_up_html = f"""
            <div style='background: #e3f2fd; padding: 25px; border-radius: 12px; border-left: 5px solid #2196F3; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #1976D2; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Suggested Follow-up Questions
                </h3>
                <div style='line-height: 1.7; font-size: 15px; color: #444;'>
                    {follow_up_bullets}
                </div>
                <div style='margin-top: 15px; padding: 15px; background: rgba(33, 150, 243, 0.1); border-radius: 8px; font-style: italic; font-size: 14px; color: #1976D2;'>
                    Feel free to ask any of these questions to dive deeper into your data!
                </div>
            </div>
            """
            objects.append({
                "type": "text",
                "title": "Follow-up Questions",
                "content": {"html": follow_up_html}
            })
        
        # Add technical details (SQL explanation)
        if explanation or sql_query:
            technical_html = """
            <div style='background: #fafafa; padding: 25px; border-radius: 12px; border-left: 5px solid #607D8B; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                <h3 style='color: #37474F; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                    <span style='margin-right: 12px;'></span> Technical Implementation
                </h3>
                <div style='margin: 15px 0;'>
            """
            
            if explanation:
                formatted_explanation = explanation.replace('\n', '<br>')
                technical_html += f"""
                    <div style='line-height: 1.6; font-size: 14px; color: #555; margin-bottom: 20px;'>
                        <h4 style='color: #37474F; margin-bottom: 10px;'>Query Processing Steps:</h4>
                        {formatted_explanation}
                    </div>
                """
            
            if sql_query:
                formatted_sql = sql_query.strip()
                if formatted_sql.startswith('```sql'):
                    formatted_sql = formatted_sql[6:]
                if formatted_sql.endswith('```'):
                    formatted_sql = formatted_sql[:-3]
                formatted_sql = formatted_sql.strip()
                
                technical_html += f"""
                    <details style='margin-top: 15px; border: 1px solid #ddd; border-radius: 8px; overflow: hidden;'>
                        <summary style='cursor: pointer; font-weight: bold; color: #37474F; padding: 12px 15px; background: #f5f5f5; user-select: none; transition: background-color 0.2s;'>
                            <span style='margin-right: 8px;'></span> SQL Query Used
                        </summary>
                        <div style='background: #1e1e1e; color: #ffffff; padding: 20px; font-family: "Courier New", Monaco, monospace; font-size: 13px; line-height: 1.4; overflow-x: auto;'>
                            <code style='color: #ffffff; white-space: pre;'>{formatted_sql}</code>
                        </div>
                    </details>
                """

            technical_html += "</div></div>"
            objects.append({
                "type": "text",
                "title": "Technical Details",
                "content": {"html": technical_html}
            })

        # Add enhanced summary with AI insights
        summary_stats = ai_analysis.get('summary_stats', {})
        
        # Calculate financial summary if financial columns detected
        financial_summary = ""
        if financial_columns:
            try:
                total_financial = 0
                financial_count = 0
                for col in financial_columns:
                    for row in results:
                        val = row.get(col)
                        if val is not None:
                            try:
                                clean_val = str(val).replace('$', '').replace(',', '')
                                total_financial += float(clean_val)
                                financial_count += 1
                            except (ValueError, TypeError):
                                continue
                
                if financial_count > 0:
                    avg_financial = total_financial / financial_count
                    financial_summary = f"""
                    <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);'>
                        <div style='font-size: 24px; font-weight: bold; margin-bottom: 5px;'>${total_financial:,.2f}</div>
                        <div style='font-size: 14px; opacity: 0.9;'>Total Financial Value</div>
                    </div>
                    """
            except Exception as e:
                logger.error(f"Financial summary calculation failed: {str(e)}")
        
        summary_html = f"""
        <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 12px; margin-top: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);'>
            <h3 style='color: white; margin-top: 0; display: flex; align-items: center; font-size: 18px;'>
                <span style='margin-right: 12px;'></span> Executive Summary
            </h3>
            <div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px;'>
                <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);'>
                    <div style='font-size: 24px; font-weight: bold; margin-bottom: 5px;'>{len(results):,}</div>
                    <div style='font-size: 14px; opacity: 0.9;'>Records Found</div>
                </div>
                <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);'>
                    <div style='font-size: 24px; font-weight: bold; margin-bottom: 5px;'>{execution_time:.2f}s</div>
                    <div style='font-size: 14px; opacity: 0.9;'>Query Time</div>
                </div>
                <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);'>
                    <div style='font-size: 24px; font-weight: bold; margin-bottom: 5px;'>{chart_data['chart_type'].title() if chart_data else 'Table'}</div>
                    <div style='font-size: 14px; opacity: 0.9;'>Visualization</div>
                </div>
                <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);'>
                    <div style='font-size: 24px; font-weight: bold; margin-bottom: 5px;'>{summary_stats.get("confidence_score", "High")}</div>
                    <div style='font-size: 14px; opacity: 0.9;'>Data Quality</div>
                </div>
                {financial_summary}
            </div>
            {f'<div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 8px; font-size: 15px; line-height: 1.6;">{summary_stats.get("key_takeaway", "Analysis completed successfully.")}</div>' if summary_stats.get("key_takeaway") else ''}
        </div>
        """
        
        objects.append({
            "type": "text",
            "title": "Summary",
            "content": {"html": summary_html}
        })
        
    except Exception as e:
        logger.error(f"Error formatting response objects: {str(e)}")
   
    return objects


def prepare_data_summary(results):
    """Prepare a concise summary of the data for AI analysis"""
    if not results:
        return "No data available"
    
    headers = list(results[0].keys())
    numeric_cols = []
    categorical_cols = []
    
    # Categorize columns
    for header in headers:
        sample_values = [row.get(header) for row in results[:5]]
        if any(isinstance(val, (int, float)) for val in sample_values):
            numeric_cols.append(header)
        else:
            categorical_cols.append(header)
    
    summary = f"Dataset with {len(results)} records and {len(headers)} columns.\n"
    
    if numeric_cols:
        summary += f"Numeric columns: {', '.join(numeric_cols)}\n"
        
        # Add basic stats for first numeric column
        first_numeric = numeric_cols[0]
        values = [float(row.get(first_numeric, 0)) for row in results if row.get(first_numeric) is not None]
        if values:
            summary += f"{first_numeric} range: {min(values):,.2f} to {max(values):,.2f}, avg: {sum(values)/len(values):,.2f}\n"
    
    if categorical_cols:
        summary += f"Categorical columns: {', '.join(categorical_cols)}\n"
        
        # Add unique count for first categorical column
        if categorical_cols:
            first_cat = categorical_cols[0]
            unique_values = set(str(row.get(first_cat, '')) for row in results)
            summary += f"{first_cat} has {len(unique_values)} unique values\n"
    
    return summary

# # UPDATED: generate_ai_analysis function
def generate_ai_analysis(query, results, sql_query, execution_time, financial_columns=None, chart_data=None):
    """Generate comprehensive AI analysis using Agno AI agent"""
    try:
        # Prepare data summary for AI analysis
        data_summary = prepare_data_summary(results)
        chart_info = f"Chart Type: {chart_data['chart_type']}" if chart_data else "No visualization"
        
        # Enhanced analysis prompt that ensures proper section formatting
        analysis_prompt = f"""
        You are an expert medical practice data analyst. Analyze the following query results and provide a comprehensive analysis.

        **Query Context:**
        - Original Query: {query}
        - Results Count: {len(results) if results else 0}
        - Execution Time: {execution_time:.2f} seconds
        - Visualization: {chart_info}
        """
        
        # Add sample data for context
        if results and len(results) > 0:
            sample_size = min(3, len(results))
            analysis_prompt += f"\n**Sample Data (first {sample_size} records):**\n"
            for i, row in enumerate(results[:sample_size]):
                analysis_prompt += f"Record {i+1}: {dict(row)}\n"
        
        # Add financial context
        if financial_columns:
            analysis_prompt += f"\n**Financial Columns Detected:** {', '.join(financial_columns)}"
        
        analysis_prompt += """
        
        Please provide your analysis in EXACTLY this format with these section headers:

        ## EXECUTIVE_SUMMARY
        Provide a clear, conversational 2-3 bullet points  overview of what the data shows.
        ## PARAMETER_EXPLANATION
        For each data column, explain keep each point in new line:
        - explain the column and table name and tell what meaning of this why these column important for the result
        - How to interpret the values
        - don't overwhelm  and  keep small bullet point wise
        - keep informative dont overcontent
        
        ## DETAILED_BREAKDOWN keep each point in new line
        Explain the key patterns, trends, and important details in the data. Include specific numbers and percentages where relevant in point wise .

        ## KEY_INSIGHTS
        • List 3-5 key insights as bullet points
        • Each insight should be specific and actionable
        • Include numerical data where possible
        • Focus on business implications
        • dont tell about execution time
        

        ## RECOMMENDATIONS
        • Provide 3-5 specific, actionable recommendations in point wise 
        • Focus on practical steps they can take
        • Prioritize high-impact actions
        • Consider both short-term and strategic goals

        ## FOLLOW_UP_QUESTIONS
        • Suggest 1-2 intelligent follow-up questions
        • Make them specific to this data
        

        ## SUMMARY_STATS
        confidence_score: High
        key_takeaway: One powerful sentence summarizing the most important insight from this data.

        Make your response engaging, specific, and actionable. Use actual numbers from the data when possible.
        """
        

        analysis_agent = Agent(
            name="Medical Data Analysis Expert",
            model=Groq(id="llama-3.1-8b-instant"),
            description="Expert medical practice data analyst providing comprehensive insights",
            instructions="You are a friendly, knowledgeable AI assistant specializing in medical practice data analysis. Provide detailed, actionable insights that help medical professionals make better decisions."
        )
    
        # Generate AI analysis
        result = analysis_agent.run(analysis_prompt, timeout=90)
        
        # Parse the AI response into structured format
        analysis_sections = parse_ai_analysis_response(result.content)
        
        return analysis_sections
        
    except Exception as e:
        logger.error(f"Error generating AI analysis: {str(e)}")
        # Return comprehensive fallback
        return {
            'executive_summary': f"I've analyzed your query results and found {len(results) if results else 0} records with valuable insights for your medical practice.",
            'detailed_breakdown': "This dataset contains important information that can help inform your operational decisions. The data shows clear patterns that warrant further investigation.",
            'key_insights': [
                f"Query successfully retrieved {len(results) if results else 0} records from your database",
                "Data contains both financial and operational metrics",
                "Results show patterns that can guide business decisions",
                "Multiple data points available for comparative analysis"
            ],
            'recommendations': [
                "Review the detailed data table for specific values and trends",
                "Consider comparing this data with historical periods",
                "Look for outliers or unusual patterns that may need attention",
                "Use this analysis as a baseline for future performance tracking"
            ],
            'follow_up_questions': [
                "How does this data compare to the same period last year?",
                "What are the trends over the last 6 months for these metrics?",
                "Can you show me the top performers in this category?",
                "Are there any seasonal patterns I should be aware of?"
            ],
            'summary_stats': {
                'confidence_score': 'High',
                'key_takeaway': 'Your data analysis reveals actionable insights that can drive informed decision-making for your medical practice.'
            }
        }

def generate_fallback_analysis(results):
    """Generate a structured fallback analysis when primary fails"""
    record_count = len(results) if results else 0
    return {
        'executive_summary': f"Analysis of {record_count} records reveals valuable insights for your practice.",
        'parameter_explanations': "Data columns contain operational and financial metrics important for practice management.",
        'detailed_breakdown': "The dataset shows patterns that can inform decision-making when analyzed in detail.",
        'key_insights': [
            f"Found {record_count} relevant records for analysis",
            "Data contains multiple metrics for comprehensive review",
            "Several data points show interesting patterns worth investigating"
        ],
        'recommendations': [
            "Examine the detailed data for specific trends",
            "Compare with historical data for context",
            "Identify outliers that may need attention"
        ],
        'follow_up_questions': [
            "How do these results compare to our targets?",
            "What trends appear when looking at a longer time period?",
            "Which areas show the most variation?",
            "Are there correlations between these metrics?"
        ],
        'summary_stats': {
            'confidence_score': 'Medium',
            'key_takeaway': 'Your data contains valuable insights that can inform practice management decisions.'
        }
    }
# FIXED FUNCTION: parse_ai_analysis_response
def parse_ai_analysis_response(ai_response):
    """Parse the AI analysis response into structured sections"""
    try:
        analysis_dict = {}
        
        # Split response by section headers
        sections = {
            'executive_summary': ['## EXECUTIVE_SUMMARY', 'executive_summary', 'explanation'],
            'detailed_breakdown': ['## DETAILED_BREAKDOWN', 'detailed_breakdown', 'breakdown'],
            'key_insights': ['## KEY_INSIGHTS', 'key_insights', 'insights'],
            'recommendations': ['## RECOMMENDATIONS', 'actionable_recommendations', 'recommendations'],
            'follow_up_questions': ['## FOLLOW_UP_QUESTIONS', 'follow_up_questions'],
            'summary_stats': ['## SUMMARY_STATS', 'summary_stats']
        }
        
        # Parse each section
        for section_key, section_markers in sections.items():
            content = None
            
            # Try to find content by section markers
            for marker in section_markers:
                if marker.upper() in ai_response.upper():
                    # Find content between this marker and next section
                    start_idx = ai_response.upper().find(marker.upper())
                    if start_idx != -1:
                        start_idx += len(marker)
                        # Find next section or end
                        next_section_idx = len(ai_response)
                        for next_marker in ['## ', '\n##']:
                            temp_idx = ai_response.find(next_marker, start_idx + 10)
                            if temp_idx != -1 and temp_idx < next_section_idx:
                                next_section_idx = temp_idx
                        
                        content = ai_response[start_idx:next_section_idx].strip()
                        break
            
            # Clean up content
            if content:
                content = content.replace('##', '').strip()
                # Convert bullet points to list if needed
                if section_key in ['key_insights', 'recommendations', 'follow_up_questions']:
                    if '•' in content or '*' in content or '-' in content:
                        lines = content.split('\n')
                        bullet_points = []
                        for line in lines:
                            line = line.strip()
                            if line and (line.startswith('•') or line.startswith('*') or line.startswith('-')):
                                bullet_points.append(line[1:].strip())
                            elif line and not line.startswith('#'):
                                bullet_points.append(line)
                        if bullet_points:
                            content = bullet_points
                
                analysis_dict[section_key] = content
        
        # Parse summary stats specially
        if 'summary_stats' not in analysis_dict:
            analysis_dict['summary_stats'] = {
                'confidence_score': 'High',
                'key_takeaway': 'Analysis completed successfully with valuable insights.'
            }
        
        return analysis_dict
        
    except Exception as e:
        logger.error(f"Error parsing AI analysis response: {str(e)}")
        return {
            'executive_summary': 'Analysis completed successfully.',
            'detailed_breakdown': 'Detailed breakdown available in results.',
            'key_insights': ['Analysis provides valuable insights into your data.'],
            'recommendations': ['Review the data patterns and consider follow-up analysis.'],
            'follow_up_questions': ['What specific trends would you like to explore further?'],
            'summary_stats': {'confidence_score': 'High', 'key_takeaway': 'Data analysis completed.'}
        }



def format_ai_text_to_html(text):
    """Convert AI-generated text to properly formatted HTML"""
    if not text:
        return ""
    
    # Convert markdown-style formatting to HTML
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.*?)\*', r'<em>\1</em>', text)
    text = re.sub(r'^\* ', r'• ', text, flags=re.MULTILINE)
    text = re.sub(r'^\d+\. ', lambda m: f'<strong>{m.group().strip()}</strong> ', text, flags=re.MULTILINE)
    
    # Convert bullet points to proper list
    if '•' in text:
        lines = text.split('\n')
        formatted_lines = []
        in_list = False
        
        for line in lines:
            line = line.strip()
            if line.startswith('•'):
                if not in_list:
                    formatted_lines.append('<ul style="margin: 10px 0; padding-left: 20px;">')
                    in_list = True
                formatted_lines.append(f'<li style="margin-bottom: 8px;">{line[1:].strip()}</li>')
            else:
                if in_list:
                    formatted_lines.append('</ul>')
                    in_list = False
                if line:
                    formatted_lines.append(f'<p style="margin-bottom: 12px;">{line}</p>')
        
        if in_list:
            formatted_lines.append('</ul>')
        
        text = '\n'.join(formatted_lines)
    else:
        # Convert paragraphs
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        text = '\n'.join(f'<p style="margin-bottom: 12px;">{p}</p>' for p in paragraphs)
    
    return text


def format_follow_up_questions(text):
    """Format follow-up questions into a nice list"""
    if not text:
        return ""
    
    # Extract questions (lines that end with ?)
    lines = text.split('\n')
    questions = []
    
    for line in lines:
        line = line.strip()
        if line and (line.endswith('?') or any(line.startswith(prefix) for prefix in ['- ', '* ', '1.', '2.', '3.', '4.', '5.'])):
            # Clean up the line
            line = re.sub(r'^[-*\d.]\s*', '', line).strip()
            if line and not line.endswith('?'):
                line += '?'
            questions.append(line)
    
    if not questions:
        # Fallback questions
        questions = [
            "Can you show me trends over time for this data?",
            "How does this compare to previous periods?"
        ]
    
    # Format as HTML list
    question_html = '<ul style="margin: 10px 0; padding-left: 20px;">'
    for question in questions[:5]:  # Limit to 5 questions
        question_html += f'<li style="margin-bottom: 10px; cursor: pointer; padding: 8px; background: rgba(33, 150, 243, 0.05); border-radius: 6px; transition: all 0.2s;" onmouseover="this.style.background=\'rgba(33, 150, 243, 0.1)\'" onmouseout="this.style.background=\'rgba(33, 150, 243, 0.05)\'">{question}</li>'
    question_html += '</ul>'
    
    return question_html

def determine_response_format(query, results):
    """Determine the best response format - ALWAYS show table, and chart when appropriate"""
    query_lower = query.lower()
    
    # Always include table in response
    base_format = 'table'
    
    # Check if we should also show chart
    show_chart = False
    
    # Explicit chart requests
    if any(term in query_lower for term in ['chart', 'graph', 'plot', 'visualize', 'visualization']):
        show_chart = True
    
    # Explicit table-only requests
    elif any(term in query_lower for term in ['table only', 'tabular only', 'just table', 'only table']):
        return 'table'
    
    # Auto-determine chart suitability
    elif results and len(results) > 1:
        # Check if we have appropriate data structure for charts
        if isinstance(results[0], dict):
            headers = list(results[0].keys())
            
            # Don't show chart for single column data
            if len(headers) <= 1:
                return 'table'
            
            # Show chart for reasonable data sizes
            if 2 <= len(results) <= 100:  # Reasonable range for visualization
                show_chart = True
    
    # Return format decision
    if show_chart:
        return 'both'  # Show both table and chart
    else:
        return 'table'  # Show only table
    
def preprocess_user_query(query):
    if not query or not query.strip():
        return query.strip() if query else ""
    
    query = re.sub(r'\s+', ' ', query)
    query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)
    query = re.sub(r'/\*.*?\*/', '', query, flags=re.DOTALL)
    return query

def create_chart_html(item, unique_id, conversation_id):
    """Create robust chart HTML with enhanced error handling"""
    chart_content = item.get('content', {})
    chart_title = item.get('title', 'Data Visualization')
    
    # Validate chart configuration
    if not chart_content or 'chart_type' not in chart_content:
        return f"""
        <div style='text-align: center; color: #666; padding: 40px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6;'>
            <h4 style='margin: 0; color: #6c757d;'> Chart data unavailable</h4>
            <p style='margin: 10px 0 0 0; font-size: 14px;'>The chart configuration could not be loaded.</p>
        </div>
        """
    
    # Build comprehensive chart configuration
    chart_config = {
        'type': chart_content.get('chart_type', 'bar'),
        'data': chart_content.get('data', {'labels': [], 'datasets': []}),
        'options': {
            'responsive': True,
            'maintainAspectRatio': False,
            'plugins': {
                'legend': {
                    'display': True,
                    'position': 'top'
                },
                'title': {
                    'display': True,
                    'text': chart_title,
                    'font': {'size': 16, 'weight': 'bold'}
                },
                'tooltip': {
                    'enabled': True,
                    'mode': 'index',
                    'intersect': False
                }
            },
            'interaction': {
                'mode': 'nearest',
                'axis': 'x',
                'intersect': False
            }
        }
    }
    
    # Merge existing options
    if 'options' in chart_content:
        merge_options(chart_config['options'], chart_content['options'])
    
    # Add scales for appropriate chart types
    if chart_config['type'] in ['bar', 'line', 'area']:
        if 'scales' not in chart_config['options']:
            chart_config['options']['scales'] = {
                'x': {
                    'beginAtZero': True,
                    'grid': {
                        'display': True,
                        'color': 'rgba(0, 0, 0, 0.1)'
                    }
                },
                'y': {
                    'beginAtZero': True,
                    'grid': {
                        'display': True,
                        'color': 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
    
    # Convert chart config to JSON string with error handling
    try:
        chart_config_json = json.dumps(chart_config, ensure_ascii=False)
    except (TypeError, ValueError) as e:
        logger.error(f"Chart config serialization error: {e}")
        return f"""
        <div style='text-align: center; color: #dc3545; padding: 40px; background: #f8d7da; border-radius: 8px; border: 1px solid #f5c6cb;'>
            <h4 style='margin: 0;'> Chart Configuration Error</h4>
            <p style='margin: 10px 0 0 0; font-size: 14px;'>Unable to serialize chart configuration.</p>
        </div>
        """
    
    # Generate the complete chart HTML
    chart_html = f"""
    <div class='chart-container' style='position: relative; width: 100%; margin: 20px 0; padding: 20px; background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border: 1px solid #e9ecef;'>
        <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #f8f9fa;'>
            <h4 style='margin: 0; color: #495057; font-size: 18px; font-weight: 600;'>
                 {chart_title}
            </h4>
            <div style='display: flex; gap: 10px; align-items: center;'>
                <span style='font-size: 12px; color: #6c757d; background: #f8f9fa; padding: 4px 8px; border-radius: 4px;'>
                    ID: {conversation_id}
                </span>
            </div>
        </div>
        
        <div style='position: relative; height: 400px; width: 100%;'>
            <canvas id='{unique_id}' style='max-height: 400px; width: 100%;'></canvas>
            <div id='{unique_id}_loading' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: #6c757d;'>
                <div style='font-size: 14px;'>Loading chart...</div>
                <div style='margin-top: 10px; font-size: 24px;'></div>
            </div>
            <div id='{unique_id}_error' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: #dc3545; display: none;'>
                <div style='font-size: 14px; font-weight: 500;'> Chart Load Error</div>
                <div style='margin-top: 5px; font-size: 12px;'>Please refresh the page to retry</div>
            </div>
        </div>
        
        <script>
            (function() {{
                const canvasId = '{unique_id}';
                const loadingId = '{unique_id}_loading';
                const errorId = '{unique_id}_error';
                let retryCount = 0;
                const maxRetries = 5;
                
                function hideLoading() {{
                    const loading = document.getElementById(loadingId);
                    if (loading) loading.style.display = 'none';
                }}
                
                function showError() {{
                    hideLoading();
                    const error = document.getElementById(errorId);
                    if (error) error.style.display = 'block';
                }}
                
                function initChart() {{
                    const canvas = document.getElementById(canvasId);
                    if (!canvas) {{
                        console.warn('Canvas not found:', canvasId);
                        return;
                    }}
                    
                    if (typeof Chart === 'undefined') {{
                        if (retryCount < maxRetries) {{
                            retryCount++;
                            console.log(`Chart.js not loaded yet, retry ${{retryCount}}/${{maxRetries}}`);
                            setTimeout(initChart, 200 * retryCount);
                            return;
                        }} else {{
                            console.error('Chart.js failed to load after', maxRetries, 'retries');
                            showError();
                            return;
                        }}
                    }}
                    
                    try {{
                        const ctx = canvas.getContext('2d');
                        const config = {chart_config_json};
                        
                        // Validate configuration
                        if (!config.data || !config.data.labels || !config.data.datasets) {{
                            throw new Error('Invalid chart configuration: missing data structure');
                        }}
                        
                        // Create the chart
                        const chart = new Chart(ctx, config);
                        
                        // Hide loading indicator on success
                        hideLoading();
                        
                        console.log('Chart initialized successfully:', canvasId);
                        
                    }} catch (error) {{
                        console.error('Chart creation error for', canvasId, ':', error);
                        showError();
                    }}
                }}
                
                // Multiple initialization strategies
                if (document.readyState === 'complete') {{
                    initChart();
                }} else {{
                    document.addEventListener('DOMContentLoaded', initChart);
                    // Fallback for cases where DOMContentLoaded already fired
                    setTimeout(initChart, 100);
                }}
                
                // Additional fallback for dynamic content loading
                setTimeout(initChart, 500);
            }})();
        </script>
    </div>
    """
    
    return chart_html


def merge_options(target, source):
    """Recursively merge chart options"""
    for key, value in source.items():
        if key in target and isinstance(target[key], dict) and isinstance(value, dict):
            merge_options(target[key], value)
        else:
            target[key] = value


def create_fallback_content(conv):
    """Create fallback content for conversation display with enhanced styling"""
    query = conv.get('query', '')
    sql_query = conv.get('sql_query', '')
    result_count = conv.get('result_count', 0)
    
    html = f'''
    <div class="conversation-item" style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #6c757d; margin: 10px 0;">
        <h4 style="color: #495057; margin-top: 0; font-size: 16px;">Query Response</h4>
        <p style="margin: 10px 0;"><strong>Query:</strong> {query}</p>
    '''
    
    if sql_query:
        html += f'<p style="margin: 10px 0;"><strong>SQL:</strong> <code style="background: #e9ecef; padding: 2px 4px; border-radius: 3px;">{sql_query}</code></p>'
    
    html += f'<p style="margin: 10px 0 0 0;"><strong>Results:</strong> {result_count} rows</p>'
    html += '</div>'
    
    return html
def create_table_html(headers, rows, financial_columns=None):
    """Create styled HTML table with proper formatting"""
    if financial_columns is None:
        financial_columns = set()
    
    # Determine which columns are actually financial using improved detection
    financial_cols_set = set(financial_columns)
    for header in headers:
        if is_financial_column(header):
            financial_cols_set.add(header)
    
    table_html = """
    <div style='overflow-x: auto; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
        <table style='width: 100%; border-collapse: collapse; background: white;'>
            <thead>
                <tr style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'>
    """
    
    for header in headers:
        table_html += f"<th style='padding: 15px 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #dee2e6;'>{header}</th>"
    
    table_html += "</tr></thead><tbody>"
    
    for i, row in enumerate(rows):
        bg_color = '#f8f9fa' if i % 2 == 0 else 'white'
        table_html += f"<tr style='background: {bg_color}; transition: background-color 0.2s;' onmouseover='this.style.background=\"#e3f2fd\"' onmouseout='this.style.background=\"{bg_color}\"'>"
        
        for col, cell in zip(headers, row):
            if col in financial_cols_set:
                # Right-align financial columns
                table_html += f"<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: #495057; text-align: right;'>{cell}</td>"
            else:
                table_html += f"<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: #495057;'>{cell}</td>"
        
        table_html += "</tr>"
    
    table_html += "</tbody></table></div>"  
    return table_html